  
# paymentmanagement

Welcome to the Spring Boot Project 

<Write here a project description>

# Build and Compile with Maven

```
$> mvn compile package
```
# Execute

It's a Spring Boot Project, so you can run with:

```
$> java -jar target/paymentmanagement --spring.profiles.active=LOCAL
```

# Build a container with Docker

Build a Dokcer image from the files of your target project
```
$> docker build  -t api/paymentmanagement:<version> .
```

Then, you can run with:
```
docker run -e "BOOTAPP_OPTS=--spring.profiles.active=MOCK" \
            -t api/paymentmanagement:<version>
```

The exposed port it's 8080. You can access by:
```
http://localhost:8080/
```

To deploy in a local registry use:
```
$> docker push paymentmanagement:<tagName>
```

# Kubernetes


