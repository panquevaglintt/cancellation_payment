package com.orange.api.paymentmanagement.mappers;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Iframe;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class GenerationIframeMapper {

    public static Iframe mapPaymentToIframe(FixedValuesDB fixedValues, Payment payment, String zLogin, String transactiontype, String urlIframe, String urlIframe3DS2)
            throws UnsupportedEncodingException {
    	String url = Constants.TOP_UP.equalsIgnoreCase(transactiontype) ? urlIframe3DS2 : urlIframe;
        String date = mapDate();
        String msisdn = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.PHONENUMBER);
        String documento = PaymentManagementUtils.mapDocument(payment.getPayer());
        int amountInt = payment.getTotalAmount().getValue().intValue();
        String amount = String.valueOf(amountInt);
        String custCode = PaymentManagementUtils.mapCustomerCode(payment.getPayer());
        String numOpOrigen = PaymentManagementUtils.getNumOrigen();
        log.info("Se va a generar iframe con Numero Operacion Origen: " + numOpOrigen);

        String urlOK = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.REDIRECTION_OK);
        String urlKO = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.REDIRECTION_KO);

        StringBuilder strHashBuilder = new StringBuilder();
        strHashBuilder.append(date).append(amount).append(fixedValues.getClientCode())
                .append(fixedValues.getCommercialCode()).append(fixedValues.getTerminalCode()).append(numOpOrigen)
                .append(urlOK).append(fixedValues.getSeed());
        String hash = DigestUtils.sha256Hex(strHashBuilder.toString());

        url += "?coCliente=" + fixedValues.getClientCode();
        url += "&coComercio=" + fixedValues.getCommercialCode();
        url += "&coTerminal=" + fixedValues.getTerminalCode();

        url += "&fechaOpOrigen=" + URLEncoder.encode(date, Constants.C_UTF8);
        url += "&idioma=" + fixedValues.getLanguage();
        url += "&numOpOrigen=" + numOpOrigen;
        url += "&importe=" + amount;
        url += "&urlOk=" + URLEncoder.encode(urlOK, Constants.C_UTF8);
        url += "&urlKo=" + URLEncoder.encode(urlKO, Constants.C_UTF8);
        url += "&moneda=" + fixedValues.getCurrency();
        url += "&hash=" + hash;
        url += "&urlCss=" + URLEncoder.encode(fixedValues.getUrlCss(), Constants.C_UTF8);
        url += "&botonForm=" + fixedValues.getFormButton();
        url += "&template=" + fixedValues.getTemplate();
        url += "&cardType=" + fixedValues.getCardType();
        url += "&msisdn=" + msisdn;
        url += "&documento=" + documento;
        url += "&usuario=" + zLogin;
        if(StringUtils.isNotEmpty(custCode)) {
        	url += "&customer_code=" + custCode;
        }
        url += "&target=" + fixedValues.getTarget();

        Iframe iframeObject = new Iframe();

        iframeObject.setDate(date);
        iframeObject.setIframe(url);
        iframeObject.setNumOpOrigen(numOpOrigen);
        iframeObject.setUrlKo(urlKO);
        iframeObject.setUrlOk(urlOK);
        iframeObject.setHash(hash);
        iframeObject.setCustCode(custCode);

        return iframeObject;

    }
    
    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    public static void mapIframeToPayment(Iframe iframe, Payment payment) {

        payment.setId(iframe.getNumOpOrigen());
        payment.setCharacteristic(mapCharacteristicResponse(iframe.getIframe(), payment.getCharacteristic()));
        payment.setStatus(Constants.PENDING);
        log.info("La fechaPayment de entrada al metod para formatear es : {}", iframe.getDate());
        payment.setStatusDate(PaymentManagementUtils.extractDateOriginIframe(iframe.getDate(), Constants.TIMEZONE_EUROPE_MADRID));
        log.info("La fechaPayment de salida al metod para formatear es : {}", iframe.getDate());
    }
    
    private static List<Characteristic> mapCharacteristicResponse(String iframe,
            List<Characteristic> listCharacteristic) {
        Characteristic characteristic = new Characteristic();

        characteristic.setName(Constants.PAYMENTLINKIFRAME);
        characteristic.setValue(iframe);

        listCharacteristic.add(characteristic);

        return listCharacteristic;
    }

    public static PaymentRegistryDB mapPaymentManagementDB(Payment payment, String zapp, FixedValuesDB fixedValues,
            String transaction, Iframe iframe, String zlogin, String processFlowId) {

        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();

        paymentRegistryDB.setAmount(payment.getTotalAmount().getValue().toString());
        if (payment.getPaymentItem() != null) {
            paymentRegistryDB.setBscsIdentifier(mapBscs(payment.getPaymentItem()));
        }
        paymentRegistryDB.setChannel(zapp);
        paymentRegistryDB.setClientCode(fixedValues.getClientCode());
        paymentRegistryDB.setCommercialCode(fixedValues.getCommercialCode());
        paymentRegistryDB.setCurrency(fixedValues.getCurrency());
        paymentRegistryDB.setIdDocument(PaymentManagementUtils.mapDocument(payment.getPayer()));
        paymentRegistryDB.setTypeDocument(GenerationPaymentLinkMapper.mapTypeDocument(payment.getPayer()));
        paymentRegistryDB.setPhonenumber(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.PHONENUMBER));
        paymentRegistryDB.setType(payment.getPayer().getReferredType());
        if (payment.getPaymentItem() != null) {
            paymentRegistryDB.setVapId(payment.getPaymentItem().get(0).getItem().getId());
        }
        paymentRegistryDB.setLanguage(fixedValues.getLanguage());

        paymentRegistryDB.setOriginOpnumber(iframe.getNumOpOrigen());
        paymentRegistryDB.setPaymentAttempts(fixedValues.getPaymentRetries());
        paymentRegistryDB.setStatus(Constants.PENDING);
        paymentRegistryDB.setStatusDescription(Constants.PENDIENTE_PAGO);
        paymentRegistryDB.setTransactiontype(transaction);
        paymentRegistryDB.setTerminalCode(fixedValues.getTerminalCode());
        paymentRegistryDB.setUserId(zlogin);
        paymentRegistryDB.setProcessflowId(processFlowId);
        paymentRegistryDB.setHash(iframe.getHash());
        paymentRegistryDB.setCustCode(iframe.getCustCode());
        paymentRegistryDB.setUrlKo(iframe.getUrlKo());
        paymentRegistryDB.setUrlOk(iframe.getUrlOk());
        paymentRegistryDB.setUrlIframe(iframe.getIframe());
        paymentRegistryDB.setPaymentUpdate(formatDateIframe(iframe.getDate()));
        paymentRegistryDB.setPaymentFlow(Constants.PAYMENT_FLOW_IFRAME);
        

        log.info("Se ha creado el objeto para guardar en bbdd");

        return paymentRegistryDB;
    }

    public static String formatDateIframe(String dateIframe) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        Date date = null;
        try {
            date = format.parse(dateIframe);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }
        log.info("La fechaupdete de entrada al metod para formatear es : {}", date);
        SimpleDateFormat format1 = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        format1.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String response = format1.format(date);
        return response;
    }

    public static String mapBscs(List<PaymentItem> listPaymentItem) {
        String codebscs = null;

        for (PaymentItem paymentItem : listPaymentItem) {
            if (Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())) {
                codebscs = PaymentManagementUtils.searchValueCharacteristic(paymentItem.getItem().getCharacteristic(),
                        Constants.BSCSCODE);
            }
        }

        return codebscs;
    }

}