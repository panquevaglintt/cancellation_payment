package com.orange.api.paymentmanagement.service.impl;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.mappers.StatusPaymentLinkMapper;
import com.orange.api.paymentmanagement.service.StatusPaymentLinkService;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestStatus;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseStatus;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StatusPaymentLinkServiceImpl implements StatusPaymentLinkService {

    private IntegrationServiceWSPspClient integrationServiceWSPspClient;

    private PaymentRegistryRepository paymentRegistryRepository;

    @Autowired
    public StatusPaymentLinkServiceImpl(IntegrationServiceWSPspClient integrationServiceWSPspClient,
            PaymentRegistryRepository paymentRegistryRepository) {
        this.integrationServiceWSPspClient = integrationServiceWSPspClient;
        this.paymentRegistryRepository = paymentRegistryRepository;
    }

    @Override
    public Payment statusPaymentLink(String id, String type) {
        Payment payment = new Payment();
        RequestStatus requestWS = new RequestStatus();

        PaymentRegistryDB paymentRegistryDB = this.paymentRegistryRepository.findByOriginOpnumber(id);
        if (ObjectUtils.isEmpty(paymentRegistryDB)) {
            log.error("No se ha encontrado ningun registro en BBDD");
            throw new OpenApiNotFoundException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
        }
        StatusPaymentLinkMapper.mapPaymentManagementDBToRequestStatus(paymentRegistryDB, requestWS);
        log.info("Se va a llamar al servicio de consulta de estado del Paymentlink al WS de PSP con la peticion: {}"
                + requestWS.toString());
        ResponseStatus responseStatus = this.integrationServiceWSPspClient.paymentLinkStatus(requestWS);

        log.info("Respuesta del servicio de consulta de estado del Paymentlink al WS de PSP: {}"
                + responseStatus.toString());

        log.info("Vamos a mapear la respuesta de psp");
        StatusPaymentLinkMapper.mapResponseStatusToPayment(id, responseStatus, payment, type);

        log.info("Vamos a actualizar el estado en la BBDD");
        StatusPaymentLinkMapper.mapPaymentRegistryDB(paymentRegistryDB, payment, responseStatus);
        this.paymentRegistryRepository.saveAndFlush(paymentRegistryDB);

        log.info("La llamada de consulta de paymentLink se ha realizado correctamente");

        return payment;
    }

}