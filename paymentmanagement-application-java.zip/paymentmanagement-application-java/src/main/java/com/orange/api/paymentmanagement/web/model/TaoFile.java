package com.orange.api.paymentmanagement.web.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaoFile {

    @JsonProperty(value = "msisdn")
    private String msisdn;
    @JsonProperty(value = "amount")
    private String amount;
    @JsonProperty(value = "paymentMethodId")
    private String paymentMethodId;
    @JsonProperty(value = "rechargeReason")
    private String rechargeReason;

}
