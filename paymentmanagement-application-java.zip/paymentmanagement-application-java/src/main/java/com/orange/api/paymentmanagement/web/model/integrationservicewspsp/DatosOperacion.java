package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosOperacion implements Serializable {
	private static final long serialVersionUID = 1L;

	  @JsonProperty("fechaOpOrigen")
	  private String fechaOpOrigen;
	  
	  @JsonProperty("numAutorizacion")
	  private String numAutorizacion;

	  @JsonProperty("numOperacionNNP")
	  private String numOperacionNNP;
	  
	  @JsonProperty("datosResolutor")
	  private DatosResolutor datosResolutor;
	  
	  @JsonProperty("datosTarjeta")
	  private DatosTarjeta datosTarjeta;
	  
	  @JsonProperty("resultadoOperacion")
	  private ResultadoOperacion resultadoOperacion;
}