package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

public interface TransferFileService {

    Payment paymentProcessingFile(Payment payment, String zApp, String authorizationHeader);
    Payment paymentValidatingFile(Payment payment, String zApp, String authorizationHeader);
}
