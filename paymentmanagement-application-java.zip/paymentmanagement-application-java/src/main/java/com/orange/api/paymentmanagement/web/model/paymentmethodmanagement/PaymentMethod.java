package com.orange.api.paymentmanagement.web.model.paymentmethodmanagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentMethod   {
  
  private String type = null;
  private String id = null;
  private String status = null;
  private String expirationDate = null;
  private String token = null;
  private List<Characteristic> characteristic = new ArrayList<Characteristic>();
  private List<ExternalIdentifier> externalIdentifier = new ArrayList<ExternalIdentifier>();
  private RelatedParty relatedParty = null;

  
  /**
   **/
  public PaymentMethod type(String type) {
    this.type = type;
    return this;
  }
  
  
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  
  /**
   **/
  public PaymentMethod id(String id) {
    this.id = id;
    return this;
  }
  
  
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  
  /**
   **/
  public PaymentMethod status(String status) {
    this.status = status;
    return this;
  }
  
  
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  
  /**
   **/
  public PaymentMethod expirationDate(String expirationDate) {
    this.expirationDate = expirationDate;
    return this;
  }
  
  
  @JsonProperty("expirationDate")
  public String getExpirationDate() {
    return expirationDate;
  }
  public void setExpirationDate(String expirationDate) {
    this.expirationDate = expirationDate;
  }

  
  /**
   **/
  public PaymentMethod token(String token) {
    this.token = token;
    return this;
  }
  
  
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  
  /**
   **/
  public PaymentMethod characteristic(List<Characteristic> characteristic) {
    this.characteristic = characteristic;
    return this;
  }
  
  
  @JsonProperty("characteristic")
  public List<Characteristic> getCharacteristic() {
    return characteristic;
  }
  public void setCharacteristic(List<Characteristic> characteristic) {
    this.characteristic = characteristic;
  }

  
  /**
   **/
  public PaymentMethod externalIdentifier(List<ExternalIdentifier> externalIdentifier) {
    this.externalIdentifier = externalIdentifier;
    return this;
  }
  
  
  @JsonProperty("externalIdentifier")
  public List<ExternalIdentifier> getExternalIdentifier() {
    return externalIdentifier;
  }
  public void setExternalIdentifier(List<ExternalIdentifier> externalIdentifier) {
    this.externalIdentifier = externalIdentifier;
  }

  
  /**
   **/
  public PaymentMethod relatedParty(RelatedParty relatedParty) {
    this.relatedParty = relatedParty;
    return this;
  }
  
  
  @JsonProperty("relatedParty")
  public RelatedParty getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(RelatedParty relatedParty) {
    this.relatedParty = relatedParty;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PaymentMethod paymentMethod = (PaymentMethod) o;
    return Objects.equals(this.type, paymentMethod.type) &&
        Objects.equals(this.id, paymentMethod.id) &&
        Objects.equals(this.status, paymentMethod.status) &&
        Objects.equals(this.expirationDate, paymentMethod.expirationDate) &&
        Objects.equals(this.token, paymentMethod.token) &&
        Objects.equals(this.characteristic, paymentMethod.characteristic) &&
        Objects.equals(this.externalIdentifier, paymentMethod.externalIdentifier) &&
        Objects.equals(this.relatedParty, paymentMethod.relatedParty);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, id, status, expirationDate, token, characteristic, externalIdentifier, relatedParty);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentMethod {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    characteristic: ").append(toIndentedString(characteristic)).append("\n");
    sb.append("    externalIdentifier: ").append(toIndentedString(externalIdentifier)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

