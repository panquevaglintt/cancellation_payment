package com.orange.api.paymentmanagement.feign.decoder;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orange.api.paymentmanagement.errors.CommonServiceErrors;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiCustomException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiUnauthorizedException.OrangeCommonError;

import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomizedIntegrationServiceWSErrorDecoder extends ErrorDecoder.Default {

	private ObjectMapper objectMapper = new ObjectMapper();

	public CustomizedIntegrationServiceWSErrorDecoder() {
		super();
	}

	@Override
	public Exception decode(String methodKey, Response response) {
		Exception exception = null;
		com.orange.api.paymentmanagement.web.model.Error responseError = null;
		int httpstatus = response.status();
		try {
			// Procesar la respuesta y propagar error en la descripcion o tratar aquellos
			// casos que nos interesen
			responseError = objectMapper.readValue(response.body().asInputStream(), com.orange.api.paymentmanagement.web.model.Error.class);
			switch (httpstatus) {
			case 400: // Peticion no valida
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_ERROR_REQUEST.toString(), responseError.getDescription());
				break;
			case 401: // Peticion no valida
				exception = new OpenApiCustomException(HttpStatus.UNAUTHORIZED,
						OrangeCommonError.INVALID_CREDENTIALS.toString());
				break;
			case 404: // Recurso LOGICO no encontrado: podemos propagar la respuesta del servicio de
						// integracion, o bien crear OpenApiNotFoundException
				exception = new OpenApiCustomException(HttpStatus.NOT_FOUND,
						OpenApiNotFoundException.OrangeCommonError.RESOURCE_NOT_FOUND.toString(),
						responseError.getDescription());
				break;
			case 500: // Error en el servicio: Si corresponde, realizar tratamiento (ERRORES
						// FUNCIONALES SERVICIO)
			case 502: // Error en el backend: Si corresponde, realizar tratamiento (ERRORES
						// FUNCIONALES BACKEND)
			case 504: // Backend no disponible
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_ERROR_RESPONSE.toString(), responseError.getDescription());
				break;
			case 503: // Servicio no disponible
				exception = new OpenApiCustomException(HttpStatus.GATEWAY_TIMEOUT,
						CommonServiceErrors.SERVICE_UNAVAILABLE.toString());
				break;
			default:
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_ERROR_CALL.toString(), responseError.getDescription());
				break;
			}
		} catch (Exception e) {
			switch (httpstatus) {
			case 400: // Peticion no valida
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_ERROR_REQUEST.toString());
				break;
			case 404: // Recurso FISICO no encontrado
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_UNABLE_CONNECT.toString());
				break;
			case 503: // Servicio de integracion no disponible
				exception = new OpenApiCustomException(HttpStatus.GATEWAY_TIMEOUT,
						CommonServiceErrors.SERVICE_UNAVAILABLE.toString());
				break;
			default:
				log.error("Error desconocido en la llamada del servicio: {}", methodKey,
						super.decode(methodKey, response));
				exception = new OpenApiCustomException(HttpStatus.INTERNAL_SERVER_ERROR,
						CommonServiceErrors.SERVICE_ERROR_CALL.toString());
				break;
			}
		}
		log.error("Error en la respuesta del servicio: {}", methodKey, exception);
		return exception;
	}
}