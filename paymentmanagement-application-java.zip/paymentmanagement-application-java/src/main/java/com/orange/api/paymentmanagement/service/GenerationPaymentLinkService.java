package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface GenerationPaymentLinkService {
	
	
	/**
	 * This service generate paymentLink
	 * @param payment
	 * @param zapp
	 * @param zlogin
	 * @return
	 */
	Payment generationPaymentLink(Payment payment, String app, String zlogin);

}