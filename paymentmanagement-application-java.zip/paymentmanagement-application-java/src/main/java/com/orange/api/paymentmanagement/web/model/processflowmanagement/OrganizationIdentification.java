package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * OrganizationIdentification
 */
@Data
@Validated
@JsonInclude(Include.NON_NULL)
public class OrganizationIdentification implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("identificationId")
	private String identificationId;

	@JsonProperty("identificationType")
	private String identificationType;
}