package com.orange.api.paymentmanagement.web.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.service.PaymentManagementService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.validations.PaymentManagementValidations;
import com.orange.api.paymentmanagement.web.api.PaymentManagementApi;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;
import com.orange.openapiosp.boot.security.jwt.service.OpenApiSecurityService;
import com.orange.openapiosp.boot.security.jwt.util.JwtClaim;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
public class PaymentManagementApiController implements PaymentManagementApi {

    private final OpenApiSecurityService securityService;

    private final PaymentManagementService paymentManagementService;

    private ObjectMapper mapper;

    @Override
    public ResponseEntity<Payment> paymentCreate(Payment body, String authorizationHeader) {

        mapper = new ObjectMapper();

        try {
            log.info(Constants.LOG_ENTRADA_CONTROLLER
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        ResponseEntity<Payment> response;
        Object zApp = securityService.getByClaimsName(JwtClaim.Z_APP);
        Object zLogin = securityService.getByClaimsName(JwtClaim.Z_LOGIN);
        Object zCallerIp = securityService.getByClaimsName(JwtClaim.Z_CALLER_IP);

        if (!CollectionUtils.isEmpty(body.getCharacteristic()) && !StringUtils.isEmpty(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.CHANNEL))) {
            zApp = PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.CHANNEL);
        }

        switch (body.getType()) {
            case Constants.E_PAYMENT:
                PaymentManagementValidations.validatePostPayment(body);
                response = paymentManagementService.generationPaymentLink(body, zApp.toString(),
                        zLogin.toString());
                break;
            case Constants.MP_PAYMENT:
                PaymentManagementValidations.validatePostPayment(body);
                response = paymentManagementService.generationPaymentMarketPlace(body, zApp.toString(),
                        zLogin.toString());
                break;
            case Constants.E_PREAUTH_PAYMENT:
                PaymentManagementValidations.validatePostPayment(body);
                response = paymentManagementService.generationPreauthorizationPaymentLink(body, zApp.toString(),
                        zLogin.toString(), zCallerIp.toString());
                break;
            case Constants.IFRAME_PREAUTH_PAYMENT:
                PaymentManagementValidations.validatePostIframe(body);
                response = paymentManagementService.generationPreauthorizationIframe(body, zApp.toString(), zLogin.toString(), zCallerIp.toString());
                break;
            case Constants.IFRAME_SCHEDULED_PAYMENT:
                PaymentManagementValidations.validatePostScheduledIframe(body);
                response = paymentManagementService.generationScheduledIframe(body, zApp.toString(), zLogin.toString(), zCallerIp.toString());
                break;
            case Constants.SCHEDULED_PAYMENT_PROCCESING:
                PaymentManagementValidations.validateTransferFile(body);
                response = paymentManagementService.generationProccesingFile(body, zApp.toString(), authorizationHeader);
                break;
            case Constants.SCHEDULED_PAYMENT_VALIDATING:
                PaymentManagementValidations.validateTransferFile(body);
                response = paymentManagementService.generationValidatingFile(body, zApp.toString(), authorizationHeader);
                break;
            case Constants.TOKEN_PAYMENT:
                PaymentManagementValidations.validatePostTokenPayment(body);
                response = paymentManagementService.generationTokenPayment(body, zApp.toString(), zLogin.toString(),
                        zCallerIp.toString());
                break;
            default:
                PaymentManagementValidations.validatePostIframe(body);
                response = paymentManagementService.generationIframe(body, zApp.toString(), zLogin.toString());
        }

        mapper = new ObjectMapper();

        try {
            log.info(Constants.LOG_SALIDA_CONTROLLER
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return response;
    }

    @Override
    public ResponseEntity<List<Payment>> paymentFind(String type, String characteristicName, String characteristicValue,
                                                     String payerReferredType,
                                                     String payerIndividualIdentificationIdentificationId,
                                                     String payerIndividualIdentificationIdentificationType,
                                                     String payerOrganizationIdentificationIdentificationId,
                                                     String payerOrganizationIdentificationIdentificationType,
                                                     String paymentItemItemId, String paymentItemItemRole) {
        ResponseEntity<List<Payment>> response = null;
        String typeDocument = null;
        String idDocument = null;
        String phoneNumber = null;
        PaymentManagementValidations.validatePaymentFind(characteristicName, characteristicValue, payerReferredType,
                payerIndividualIdentificationIdentificationId, payerIndividualIdentificationIdentificationType,
                payerOrganizationIdentificationIdentificationId, payerOrganizationIdentificationIdentificationType,
                paymentItemItemId, paymentItemItemRole);

        if (Constants.MP_PAYMENT.equalsIgnoreCase(type)) {
            if (StringUtils.isNotEmpty(payerReferredType)) {
                typeDocument = Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payerReferredType)
                        ? payerIndividualIdentificationIdentificationType
                        : payerOrganizationIdentificationIdentificationType;
                idDocument = Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payerReferredType)
                        ? payerIndividualIdentificationIdentificationId
                        : payerOrganizationIdentificationIdentificationId;
            } else {
                phoneNumber = Constants.MSISDN.equalsIgnoreCase(characteristicName) ? characteristicValue : null;
            }
            response = paymentManagementService.searchPaymentMarketPlace(payerReferredType, typeDocument,
                    idDocument, phoneNumber);
        }

        mapper = new ObjectMapper();

        try {
            log.info(Constants.LOG_SALIDA_CONTROLLER
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return response;
    }

    @Override
    public ResponseEntity<Payment> paymentGet(String id, String type) {
        PaymentManagementValidations.validateIdPaymentLink(id);
        return paymentManagementService.statusPaymentLink(id, type);
    }

    @Override
    public ResponseEntity<Payment> paymentPatch(String id, Payment body) {
        mapper = new ObjectMapper();

        try {
            log.info(Constants.LOG_ENTRADA_CONTROLLER
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        ResponseEntity<Payment> response = handleFlow(body, id);

        mapper = new ObjectMapper();

        try {
            log.info(Constants.LOG_SALIDA_CONTROLLER
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void cleanDb() {
        paymentManagementService.cleanDb();
    }

    @Override
    public ResponseEntity<byte[]> paymentReportCsv(String startDate, String endDate) {
        return paymentManagementService.paymentReportCsvGenerate(startDate, endDate);
    }

    private ResponseEntity<Payment> handleFlow(Payment body, String id) {
        if (StringUtils.isNotEmpty(body.getType()) && Constants.PAYMENT_LINK_TYPE_CANCELLATION.equalsIgnoreCase(body.getType())) {
            return handleType(body, id);
        } else if (StringUtils.isNotEmpty(body.getStatus())) {
            return handleStatus(body, id);
        }
        return paymentManagementService.updateStatusPayment(id, body);
    }

    private ResponseEntity<Payment> handleStatus(Payment body, String id) {
        ResponseEntity<Payment> response = null;
        if (StringUtils.isNotEmpty(body.getStatus()) && Constants.CANCELLED.equalsIgnoreCase(body.getStatus())) {
            PaymentManagementValidations.validatePostPaymentAnulationAndReturned(body);
            response = paymentManagementService.paymentLinkAnnulation(body, id);
        } else if (StringUtils.isNotEmpty(body.getStatus())
                && Constants.STATUS_RETURNED.equalsIgnoreCase(body.getStatus())) {
            PaymentManagementValidations.validatePostPaymentAnulationAndReturned(body);
            response = paymentManagementService.paymentReturnMarketPlace(body, id);
        } else if (StringUtils.isNotEmpty(body.getStatus()) && Constants.PREAUTH_CONFIRMED.equalsIgnoreCase(body.getStatus())) {
            response = paymentManagementService.confirmationPreauthorizationPayment(body, id);
        } else if (StringUtils.isNotEmpty(body.getStatus()) && Constants.PREAUTH_CANCELLED.equalsIgnoreCase(body.getStatus())) {
            response = paymentManagementService.cancellationPreauthorizationPayment(body, id);
        } else if (StringUtils.isNotEmpty(body.getStatus()) && !Constants.CANCELLED.equalsIgnoreCase(body.getStatus())
                && !Constants.STATUS_RETURNED.equalsIgnoreCase(body.getStatus())) {
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        } else {
            response = paymentManagementService.updateStatusPayment(id, body);
        }
        return response;
    }

    private ResponseEntity<Payment> handleType(Payment body, String id) {
        Object zLogin = securityService.getByClaimsName(JwtClaim.Z_LOGIN);
        return paymentManagementService.paymentLinkCancellation(body, id, zLogin.toString());
    }
}