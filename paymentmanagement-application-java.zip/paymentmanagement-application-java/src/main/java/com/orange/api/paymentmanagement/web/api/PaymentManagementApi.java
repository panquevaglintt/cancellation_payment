package com.orange.api.paymentmanagement.web.api;

import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.orange.api.paymentmanagement.web.model.Error;
import com.orange.api.paymentmanagement.web.model.Payment;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@Tag(name = "PaymentManagement")
public interface PaymentManagementApi {

	@Operation(operationId = "paymentGet", summary = "This operation retrieves a Payment entity.", tags = { "Payment" })
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = Payment.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@GetMapping(value = "/payment/{id}", produces = {
			"application/json;charset=utf-8" })
	ResponseEntity<Payment> paymentGet(@PathVariable("id") String id, @RequestParam(value = "type", required = false) String type);

	@Operation(operationId = "paymentFind", summary = "This operation lists Payment entities.", tags = { "Payment" })
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Payment.class)))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@GetMapping(value = "/payment", produces = { "application/json;charset=utf-8" })
	ResponseEntity<List<Payment>> paymentFind(@Valid @RequestParam(value = "type", required = false) String type,
			 @RequestParam(value = "characteristic.name", required = false) String characteristicName,
			 @RequestParam(value = "characteristic.value", required = false) String characteristicValue,
			 @RequestParam(value = "payer.referredType", required = false) String payerReferredType,
			 @RequestParam(value = "payer.individualIdentification.identificationId", required = false) String payerIndividualIdentificationIdentificationId,
			 @RequestParam(value = "payer.individualIdentification.identificationType", required = false) String payerIndividualIdentificationIdentificationType,
			 @RequestParam(value = "payer.organizationIdentification.identificationId", required = false) String payerOrganizationIdentificationIdentificationId,
			 @RequestParam(value = "payer.organizationIdentification.identificationType", required = false) String payerOrganizationIdentificationIdentificationType,
			 @RequestParam(value = "paymentItem.item.id", required = false) String paymentItemItemId,
			 @RequestParam(value = "paymentItem.item.role", required = false) String paymentItemItemRole);

	@Operation(summary = "This operation creates a Payment entity.", operationId = "paymentCreate", description = "This operation creates a Payment entity.", tags = {
			"Payment", })
	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "Created", content = @Content(schema = @Schema(implementation = Payment.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@PostMapping(value = "/payment", produces = { "application/json;charset=utf-8" }, consumes = {
			"application/json;charset=utf-8" })
	ResponseEntity<Payment> paymentCreate(@RequestBody Payment body , @RequestHeader(HttpHeaders.AUTHORIZATION) String authorizationHeader);

	@Operation(operationId = "paymentPatch", summary = "This operation partially updates a Payment entity.", tags = {
			"Payment" })
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = Payment.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@PatchMapping(value = "/payment/{id}", produces = { "application/json;charset=utf-8" }, consumes = {
			"application/json;charset=utf-8" })
	ResponseEntity<Payment> paymentPatch(@PathVariable("id") String id, @Valid @RequestBody Payment body);

	@Operation(operationId = "Clean outdated DB registries", description = "paymentCleanDB", tags = {
			"Payment" })
	@ApiResponses(value = { 
		    @ApiResponse(responseCode = "204", description = "No Content", content = @Content(schema = @Schema(implementation = Payment.class))),
		    @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
		    @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Error.class))),
		    @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@PostMapping(value = "/payment/clean", produces = { "application/json;charset=utf-8" })
	void cleanDb();
	
	@Operation(summary = "Creates a CSV", description = "This operation modifies the consumption buckets.", tags = {})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Ok", content = @Content(schema = @Schema(implementation = Payment.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = Error.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = Error.class))) })
	@GetMapping(value = "/paymentReportCsv", produces = {
			"application/json;charset=utf-8" })
	ResponseEntity<byte[]> paymentReportCsv(@RequestParam(value = "startDate") String startDate,
			@RequestParam(value = "endDate") String endDate);

}