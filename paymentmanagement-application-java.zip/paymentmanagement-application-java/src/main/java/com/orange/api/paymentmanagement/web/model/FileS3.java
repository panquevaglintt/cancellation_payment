package com.orange.api.paymentmanagement.web.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FileS3 {

	@JsonProperty(value = "name")
	private String name;
	@JsonProperty(value = "text")
	private String text;
}
