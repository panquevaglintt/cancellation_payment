package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.orange.api.paymentmanagement.configuration.OAuthFeignConfig;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;

@FeignClient(name = "paymentmethodmanagementoauth", url = "${spring.cloud.openfeign.client.config.paymentmethodmanagementoauth.url}", configuration = OAuthFeignConfig.class)
public interface PaymentMethodManagementClientOauth {

    @PatchMapping(path = "/v1/paymentMethod/{id}")
    PaymentMethod updatePaymentMethod(@PathVariable("id") String id, @RequestBody PaymentMethod inputJson);

    @GetMapping(path = "/v1/paymentMethod/{id}")
    PaymentMethod getPaymentMethod(@PathVariable(value = "id") String id, @RequestParam("type") String type);

    @PostMapping(path = "/v1/paymentMethod")
    PaymentMethod createPaymentMethod(@RequestBody PaymentMethod inputJson);
}

