package com.orange.api.paymentmanagement.service.impl;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.BpmAmortizationManagementClient;
import com.orange.api.paymentmanagement.feign.client.BpmPfSalesClient;
import com.orange.api.paymentmanagement.feign.client.BpmPrepaidTopUpManagementClient;
import com.orange.api.paymentmanagement.feign.client.BpmRecoveryManagementClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.mappers.UpdateStatusPaymentMapper;
import com.orange.api.paymentmanagement.service.UpdateStatusPaymentService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UpdateStatusPaymentServiceImpl implements UpdateStatusPaymentService {

	private PaymentRegistryRepository paymentRegistryRepository;
	private BpmAmortizationManagementClient bpmAmortizationManagement;
	private BpmRecoveryManagementClient bpmRecoveryManagement;
	private BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement;
	private BpmPfSalesClient bpmPfSalesClient;
	private PaymentMethodManagementClient paymentMethodManagementClient;
	private ObjectMapper mapper;

	@Autowired
    public UpdateStatusPaymentServiceImpl(PaymentRegistryRepository paymentRegistryRepository,
            BpmAmortizationManagementClient bpmAmortizationManagement,
            BpmRecoveryManagementClient bpmRecoveryManagement,
            BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement, BpmPfSalesClient bpmPfSalesClient,
            PaymentMethodManagementClient paymentMethodManagementClient) {
        this.paymentRegistryRepository = paymentRegistryRepository;
        this.bpmAmortizationManagement = bpmAmortizationManagement;
        this.bpmRecoveryManagement = bpmRecoveryManagement;
        this.bpmPrepaidTopUpManagement = bpmPrepaidTopUpManagement;
        this.bpmPfSalesClient = bpmPfSalesClient;
        this.paymentMethodManagementClient = paymentMethodManagementClient;
	}

	@Override
	public Payment updateStatusPayment(String id, Payment body) {
	    
        mapper = new ObjectMapper();
        try {
            log.info("Payment de entrada: "
                    + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

		PaymentRegistryDB paymentManagementDB = getPaymentRegistryDB(id);

		// Si es amortizacion llamamos para recuperar el id del proceso, sino lo
		// obtenemos de la BBDD
		String processId = getIdProcessAmortization(paymentManagementDB);

        TaskFlowObj taskFlowObj = null;

		switch (paymentManagementDB.getTransactiontype()) {
		case Constants.AMORTIZATION:
		    taskFlowObj = mapTaskFlow(id, body, paymentManagementDB, processId);
			this.bpmAmortizationManagement.updateStatus(processId, taskFlowObj);
			break;
		case Constants.RECOVERY:
		    taskFlowObj = mapTaskFlow(id, body, paymentManagementDB, processId);
			log.info("body de recovery: " + taskFlowObj.toString());
			if (StringUtils.isNotEmpty(paymentManagementDB.getHash())) {
				this.bpmRecoveryManagement.updateStatusIframe(processId, taskFlowObj);
			} else {
				this.bpmRecoveryManagement.updateStatus(processId, taskFlowObj);
			}
			break;
        case Constants.PURCHASE:
            taskFlowObj = new TaskFlowObj();
            UpdateStatusPaymentMapper.mapPaymentToTaskFlowObjBpmPfSales(body, taskFlowObj, paymentManagementDB, id);
            mapper = new ObjectMapper();
            try {
                log.info("Peticion bpmPfSalesClient: "
                        + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(taskFlowObj));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            if (StringUtils.isNotEmpty(paymentManagementDB.getHash())) {
                this.bpmPfSalesClient.updateStatusPurchaseIframe(processId, taskFlowObj);
            } else {
                this.bpmPfSalesClient.updateStatusPurchase(processId, taskFlowObj);
            }
            break;
        case Constants.TOP_UP:
            taskFlowObj = mapTaskFlow(id, body, paymentManagementDB, processId);
            this.bpmPrepaidTopUpManagement.updateStatusIframe(processId, taskFlowObj);
            break;
        case Constants.SCHEDULED_TOP_UP:
            log.info("Se genera la llamada al PaymentMethod para registrar el metodo de pago");
            PaymentMethod paymentMethodInput = UpdateStatusPaymentMapper.mapCreatePaymentMethod(body, paymentManagementDB);
            
            mapper = new ObjectMapper();
            try {
                log.info("Peticion al PaymentMethod para registrar el metodo de pago: "
                        + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(paymentMethodInput));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }                                
            PaymentMethod paymentMethod = paymentMethodManagementClient.createPaymentMethod(paymentMethodInput);

            paymentManagementDB.setPaymentMethodId(paymentMethod.getId());
            this.paymentRegistryRepository.saveAndFlush(paymentManagementDB);

            taskFlowObj = new TaskFlowObj();
            UpdateStatusPaymentMapper.mapPaymentToTaskFlowObjbpmScheduled(body, taskFlowObj, paymentManagementDB,
                    paymentMethod);
            mapper = new ObjectMapper();
            try {
                log.info("Peticion bpmprepaidtopupmanagement actualizacion estado recarga programada: "
                        + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(taskFlowObj));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            this.bpmPrepaidTopUpManagement.updateScheduled(processId, taskFlowObj);
            break;
        }
		

        log.info("La llamada de actualizacion de estado de pago se ha realizado correctamente");
        return body;
	}

    private TaskFlowObj mapTaskFlow(String id, Payment body, PaymentRegistryDB paymentManagementDB, String processId) {
        TaskFlowObj taskFlowObj = new TaskFlowObj();
		UpdateStatusPaymentMapper.mapPaymentToTaskFlowObj(body, taskFlowObj, paymentManagementDB, id);
		UpdateStatusPaymentMapper.mapPaymentRegistryDB(paymentManagementDB, body, processId);
		this.paymentRegistryRepository.saveAndFlush(paymentManagementDB);
        return taskFlowObj;
    }

    private PaymentRegistryDB getPaymentRegistryDB(String id) {
        PaymentRegistryDB paymentManagementDB = this.paymentRegistryRepository.findByOriginOpnumber(id);
		if (ObjectUtils.isEmpty(paymentManagementDB)) {
			log.error("No se ha encontrado ningun registro en BBDD");
			throw new OpenApiNotFoundException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
		}
        return paymentManagementDB;
    }

    private String getIdProcessAmortization(PaymentRegistryDB paymentManagementDB) {
        ResponseEntity<String> responseGet = null;
		String processId = null;
		if (Constants.AMORTIZATION.equalsIgnoreCase(paymentManagementDB.getTransactiontype())) {
			responseGet = this.bpmAmortizationManagement.getProccessFlow(paymentManagementDB.getVapId());
			processId = UpdateStatusPaymentMapper.mapProcessId(responseGet);
			log.info("Se ha realizado la llamada GET al bpmamortizationmanagement para recoger el id del proceso: "
					+ processId);
		} else {
			processId = paymentManagementDB.getProcessflowId();
			log.info("Obtenemos el id del proceso de BBDD:  " + processId);
		}
        return processId;
    }

}