package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;


public interface GenerationScheduledIframeService {

    Payment generationScheduledIframe(Payment payment, String app, String zlogin, String zCallerIp);

}