package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.io.Serializable;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseCancellationPaymentLink implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("datosCliente")
    private DatosCliente clientData;

    @JsonProperty("fxAltaLink")
    private Object fxAltaLink;

    @JsonProperty("idLink")
    private String idLink;

    @JsonProperty("idioma")
    private String language;

    @JsonProperty("numOpOrigen")
    private String numOpOrigin;

    @JsonProperty("numOperacionNPP")
    private String numOperationNPP;

    @JsonProperty("parametrosAdicionales")
    private ParametrosAdicionales additionalParams;

    @JsonProperty("usuario")
    private String user;

    @JsonProperty("resultadoOperacion")
    private ResultadoOperacion operationResult;


}
