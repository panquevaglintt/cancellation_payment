package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskFlow implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("state")
	private String state;

	@JsonProperty("taskFlowSpecification")
	private String taskFlowSpecification;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}