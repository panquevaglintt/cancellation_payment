package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessInstanceResponseObj implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("id")
	private String id;

	@JsonProperty("businessKey")
	private String businessKey;

	@JsonProperty("processDefinitionId")
	private String processDefinitionId;

	@JsonProperty("processDefinitionKey")
	private String processDefinitionKey;

	@JsonProperty("processDefinitionName")
	private String processDefinitionName;

	@JsonProperty("processDefinitionVersion")
	private Integer processDefinitionVersion;

	@JsonProperty("startTime")
	private String startTime;

	@JsonProperty("endTime")
	private String endTime;

	@JsonProperty("removalTime")
	private String removalTime;

	@JsonProperty("durationInMillis")
	private Integer durationInMillis;

	@JsonProperty("startUserId")
	private String startUserId;

	@JsonProperty("startActivityId")
	private String startActivityId;

	@JsonProperty("deleteReason")
	private String deleteReason;

	@JsonProperty("rootProcessInstanceId")
	private String rootProcessInstanceId;

	@JsonProperty("superProcessInstanceId")
	private String superProcessInstanceId;

	@JsonProperty("superCaseInstanceId")
	private String superCaseInstanceId;

	@JsonProperty("caseInstanceId")
	private String caseInstanceId;

	@JsonProperty("tenantId")
	private String tenantId;

	@JsonProperty("state")
	private String state;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}