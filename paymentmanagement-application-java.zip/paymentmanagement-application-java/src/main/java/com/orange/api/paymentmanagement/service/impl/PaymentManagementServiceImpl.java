package com.orange.api.paymentmanagement.service.impl;

import java.util.List;

import com.orange.api.paymentmanagement.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.dataauthorization.aspect.DataAuthorization;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentManagementServiceImpl implements PaymentManagementService {

    private StatusPaymentLinkService statusPaymentManagementService;
    private GenerationPaymentLinkService generationPaymentManagementService;
    private GenerationPreauthorizationPaymentLinkService generationPreauthorizationPaymentManagementService;
    private PaymentLinkAnnulationService paymentLinkAnnulationService;
    private ConfirmationPreauthorizationPaymentService confirmationPreauthorizationPaymentService;
    private CancellationPreauthorizationPaymentService cancellationPreauthorizationPaymentService;
    private UpdateStatusPaymentService updateStatusPaymentService;
    private GenerationIframeService generationIframeService;
    private GenerationPreauthorizationIframeService generationPreauthorizationIframeService;
    private PaymentReportService paymentReportService;
    private GenerationPaymentMarketPlaceService generationPaymentMarketPlaceService;
    private SearchPaymentMarketPlaceService searchPaymentMarketPlaceService;
    private PaymentReturnedMarketPlaceService paymentReturnedMarketPlaceService;
    private CleanDBService cleanDBService;
    private TransferFileService transferFileService;
    private GenerationScheduledIframeService generationScheduledIframeService;
    private GenerationTokenPaymentService generationTokenPaymentService;
    private PaymentLinkCancellationService paymentLinkCancellationService;

    @Autowired
    public PaymentManagementServiceImpl(StatusPaymentLinkService statusPaymentManagementService,
                                        GenerationPaymentLinkService generationPaymentManagementService,
                                        PaymentLinkAnnulationService paymentLinkAnnulationService,
                                        UpdateStatusPaymentService updateStatusPaymentService, GenerationIframeService generationIframeService,
                                        PaymentReportService paymentReportService,
                                        GenerationPaymentMarketPlaceService generationPaymentMarketPlaceService,
                                        SearchPaymentMarketPlaceService searchPaymentMarketPlaceService,
                                        PaymentReturnedMarketPlaceService paymentReturnedMarketPlaceService, CleanDBService cleanDBService,
                                        GenerationPreauthorizationPaymentLinkService generationPreauthorizationPaymentManagementService,
                                        GenerationPreauthorizationIframeService generationPreauthorizationIframeService,
                                        ConfirmationPreauthorizationPaymentService confirmationPreauthorizationPaymentService,
                                        CancellationPreauthorizationPaymentService cancellationPreauthorizationPaymentService,
                                        TransferFileService transferFileService, GenerationScheduledIframeService generationScheduledIframeService,
                                        GenerationTokenPaymentService generationTokenPaymentService,
                                        PaymentLinkCancellationService paymentLinkCancellationService) {
        this.statusPaymentManagementService = statusPaymentManagementService;
        this.generationPaymentManagementService = generationPaymentManagementService;
        this.paymentLinkAnnulationService = paymentLinkAnnulationService;
        this.updateStatusPaymentService = updateStatusPaymentService;
        this.generationIframeService = generationIframeService;
        this.paymentReportService = paymentReportService;
        this.generationPaymentMarketPlaceService = generationPaymentMarketPlaceService;
        this.searchPaymentMarketPlaceService = searchPaymentMarketPlaceService;
        this.paymentReturnedMarketPlaceService = paymentReturnedMarketPlaceService;
        this.cleanDBService = cleanDBService;
        this.generationPreauthorizationPaymentManagementService = generationPreauthorizationPaymentManagementService;
        this.generationPreauthorizationIframeService = generationPreauthorizationIframeService;
        this.confirmationPreauthorizationPaymentService = confirmationPreauthorizationPaymentService;
        this.cancellationPreauthorizationPaymentService = cancellationPreauthorizationPaymentService;
        this.transferFileService = transferFileService;
        this.generationScheduledIframeService = generationScheduledIframeService;
        this.generationTokenPaymentService = generationTokenPaymentService;
        this.paymentLinkCancellationService = paymentLinkCancellationService;
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> paymentLinkAnnulation(Payment payment, String numOrigin) {
        log.info("Acceso al servicio de anulación de PaymentLink.");
        Payment paymentResponse = this.paymentLinkAnnulationService.paymentLinkAnnulation(payment, numOrigin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> confirmationPreauthorizationPayment(Payment payment, String numOrigin) {
        log.info("Acceso al servicio de confirmación de la preautorización de un pago.");
        Payment paymentResponse = this.confirmationPreauthorizationPaymentService.confirmationPreauthorizationPayment(payment, numOrigin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> cancellationPreauthorizationPayment(Payment payment, String numOrigin) {
        log.info("Acceso al servicio de cancelación de la preautorización de un pago.");
        Payment paymentResponse = this.cancellationPreauthorizationPaymentService.cancellationPreauthorizationPayment(payment, numOrigin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    public ResponseEntity<Payment> paymentLinkCancellation(Payment payment, String numOrigin, String zLogin) {
        log.info("Acceso al servicio de cancelación de un PaymentLink.");
        Payment paymentResponse = this.paymentLinkCancellationService.paymentLinkCancellation(payment, numOrigin, zLogin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> generationPaymentLink(Payment payment, String zapp, String zlogin) {
        log.info("Acceso al servicio de generacion del PaymentLink.");
        Payment paymentResponse = this.generationPaymentManagementService.generationPaymentLink(payment, zapp, zlogin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> generationPreauthorizationPaymentLink(Payment payment, String zapp, String zlogin, String zCallerIp) {
        log.info("Acceso al servicio de generacion del PaymentLink por preautorización.");
        Payment paymentResponse = this.generationPreauthorizationPaymentManagementService.generationPreauthorizationPaymentLink(payment, zapp, zlogin, zCallerIp);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> statusPaymentLink(String id, String type) {
        log.info("Acceso al servicio para recupera el estado del PaymentLink.");
        Payment payment = this.statusPaymentManagementService.statusPaymentLink(id, type);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(payment);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> updateStatusPayment(String id, Payment body) {
        log.info("Acceso al servicio de actualizacion de estado de pago");
        Payment payment = this.updateStatusPaymentService.updateStatusPayment(id, body);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(payment);
    }

    @Override
    public ResponseEntity<Payment> generationIframe(Payment payment, String zApp, String zLogin) {
        log.info("Acceso al servicio de generacion del Iframe.");
        Payment paymentResponse = this.generationIframeService.generationIframe(payment, zApp, zLogin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    public ResponseEntity<Payment> generationPreauthorizationIframe(Payment payment, String zApp, String zLogin, String zCallerIp) {
        log.info("Acceso al servicio de generacion del Iframe por preautorización..");
        Payment paymentResponse = this.generationPreauthorizationIframeService.generationPreauthorizationIframe(payment, zApp, zLogin, zCallerIp);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    public ResponseEntity<Payment> generationScheduledIframe(Payment payment, String zApp, String zLogin, String zCallerIp) {
        log.info("Acceso al servicio de generacion del Iframe recarga programada..");
        Payment paymentResponse = this.generationScheduledIframeService.generationScheduledIframe(payment, zApp, zLogin, zCallerIp);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    public ResponseEntity<Payment> generationProccesingFile(Payment payment, String zApp, String authorizationHeader) {
        log.info("Acceso al servicio de procesamiento del fichero de recargas programadas");
        Payment paymentResponse = this.transferFileService.paymentProcessingFile(payment, zApp, authorizationHeader);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    public ResponseEntity<Payment> generationValidatingFile(Payment payment, String zApp, String authorizationHeader) {
        log.info("Acceso al servicio de validacion del fichero de recargas programadas");
        Payment paymentResponse = this.transferFileService.paymentValidatingFile(payment, zApp, authorizationHeader);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    public ResponseEntity<Payment> generationTokenPayment(Payment payment, String zApp, String zLogin, String zCallerIp) {
        log.info("Acceso al servicio de recarga manual..");
        Payment paymentResponse = this.generationTokenPaymentService.generationTokenPayment(payment, zApp, zLogin, zCallerIp);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    public ResponseEntity<byte[]> paymentReportCsvGenerate(String startDate, String endDate) {

        byte[] csvFile = paymentReportService.paymentReportCsvGenerate(startDate, endDate);
        // TODO Auto-generated method stub
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("text/csv")).body(csvFile);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> generationPaymentMarketPlace(Payment payment, String zapp, String zlogin) {
        log.info("Acceso al servicio de generacion del PaymentMarketPlace.");
        Payment paymentResponse = this.generationPaymentMarketPlaceService.generationPaymentMarketPlace(payment, zapp, zlogin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<List<Payment>> searchPaymentMarketPlace(String payerReferredType, String typeDocument, String idDocument, String phoneNumber) {
        log.info("Acceso al servicio para recuperar una lista de paymentMarketPlace.");
        List<Payment> payment = this.searchPaymentMarketPlaceService.searchPaymentMarketPlace(payerReferredType, typeDocument, idDocument, phoneNumber);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(payment);
    }

    @Override
    @DataAuthorization
    public ResponseEntity<Payment> paymentReturnMarketPlace(Payment payment, String numOrigin) {
        log.info("Acceso al servicio de devolucion de MarketPlace.");
        Payment paymentResponse = this.paymentReturnedMarketPlaceService.paymentReturnMarketPlace(payment, numOrigin);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(paymentResponse);
    }

    @Override
    @DataAuthorization
    public void cleanDb() {
        log.info("Acceso al servicio de borrado de registros antiguos en BDD.");
        cleanDBService.cleanDb();

    }
}