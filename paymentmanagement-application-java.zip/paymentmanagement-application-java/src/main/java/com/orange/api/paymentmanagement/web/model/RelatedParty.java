package com.orange.api.paymentmanagement.web.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedParty implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@referredType")
	private String referredType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("name")
	private String name;

	@JsonProperty("role")
	private String role;

	@Valid
	@JsonProperty("individualIdentification")
	private List<IndividualIdentification> individualIdentification;

	@Valid
	@JsonProperty("organizationIdentification")
	private List<OrganizationIdentification> organizationIdentification;
}