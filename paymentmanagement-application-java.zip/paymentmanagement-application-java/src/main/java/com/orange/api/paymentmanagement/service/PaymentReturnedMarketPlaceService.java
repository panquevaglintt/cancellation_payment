package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for PaymentLink cancellation service.
 */
public interface PaymentReturnedMarketPlaceService {

	/**
	 * This service performs a PaymentLink cancellation.
	 * 
	 * @param payment
	 * @param numOrigin
	 * @param zApp
	 * @return
	 */
	Payment paymentReturnMarketPlace(Payment payment, String numOrigin);
}