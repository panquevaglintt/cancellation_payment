package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

public interface ConfirmationPreauthorizationPaymentService {


	Payment confirmationPreauthorizationPayment(Payment payment, String numOrigin);
}