package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("datosCliente")
	private DatosCliente datosCliente;

	@JsonProperty("fechaOpOrigen")
	private String fechaOpOrigen;

	@JsonProperty("idioma")
	private String idioma;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("numOperacionNNP")
	private String numOperacionNNP;

	@JsonProperty("usuario")
	private String usuario;
}