package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.mappers.PaymentMarketPlaceMapper;
import com.orange.api.paymentmanagement.service.SearchPaymentMarketPlaceService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SearchPaymentMarketPlaceServiceImpl implements SearchPaymentMarketPlaceService {

	private PaymentRegistryRepository paymentRegistryRepository;

	@Autowired
	public SearchPaymentMarketPlaceServiceImpl(PaymentRegistryRepository paymentRegistryRepository) {
		this.paymentRegistryRepository = paymentRegistryRepository;
	}

	@Override
	public List<Payment> searchPaymentMarketPlace(String payerReferredType, String typeDocument, String idDocument,
			String phoneNumber) {

		List<PaymentRegistryDB> paymentRegistryDBList = new ArrayList<>();

		if (StringUtils.isNotEmpty(phoneNumber)) {
			paymentRegistryDBList = this.paymentRegistryRepository.findByPhonenumber(phoneNumber);
			if (ObjectUtils.isEmpty(paymentRegistryDBList)) {
				throwErrorFind();
			}
		} else {
			paymentRegistryDBList = this.paymentRegistryRepository.findByIdDocument(idDocument);
			if (ObjectUtils.isEmpty(paymentRegistryDBList)) {
				throwErrorFind();
			}

		}

		log.info("La llamada de consulta de paymentMarketPlace se ha realizado correctamente");

		return PaymentMarketPlaceMapper.mapRespSearchByPhonenumberAndDocumentId(paymentRegistryDBList, phoneNumber,
				idDocument, payerReferredType, typeDocument);
	}

	public void throwErrorFind() {
		log.error("No se ha encontrado ningun registro en BBDD");
		throw new OpenApiNotFoundException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
	}

}