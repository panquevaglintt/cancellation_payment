package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;

@FeignClient(name = "bpmpfsales", url = "${spring.cloud.openfeign.client.config.bpmpfsales.url}")
public interface BpmPfSalesClient {

	@PatchMapping(path = "/processFlow/salesManagement/{processFlowId}/taskFlow/update")
	ResponseEntity<String> updateStatusPurchase(@PathVariable("processFlowId") String processFlowId,
			@RequestBody TaskFlowObj inputJson);
	
    @PatchMapping(path = "/processFlow/salesManagement/{processFlowId}/taskFlow/updateIframe")
    ResponseEntity<String> updateStatusPurchaseIframe(@PathVariable("processFlowId") String processFlowId,
            @RequestBody TaskFlowObj inputJson);	

}