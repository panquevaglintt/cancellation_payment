package com.orange.api.paymentmanagement.service;

public interface PaymentReportService {

	/**
	 * This service Creates the CSV with the info in BBDD
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	byte[] paymentReportCsvGenerate(String startDate, String endDate);

}