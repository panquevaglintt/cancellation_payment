package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactMedium implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("mediumType")
	private String mediumType;

	@JsonProperty("mediumCharacteristic")
	private MediumCharacteristic characteristic;
}