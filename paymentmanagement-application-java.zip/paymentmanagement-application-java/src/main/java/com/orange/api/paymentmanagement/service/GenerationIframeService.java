package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface GenerationIframeService {
	
	
	/**
	 * This service generate paymentLink
	 * @param payment
	 * @param zapp
	 * @param zlogin
	 * @return
	 */
	Payment generationIframe(Payment payment, String app, String zlogin);

}