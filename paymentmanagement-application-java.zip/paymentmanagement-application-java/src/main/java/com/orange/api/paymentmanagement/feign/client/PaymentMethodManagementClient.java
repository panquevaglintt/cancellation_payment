package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;

@FeignClient(name = "paymentmethodmanagement", url = "${spring.cloud.openfeign.client.config.paymentmethodmanagement.url}")
public interface PaymentMethodManagementClient {

    @PatchMapping(path = "/paymentMethod/{id}")
    PaymentMethod updatePaymentMethod(@PathVariable("id") String id, @RequestBody PaymentMethod inputJson);

    @PatchMapping(path = "/paymentMethod/{id}")
    PaymentMethod updatePaymentMethodAsync(@PathVariable("id") String id, @RequestBody PaymentMethod inputJson, @RequestHeader(HttpHeaders.AUTHORIZATION) String authorizationHeader);
    
    @GetMapping(path = "/paymentMethod/{id}")
    PaymentMethod getPaymentMethod(@PathVariable(value = "id") String id, @RequestParam("type") String type);

    @GetMapping(path = "/paymentMethod/{id}")
    PaymentMethod getPaymentMethodAsync(@PathVariable(value = "id") String id, @RequestParam("type") String type, @RequestHeader(HttpHeaders.AUTHORIZATION) String authorizationHeader);
    
    @PostMapping(path = "/paymentMethod")
    PaymentMethod createPaymentMethod(@RequestBody PaymentMethod inputJson);
}