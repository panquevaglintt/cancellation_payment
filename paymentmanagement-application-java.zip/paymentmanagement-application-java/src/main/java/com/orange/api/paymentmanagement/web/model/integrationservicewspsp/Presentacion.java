package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Presentacion implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("campoExtra1")
	private Object campoExtra1;

	@JsonProperty("campoExtra2")
	private Object campoExtra2;

	@JsonProperty("campoExtra3")
	private Object campoExtra3;

	@JsonProperty("color")
	private String color;

	@JsonProperty("texto")
	private String texto;

	@JsonProperty("textoBoton")
	private String textoBoton;

	@JsonProperty("textoCvv")
	private String textoCvv;

	@JsonProperty("textoFxCaducidad")
	private String textoFxCaducidad;

	@JsonProperty("textoMascara")
	private String textoMascara;

	@JsonProperty("textoTarjeta")
	private String textoTarjeta;

	@JsonProperty("textoTitulo")
	private String textoTitulo;

	@JsonProperty("urlLogo")
	private String urlLogo;
}