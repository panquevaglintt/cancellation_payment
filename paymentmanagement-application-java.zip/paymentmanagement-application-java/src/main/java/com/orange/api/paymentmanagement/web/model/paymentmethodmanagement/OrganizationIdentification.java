package com.orange.api.paymentmanagement.web.model.paymentmethodmanagement;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrganizationIdentification   {
  
  private String identificationId = null;
  private String identificationType = null;

  
  /**
   **/
  public OrganizationIdentification identificationId(String identificationId) {
    this.identificationId = identificationId;
    return this;
  }
  
  
  @JsonProperty("identificationId")
  public String getIdentificationId() {
    return identificationId;
  }
  public void setIdentificationId(String identificationId) {
    this.identificationId = identificationId;
  }

  
  /**
   **/
  public OrganizationIdentification identificationType(String identificationType) {
    this.identificationType = identificationType;
    return this;
  }
  
  
  @JsonProperty("identificationType")
  public String getIdentificationType() {
    return identificationType;
  }
  public void setIdentificationType(String identificationType) {
    this.identificationType = identificationType;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrganizationIdentification organizationIdentification = (OrganizationIdentification) o;
    return Objects.equals(this.identificationId, organizationIdentification.identificationId) &&
        Objects.equals(this.identificationType, organizationIdentification.identificationType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(identificationId, identificationType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrganizationIdentification {\n");
    
    sb.append("    identificationId: ").append(toIndentedString(identificationId)).append("\n");
    sb.append("    identificationType: ").append(toIndentedString(identificationType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

