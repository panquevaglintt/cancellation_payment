package com.orange.api.paymentmanagement.mappers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosPrevia;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionCancelacionRequest;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionCancelacionResponse;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class CancelationPreauthorizationPaymentMapper {


    public static void mapPaymentToPreautorizacionCancellationRequest(Payment payment, PreautorizacionCancelacionRequest preautorizacionCancelacionRequest,
            PaymentRegistryDB cancelationPaymentRegistryDB, FixedValuesDB fixedValues) {

        preautorizacionCancelacionRequest.setDatosCliente(mapClientData(fixedValues, cancelationPaymentRegistryDB));
        preautorizacionCancelacionRequest.setFechaOpOrigen(mapDate());
        preautorizacionCancelacionRequest.setIdioma(fixedValues.getLanguage());
        preautorizacionCancelacionRequest.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        preautorizacionCancelacionRequest.setImporte((long)Double.parseDouble(cancelationPaymentRegistryDB.getAmount()));
        preautorizacionCancelacionRequest.setMoneda(fixedValues.getCurrency());
        preautorizacionCancelacionRequest.setParametrosAdicionales(mapAdditionalParameters(payment, cancelationPaymentRegistryDB));
        preautorizacionCancelacionRequest.setDatosPrevia(mapPreviousData(cancelationPaymentRegistryDB));
        log.info("Se va a generar la cancelacion de preautorizacion con Numero Operacion Origen: " + preautorizacionCancelacionRequest.getNumOpOrigen());

    }

    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    private static DatosPrevia mapPreviousData(PaymentRegistryDB cancelationPaymentRegistryDB) {
        DatosPrevia datosPrevia1 = new DatosPrevia();

        datosPrevia1.setCoComercio(cancelationPaymentRegistryDB.getCommercialCode());
        datosPrevia1.setCoTerminal(cancelationPaymentRegistryDB.getTerminalCode());
        datosPrevia1.setFechaOpOrigen(cancelationPaymentRegistryDB.getPaymentUpdate());
        datosPrevia1.setNumOpOrigen(cancelationPaymentRegistryDB.getOriginOpnumber());

        return datosPrevia1;
    }

    private static ParametrosAdicionales mapAdditionalParameters(Payment payment, PaymentRegistryDB cancelationPaymentRegistryDB) {
        ParametrosAdicionales parametros = new ParametrosAdicionales();
        List<Entry> listEntry = new ArrayList<Entry>();

        Entry entry1 = new Entry();
        entry1.setKey(Constants.MSISDN);
        entry1.setValue(cancelationPaymentRegistryDB.getPhonenumber());
        listEntry.add(entry1);

        entry1 = new Entry();
        entry1.setKey(Constants.DOCUMENTO);
        entry1.setValue(cancelationPaymentRegistryDB.getIdDocument());
        listEntry.add(entry1);

        entry1 = new Entry();
        entry1.setKey(Constants.USUARIO);
        entry1.setValue(cancelationPaymentRegistryDB.getUserId());
        listEntry.add(entry1);

        entry1 = new Entry();
        entry1.setKey(Constants.PEDIDOCRM);
        entry1.setValue(cancelationPaymentRegistryDB.getProcessflowId());
        listEntry.add(entry1);
        
        parametros.setEntry(listEntry);

        return parametros;
    }

    private static DatosCliente mapClientData(FixedValuesDB fixedValues, PaymentRegistryDB cancelationPaymentRegistryDB) {
        DatosCliente datosCliente1 = new DatosCliente();

        datosCliente1.setCoCliente(fixedValues.getClientCode());
        if (cancelationPaymentRegistryDB.getCommercialCode() != null) {
            datosCliente1.setCoComercio(cancelationPaymentRegistryDB.getCommercialCode());
        } else {
            datosCliente1.setCoComercio(fixedValues.getCommercialCode());
        }
        datosCliente1.setCoTerminal(fixedValues.getTerminalCode());
        datosCliente1.setPalabraClave(fixedValues.getKeyword());

        return datosCliente1;
    }

    public static void mapPaymentRegistry(PaymentRegistryDB cancelationPaymentRegistryDB, PreautorizacionCancelacionResponse responseConfirmationAndCancellation,
            PreautorizacionCancelacionRequest requestWS, String status, String statusDescription) {

        cancelationPaymentRegistryDB.setStatus(status);
        cancelationPaymentRegistryDB.setStatusDescription(statusDescription);
        mapResultOperation(responseConfirmationAndCancellation.getResultadoOperacion(), cancelationPaymentRegistryDB);
    }

    public static void mapPaymentRegistryError(PaymentRegistryDB cancelationPaymentRegistryDB, PreautorizacionCancelacionRequest requestWS,
            String status, String statusDescription) {

        cancelationPaymentRegistryDB.setStatus(status);
        cancelationPaymentRegistryDB.setStatusDescription(statusDescription);
        mapResultOperationError(cancelationPaymentRegistryDB);
    }

    private static void mapResultOperation(ResultadoOperacion resultado, PaymentRegistryDB cancelationPaymentRegistryDB) {

        if (Constants.ENRQ_PREV_NO_ENCONTRADA.equalsIgnoreCase(resultado.getCodigo())) {
            cancelationPaymentRegistryDB.setStatus(Constants.PREAUTH_EXPIRED);
            cancelationPaymentRegistryDB.setStatusDescription(Constants.EXPIRED_DESC);
            cancelationPaymentRegistryDB.setResultDescription(Constants.KO);
        } else if (!Constants.OK.equalsIgnoreCase(resultado.getCodigo())) {
            cancelationPaymentRegistryDB.setStatus(Constants.PREAUTH_CANCELLED_ERROR);
            cancelationPaymentRegistryDB.setStatusDescription(Constants.PREAUTH_CANCELLED_ERROR_DESC);
            cancelationPaymentRegistryDB.setResultDescription(Constants.KO);
        }

    }

    private static void mapResultOperationError(PaymentRegistryDB cancelationPaymentRegistryDB) {

        if (Constants.PREAUTH_CANCELLED_TIMEOUT_DESC.equalsIgnoreCase(cancelationPaymentRegistryDB.getStatusDescription())) {
            cancelationPaymentRegistryDB.setAnnulationResult(Constants.ANNULALATION_TIMEOUT_RESUL);
            cancelationPaymentRegistryDB.setAnnulationDescription(Constants.ANNULATION_TIMEOUT_DESC);
        } else {

            cancelationPaymentRegistryDB.setAnnulationResult(Constants.ANULLATION_ERROR_RESULT);
            cancelationPaymentRegistryDB.setAnnulationDescription(Constants.ANULLATION_ERROR_DESC);
        }
        cancelationPaymentRegistryDB.setResultDescription(Constants.KO);

    }

}