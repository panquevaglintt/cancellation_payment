package com.orange.api.paymentmanagement.web.model.paymentmethodmanagement;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorDetail   {
  
  private String code = null;
  private String message = null;
  private String desciption = null;
  private String infoURL = null;

  
  /**
   **/
  public ErrorDetail code(String code) {
    this.code = code;
    return this;
  }
  
  
  @JsonProperty("code")
  public String getCode() {
    return code;
  }
  public void setCode(String code) {
    this.code = code;
  }

  
  /**
   **/
  public ErrorDetail message(String message) {
    this.message = message;
    return this;
  }
  
  
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }

  
  /**
   **/
  public ErrorDetail desciption(String desciption) {
    this.desciption = desciption;
    return this;
  }
  
  
  @JsonProperty("desciption")
  public String getDesciption() {
    return desciption;
  }
  public void setDesciption(String desciption) {
    this.desciption = desciption;
  }

  
  /**
   **/
  public ErrorDetail infoURL(String infoURL) {
    this.infoURL = infoURL;
    return this;
  }
  
  
  @JsonProperty("infoURL")
  public String getInfoURL() {
    return infoURL;
  }
  public void setInfoURL(String infoURL) {
    this.infoURL = infoURL;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorDetail errorDetail = (ErrorDetail) o;
    return Objects.equals(this.code, errorDetail.code) &&
        Objects.equals(this.message, errorDetail.message) &&
        Objects.equals(this.desciption, errorDetail.desciption) &&
        Objects.equals(this.infoURL, errorDetail.infoURL);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, desciption, infoURL);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorDetail {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    desciption: ").append(toIndentedString(desciption)).append("\n");
    sb.append("    infoURL: ").append(toIndentedString(infoURL)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

