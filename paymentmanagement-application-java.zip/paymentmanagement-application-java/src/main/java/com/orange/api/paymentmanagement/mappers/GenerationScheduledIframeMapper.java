package com.orange.api.paymentmanagement.mappers;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Iframe;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public final class GenerationScheduledIframeMapper {
   
    public static Iframe mapScheduledPaymentToIframe(FixedValuesDB fixedValues, Payment paymentScheduled, String zLogin, String transactiontype, String urlIframe, String zCallerIp)
            throws UnsupportedEncodingException {
        String urlScheduled = urlIframe;
        String date = mapDate();
        String msisdn = PaymentManagementUtils.searchValueCharacteristic(paymentScheduled.getCharacteristic(),
                Constants.PHONENUMBER);
        String documento = PaymentManagementUtils.mapDocument(paymentScheduled.getPayer());
        String amount = "0";
        String custCode = PaymentManagementUtils.mapCustomerCode(paymentScheduled.getPayer());
        String numOpOrigen = PaymentManagementUtils.getNumOrigen();
        log.info("Se va a generar iframe de recuarga programada con Numero Operacion Origen: " + numOpOrigen);

        String urlOK = PaymentManagementUtils.searchValueCharacteristic(paymentScheduled.getCharacteristic(),
                Constants.REDIRECTION_OK);
        String urlKO = PaymentManagementUtils.searchValueCharacteristic(paymentScheduled.getCharacteristic(),
                Constants.REDIRECTION_KO);

        StringBuilder strHashBuilder = new StringBuilder();
        strHashBuilder.append(date).append(amount).append(fixedValues.getClientCode())
                .append(fixedValues.getCommercialCode()).append(fixedValues.getTerminalCode()).append(numOpOrigen)
                .append(urlOK).append(fixedValues.getSeed());
        String hash = DigestUtils.sha256Hex(strHashBuilder.toString());

        urlScheduled += "?coCliente=" + fixedValues.getClientCode();
        urlScheduled += "&coComercio=" + fixedValues.getCommercialCode();
        urlScheduled += "&coTerminal=" + fixedValues.getTerminalCode();

        urlScheduled += "&fechaOpOrigen=" + URLEncoder.encode(date, Constants.C_UTF8);
        urlScheduled += "&idioma=" + fixedValues.getLanguage();
        urlScheduled += "&numOpOrigen=" + numOpOrigen;
        urlScheduled += "&importe=" + amount;
        urlScheduled += "&moneda=" + fixedValues.getCurrency();
        urlScheduled += "&urlOk=" + URLEncoder.encode(urlOK, Constants.C_UTF8);
        urlScheduled += "&urlKo=" + URLEncoder.encode(urlKO, Constants.C_UTF8);
        urlScheduled += "&hash=" + hash;
        urlScheduled += "&target=" + fixedValues.getTarget();
        urlScheduled += "&urlCss=" + URLEncoder.encode(fixedValues.getUrlCss(), Constants.C_UTF8);
        urlScheduled += "&botonForm=" + fixedValues.getFormButton();
        urlScheduled += "&template=" + fixedValues.getTemplate();
        urlScheduled += "&formaPago=" + fixedValues.getPaymentMethod();
        urlScheduled += "&cardType=" + fixedValues.getCardType();
        urlScheduled += "&msisdn=" + msisdn;
        urlScheduled += "&documento=" + documento;
        urlScheduled += "&usuario=" + zLogin;
        if(StringUtils.isNotEmpty(custCode)) {
            urlScheduled += "&customer_code=" + custCode;
        }
        
        String processFlowId = null;
        processFlowId = PaymentManagementUtils.searchValueCharacteristic(paymentScheduled.getCharacteristic(),
                Constants.PROCESSFLOW_ID);
        urlScheduled += "&PedidoCRM=" + processFlowId;
        urlScheduled += "&pedidoTOL=" + zCallerIp;
        urlScheduled += "&pagoRecurrente=F";

        Iframe iframeScheduled = new Iframe();

        iframeScheduled.setDate(date);
        iframeScheduled.setIframe(urlScheduled);
        iframeScheduled.setNumOpOrigen(numOpOrigen);
        iframeScheduled.setUrlKo(urlKO);
        iframeScheduled.setUrlOk(urlOK);
        iframeScheduled.setHash(hash);
        iframeScheduled.setCustCode(custCode);

        return iframeScheduled;

    }


    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }
    
    public static void mapIframeToScheduledPayment(Iframe iframe, Payment paymentScheduled) {

        paymentScheduled.setId(iframe.getNumOpOrigen());
        paymentScheduled.setCharacteristic(mapCharacteristicResponse(iframe.getIframe(), paymentScheduled.getCharacteristic()));
        paymentScheduled.setStatus(Constants.PENDING);
        log.info("La fechaPayment de entrada al metod para formatear es : {}", iframe.getDate());
        paymentScheduled.setStatusDate(PaymentManagementUtils.extractDateOriginIframe(iframe.getDate(), Constants.TIMEZONE_UTC));
        log.info("La fechaPayment de salida al metod para formatear es : {}", iframe.getDate());
    }

    private static List<Characteristic> mapCharacteristicResponse(String iframe,
            List<Characteristic> listCharacteristic) {
        Characteristic characteristicIframe = new Characteristic();

        characteristicIframe.setName(Constants.PAYMENTLINKIFRAME);
        characteristicIframe.setValue(iframe);

        listCharacteristic.add(characteristicIframe);

        return listCharacteristic;
    }

    public static PaymentRegistryDB mapScheduledPaymentManagementDB(Payment paymentScheduled, String zapp, FixedValuesDB fixedValues,
            String transaction, Iframe iframe, String zlogin, String processFlowId) {

        PaymentRegistryDB paymentRegistryIframeSch = new PaymentRegistryDB();

     Optional.ofNullable(paymentScheduled.getTotalAmount())
             .map(Money::getValue)
             .map(Object::toString)
             .ifPresent(paymentRegistryIframeSch::setAmount);

     if (paymentScheduled.getPaymentItem() != null) {
         paymentRegistryIframeSch.setBscsIdentifier(mapBscs(paymentScheduled.getPaymentItem()));
     }

     paymentRegistryIframeSch.setChannel(zapp);
     paymentRegistryIframeSch.setClientCode(fixedValues.getClientCode());
     paymentRegistryIframeSch.setCommercialCode(fixedValues.getCommercialCode());
     paymentRegistryIframeSch.setCurrency(fixedValues.getCurrency());

     Optional.ofNullable(paymentScheduled.getPayer())
             .map(PaymentManagementUtils::mapDocument)
             .ifPresent(paymentRegistryIframeSch::setIdDocument);

     Optional.ofNullable(paymentScheduled.getPayer())
             .map(GenerationPaymentLinkMapper::mapTypeDocument)
             .ifPresent(paymentRegistryIframeSch::setTypeDocument);

     Optional.ofNullable(paymentScheduled.getCharacteristic())
             .map(characteristics -> PaymentManagementUtils.searchValueCharacteristic(characteristics, Constants.PHONENUMBER))
             .ifPresent(paymentRegistryIframeSch::setPhonenumber);

     Optional.ofNullable(paymentScheduled.getPayer())
             .map(RelatedParty::getReferredType)
             .ifPresent(paymentRegistryIframeSch::setType);

     Optional.ofNullable(paymentScheduled.getPaymentItem())
             .filter(items -> !items.isEmpty())
             .map(items -> items.get(0).getItem().getId())
             .ifPresent(paymentRegistryIframeSch::setVapId);

     paymentRegistryIframeSch.setLanguage(fixedValues.getLanguage());
     paymentRegistryIframeSch.setOriginOpnumber(iframe.getNumOpOrigen());
     paymentRegistryIframeSch.setPaymentAttempts(fixedValues.getPaymentRetries());
     paymentRegistryIframeSch.setStatus(Constants.SCHEDULED_REQUESTED);
     paymentRegistryIframeSch.setStatusDescription(Constants.SCHEDULED_REQUESTED);
     paymentRegistryIframeSch.setTransactiontype(transaction);
     paymentRegistryIframeSch.setTerminalCode(fixedValues.getTerminalCode());
     paymentRegistryIframeSch.setUserId(zlogin);
     paymentRegistryIframeSch.setProcessflowId(processFlowId);
     paymentRegistryIframeSch.setHash(iframe.getHash());
     paymentRegistryIframeSch.setCustCode(iframe.getCustCode());
     paymentRegistryIframeSch.setUrlKo(iframe.getUrlKo());
     paymentRegistryIframeSch.setUrlOk(iframe.getUrlOk());
     paymentRegistryIframeSch.setUrlIframe(iframe.getIframe());

     paymentRegistryIframeSch.setPaymentUpdate(formatDateIframe(iframe.getDate()));

     paymentRegistryIframeSch.setPaymentFlow(Constants.PAYMENT_FLOW_IFRAME);

        

        log.info("Se ha creado el objeto para guardar en bbdd");

        return paymentRegistryIframeSch;
    }

    public static String formatDateIframe(String dateIframe) {
        SimpleDateFormat sdfInput = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        Date date = null;
        try {
            date = sdfInput.parse(dateIframe);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }
        log.info("La fechaupdete de entrada al metod para formatear es : {}", date);
        SimpleDateFormat sdfOutput = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfOutput.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String response = sdfOutput.format(date);
        return response;
    }

    public static String mapBscs(List<PaymentItem> listPaymentItem) {
        String codebscsPL = null;

        for (PaymentItem paymentItem : listPaymentItem) {
            if (Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())) {
                codebscsPL = PaymentManagementUtils.searchValueCharacteristic(paymentItem.getItem().getCharacteristic(),
                        Constants.BSCSCODE);
            }
        }

        return codebscsPL;
    }

}