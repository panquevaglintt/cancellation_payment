package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosTarjetaTP {

    @JsonProperty("fechaCaducidad")
    private String fechaCaducidad;
    
    @JsonProperty("token")
    private String token;
    
}
