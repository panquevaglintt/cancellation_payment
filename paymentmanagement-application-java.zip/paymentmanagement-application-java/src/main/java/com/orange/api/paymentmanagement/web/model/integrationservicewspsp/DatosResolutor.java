package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;
import java.time.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosResolutor implements Serializable {
	private static final long serialVersionUID = 1L;
	
	  @JsonProperty("fechaSesion")
	  private OffsetDateTime fechaSesion;

	  @JsonProperty("idResolutor")
	  private String idResolutor;

	  @JsonProperty("idSesion")
      private Integer idSesion;

      @JsonProperty("adquirente")
      private String adquirente;

      @JsonProperty("merchant")
      private String merchant;

      @JsonProperty("terminalBancario")
      private String terminalBancario;


	
}