package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestTokenPayment implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("datosCliente")
    private DatosCliente datosCliente;

    @JsonProperty("datosTarjeta")
    private DatosTarjetaTP datosTarjeta;
    
    @JsonProperty("fechaOpOrigen")
    private String fechaOpOrigen;

    @JsonProperty("idioma")
    private String idioma;

    @JsonProperty("importe")
    private Long importe;
    
    @JsonProperty("moneda")
    private String moneda;

    @JsonProperty("numOpOrigen")
    private String numOpOrigen;

    @JsonProperty("pagoRecurrente")
    private String pagoRecurrente;

    @JsonProperty("parametrosAdicionales")
    private ParametrosAdicionales parametrosAdicionales;

    @JsonProperty("usuario")
    private String usuario;
    
    @JsonProperty("txId_COF")
    private String txId_COF;
}
