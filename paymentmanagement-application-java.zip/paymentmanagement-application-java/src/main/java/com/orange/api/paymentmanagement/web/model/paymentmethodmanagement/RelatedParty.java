package com.orange.api.paymentmanagement.web.model.paymentmethodmanagement;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatedParty   {
  
  private String referredType = null;
  private List<IndividualIdentification> individualIdentification = new ArrayList<IndividualIdentification>();
  private List<OrganizationIdentification> organizationIdentification = new ArrayList<OrganizationIdentification>();

  
  /**
   **/
  public RelatedParty referredType(String referredType) {
    this.referredType = referredType;
    return this;
  }
  
  
  @JsonProperty("@referredType")
  public String getReferredType() {
    return referredType;
  }
  public void setReferredType(String referredType) {
    this.referredType = referredType;
  }

  
  /**
   **/
  public RelatedParty individualIdentification(List<IndividualIdentification> individualIdentification) {
    this.individualIdentification = individualIdentification;
    return this;
  }
  
  
  @JsonProperty("individualIdentification")
  public List<IndividualIdentification> getIndividualIdentification() {
    return individualIdentification;
  }
  public void setIndividualIdentification(List<IndividualIdentification> individualIdentification) {
    this.individualIdentification = individualIdentification;
  }

  
  /**
   **/
  public RelatedParty organizationIdentification(List<OrganizationIdentification> organizationIdentification) {
    this.organizationIdentification = organizationIdentification;
    return this;
  }
  
  
  @JsonProperty("organizationIdentification")
  public List<OrganizationIdentification> getOrganizationIdentification() {
    return organizationIdentification;
  }
  public void setOrganizationIdentification(List<OrganizationIdentification> organizationIdentification) {
    this.organizationIdentification = organizationIdentification;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RelatedParty relatedParty = (RelatedParty) o;
    return Objects.equals(this.referredType, relatedParty.referredType) &&
        Objects.equals(this.individualIdentification, relatedParty.individualIdentification) &&
        Objects.equals(this.organizationIdentification, relatedParty.organizationIdentification);
  }

  @Override
  public int hashCode() {
    return Objects.hash(referredType, individualIdentification, organizationIdentification);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RelatedParty {\n");
    
    sb.append("    referredType: ").append(toIndentedString(referredType)).append("\n");
    sb.append("    individualIdentification: ").append(toIndentedString(individualIdentification)).append("\n");
    sb.append("    organizationIdentification: ").append(toIndentedString(organizationIdentification)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

