package com.orange.api.paymentmanagement.service.impl;

import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.google.common.base.Strings;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.CommonServiceErrors;
import com.orange.api.paymentmanagement.service.PaymentReportService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiInternalServerErrorException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentReportServiceImpl implements PaymentReportService {

    private PaymentRegistryRepository paymentRegistryRepository;

    @Autowired
    public PaymentReportServiceImpl(PaymentRegistryRepository paymentRegistryRepository) {
        this.paymentRegistryRepository = paymentRegistryRepository;
    }

    @Override
    public byte[] paymentReportCsvGenerate(String startDate, String endDate) {
        log.info("Se llama a la bbdd.");

        List<PaymentRegistryDB> paymentReportList = null;
        try {
            // Se obtienen los registros con antiguedad de una semana

            paymentReportList = paymentRegistryRepository.findByCreationDate(startDate, endDate);
            if (ObjectUtils.isEmpty(paymentReportList)) {
                log.info("No existe ningun registro en la base de datos para las fechas seleccionadas.");
            }
        } catch (Exception e) {
            log.error("Error al exportar la bbdd.");
            log.error(e.getLocalizedMessage());
            throw new OpenApiInternalServerErrorException(CommonServiceErrors.ERROR_CONNECTION_BBDD.toString());
        }

        return this.generateCsvFile(paymentReportList);

    }

    @Transactional(readOnly = true)
    public static byte[] generateCsvFile(List<PaymentRegistryDB> paymentReportList) {

        final String[][] dataMatrix = getMatrixOfLines(paymentReportList);
        return generateFile(dataMatrix);
    }

    /**
     * Method that builds the table from the file.
     * 
     * @param listFraudReport
     * @return String[][]
     */
    private static String[][] getMatrixOfLines(final List<PaymentRegistryDB> paymentReportList) {

        // Se construye la tabla que se exportara finalmente
        final int excelRows = paymentReportList.size() + 1;
        String[][] matrix = new String[excelRows][Constants.TAPARTNER_EXCEL_COLUMN_COUNT];

        // Añadimos Cabeceras
        matrix[0] = Constants.TAPARTNER_EXCEL_HEADERS;

        PaymentRegistryDB paymentRegistry;
        for (int i = 0; i < paymentReportList.size(); i++) {
            paymentRegistry = paymentReportList.get(i);
            matrix[i + 1][0] = formatColumnOutput(paymentRegistry.getOriginOpnumber());
            matrix[i + 1][1] = formatColumnOutput(paymentRegistry.getPaymentUpdate());
            matrix[i + 1][2] = formatColumnOutput(paymentRegistry.getCommercialCode());
            matrix[i + 1][3] = formatColumnOutput(paymentRegistry.getAmount().replace(".0", ""));
            matrix[i + 1][4] = formatColumnOutput(paymentRegistry.getStatus());
            matrix[i + 1][5] = formatColumnOutput(paymentRegistry.getPaymentMethod());
            matrix[i + 1][6] = formatColumnOutput(paymentRegistry.getToken());
            matrix[i + 1][7] = TimestampToString(paymentRegistry.getLinkExpiration());
            matrix[i + 1][8] = formatColumnOutput(paymentRegistry.getPhonenumber());
            matrix[i + 1][9] = formatColumnOutput(paymentRegistry.getIdDocument());
            matrix[i + 1][10] = formatColumnOutput(paymentRegistry.getAnnulationOpnumber());
            matrix[i + 1][11] = TimestampToString(paymentRegistry.getAnnulationDate());
            matrix[i + 1][12] = formatColumnOutput(paymentRegistry.getAnnulationResult());
            matrix[i + 1][13] = formatColumnOutput(paymentRegistry.getVapId());
            matrix[i + 1][14] = formatColumnOutput(paymentRegistry.getProcessflowId());
            matrix[i + 1][15] = formatColumnOutput(paymentRegistry.getConfirmationOriginOpnumber());
            matrix[i + 1][16] = TimestampToString(paymentRegistry.getConfirmationOriginOpdate());
        }
        return matrix;
    }

    private static String formatColumnOutput(final String value) {
        return Strings.nullToEmpty(value);
    }

    private static String TimestampToString(Timestamp timestamp) {
        String value = "";
        if (null != timestamp) {
            value = formatColumnOutput(timestamp.toString());

        } else {
            // Sonar
        }
        return value;
    }

    /**
     * Method that generates the file.
     * 
     * @param table
     * @return byte[]
     */
    private static byte[] generateFile(String[][] table) {

        log.debug("Generando fichero");
        byte[] file;
        final long start = System.currentTimeMillis();

        file = generateCSV(table);

        log.debug("La generacion del fichero ha tardado: {} ms", System.currentTimeMillis() - start);
        return file;
    }

    /**
     * Method that generates the csv.
     * 
     * @param matrix
     * @return byte[]
     */
    private static byte[] generateCSV(final String[][] matrix) {

        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < matrix.length; i++) {
            sb.append(String.join(Constants.CSV_DELIMITER, matrix[i])).append(Constants.CSV_ENDLINE);
        }
        // Se usa el encode ISO-8859-1 pues es el que usan por defectos las
        // aplicaciones de Microsoft
        return sb.toString().getBytes(Charset.forName("ISO-8859-1"));

    }

}