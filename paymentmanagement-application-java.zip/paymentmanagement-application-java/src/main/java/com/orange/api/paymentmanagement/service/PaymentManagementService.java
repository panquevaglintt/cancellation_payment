package com.orange.api.paymentmanagement.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for PaymentManagement service.
 */
public interface PaymentManagementService {

    /**
     * This service performs a PaymentLink cancellation.
     * 
     * @param payment
     * @param numOrigin
     * @param zApp
     * @return
     */
    ResponseEntity<Payment> paymentLinkAnnulation(Payment payment, String numOrigin);
    
    ResponseEntity<Payment> confirmationPreauthorizationPayment(Payment payment, String numOrigin);
    
    ResponseEntity<Payment> cancellationPreauthorizationPayment(Payment payment, String numOrigin);

    ResponseEntity<Payment> paymentLinkCancellation(Payment payment, String numOrigin, String zLogin);

    /**
     * This service generates a PaymentLink.
     * 
     * @param payment
     * @param zApp
     * @param zLogin
     * @return
     */
    ResponseEntity<Payment> generationPaymentLink(Payment payment, String zApp, String zLogin);
    
    ResponseEntity<Payment> generationPreauthorizationPaymentLink(Payment payment, String zApp, String zLogin, String zCallerIp);

    ResponseEntity<Payment> statusPaymentLink(String id, String type);

    /**
     * This service updates the status of a Payment.
     * 
     * @param id
     * @param payment
     * @return
     */
    ResponseEntity<Payment> updateStatusPayment(String id, Payment payment);

    /**
     * This service generates a Iframe.
     * 
     * @param payment
     * @param zApp
     * @param zLogin
     * @return
     */
    ResponseEntity<Payment> generationIframe(Payment payment, String zApp, String zLogin);
    
    ResponseEntity<Payment> generationPreauthorizationIframe(Payment payment, String zApp, String zLogin, String zCallerIp);
    
    ResponseEntity<Payment> generationScheduledIframe(Payment payment, String zApp, String zLogin, String zCallerIp);
    
    ResponseEntity<Payment> generationProccesingFile(Payment payment, String zApp, String authorizationHeader);

    ResponseEntity<Payment> generationValidatingFile(Payment payment, String zApp, String authorizationHeader);

    /**
     * This service Creates the CSV with the info in BBDD
     * 
     * @param startDate
     * @param endDate
     * @return
     */
    ResponseEntity<byte[]> paymentReportCsvGenerate(String startDate, String endDate);
    
    /**
     * This service generates a PaymentMarketPlace.
     * 
     * @param payment
     * @param zApp
     * @param zLogin
     * @return
     */
    ResponseEntity<Payment> generationPaymentMarketPlace(Payment payment, String zApp, String zLogin);
    
    /**
     * This service gets a PaymentLink status.
     * 
     * @param id
     * @return
     */
    ResponseEntity<List<Payment>> searchPaymentMarketPlace(String payerReferredType, String typeDocument, String idDocument, String phoneNumber);
    
    /**
     * This service return a Payment.
     * 
     * @param id
     * @return
     */
    ResponseEntity<Payment> paymentReturnMarketPlace(Payment payment, String numOrigin);

    ResponseEntity<Payment> generationTokenPayment(Payment payment, String zApp, String zLogin, String zCallerIp);
    
    /**
     * This service performs a clean operation in the service DB in order to
     * delete outdated DB registries in all tablespaces.
     */
    void cleanDb();
}