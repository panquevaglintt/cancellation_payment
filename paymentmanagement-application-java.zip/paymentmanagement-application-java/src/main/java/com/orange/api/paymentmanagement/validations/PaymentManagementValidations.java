package com.orange.api.paymentmanagement.validations;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

/**
 * Validations class for PaymentManagement API.
 */
@Slf4j
public class PaymentManagementValidations {

    /**
     * This method validates the Mode field
     * 
     * @param serviceTest
     */
    public static void validateIdPaymentLink(String id) {

        if (StringUtils.isEmpty(id)) {
            log.error("El campo id introducido no puede ser ni nulo ni vacio");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    /**
     * This method validates payment
     * 
     * @param body
     */
    public static void validatePostPayment(Payment body) {

        validateTotalAmount(body.getTotalAmount());
        validateCharacteristic(body.getCharacteristic());
        if (Constants.MP_PAYMENT.equalsIgnoreCase(body.getType())) {
            validateDateFormat(body);
        }
        
        boolean amortization = PaymentManagementUtils.isAmortization(body.getCharacteristic());

        if (amortization) {
            validatePaymentItem(body.getPaymentItem());
        }

        validatePayer(body.getPayer());

    }

    private static void validateDateFormat(Payment body) {
        for (String formatter : Constants.DATE_FORMATS_MARKETPLACE_CREATE) {
            try {
                DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(formatter);
                LocalDateTime localDateTime = LocalDateTime.parse(body.getStatusDate().toString(), inputFormatter);
                break;
            } catch (DateTimeParseException e) {
                e.printStackTrace();
                log.error("la fecha de pago no tiene un formato correcto:  " + body.getStatusDate().toString());
                if (formatter.equals(Constants.DATE_FORMATS_MARKETPLACE_CREATE
                        .get(Constants.DATE_FORMATS_MARKETPLACE_CREATE.size() - 1))) {
                    throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_DATE_FORMAT.toString());
                }
            }
        }
    }

    /**
     * This method validates payment Iframe
     * 
     * @param body
     */
    public static void validatePostIframe(Payment payment) {
        validateTotalAmount(payment.getTotalAmount());
        validateCharacteristicIframe(payment.getCharacteristic());
        validatePayer(payment.getPayer());

        String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.TRANSACTION);
        if (Constants.RECOVERY.equalsIgnoreCase(transactiontype)) {
            validateAccount(payment.getAccount());
        }
    }

    public static void validatePostScheduledIframe(Payment payment) {
        validateCharacteristicIframe(payment.getCharacteristic());
        validatePayer(payment.getPayer());

    }

    public static void validateTransferFile(Payment payment) {
        String fileName = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.FILE_NAME);
        String processFlowId = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.PROCESSFLOW_ID);
        if (null == fileName) {
            log.error("Se debe informar el FileName");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (null == processFlowId) {
            log.error("Se debe informar el ProcessFlowId");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

    }

    /**
     * This method validates account
     * 
     * @param account
     */
    private static void validateAccount(AccountRef account) {
        if (ObjectUtils.isEmpty(account) || !Constants.BILLINGACCOUNT.equalsIgnoreCase(account.getReferredType())) {
            log.error("El referredType de account debe ser billingAccount");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (StringUtils.isEmpty(account.getId())) {
            log.error("campo id de account no puede ser nulo o vacio");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    /**
     * This method validates annulation Payment
     * 
     * @param body
     */
    public static void validatePostPaymentAnulationAndReturned(Payment body) {

        validateTotalAmount(body.getTotalAmount());
        validateCharacteristicAnulationAndReturned(body.getCharacteristic());
        validatePayer(body.getPayer());

    }

    /**
     * This method validates characteristic annulation
     * 
     * @param listCharacteristic
     */
    private static void validateCharacteristicAnulationAndReturned(List<Characteristic> listCharacteristic) {
        if (ObjectUtils.isEmpty(listCharacteristic)) {
            log.error("El campo characteristic debe existir.");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        boolean phoneNumber = false;

        for (Characteristic characteristic : listCharacteristic) {
            if (Constants.PHONENUMBER.equalsIgnoreCase(characteristic.getName())) {
                phoneNumber = true;
            }

        }

        if (!phoneNumber) {
            log.error("El campo phone number de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

    }

    /**
     * This method validates payer
     * 
     * @param payer
     */
    private static void validatePayer(RelatedParty payer) {

        boolean individualOk = false;
        boolean organizationOk = false;

        if (ObjectUtils.isEmpty(payer) || !Constants.CLIENT.equalsIgnoreCase(payer.getRole())) {
            log.error("El rol de payer debe ser Client");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
            individualOk = StringUtils.isNotEmpty(payer.getIndividualIdentification().get(0).getIdentificationId())
                    && StringUtils.isNotEmpty(payer.getIndividualIdentification().get(0).getIdentificationType());
        } else if (Constants.REFERRED_TYPE_ORGANIZATION.equalsIgnoreCase(payer.getReferredType())) {
            organizationOk = StringUtils.isNotEmpty(payer.getOrganizationIdentification().get(0).getIdentificationId())
                    && StringUtils.isNotEmpty(payer.getOrganizationIdentification().get(0).getIdentificationType());
        } else {
            log.error("No viene ningun referredType");
        }
        if (!individualOk && !organizationOk) {
            log.error("Debe introducirse un numero y tipo de cliente asociado a la tipologia de cliente introducida.");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());

        }

    }

    /**
     * This method validates characteristics.
     * 
     * @param characteristics
     */
    private static void validateCharacteristic(List<Characteristic> characteristics) {

        if (ObjectUtils.isEmpty(characteristics)) {
            log.error("El campo characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        boolean phoneNumber = false;
        boolean transaction = false;

        for (Characteristic characteristic : characteristics) {
            if (Constants.PHONENUMBER.equalsIgnoreCase(characteristic.getName())) {
                phoneNumber = true;
            }

            if (Constants.TRANSACTION.equalsIgnoreCase(characteristic.getName())) {
                transaction = true;
            }
        }

        if (!phoneNumber) {
            log.error("El campo phone number de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (!transaction) {
            log.error("El campo transaction de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    /**
     * This method validates characteristics iframe.
     * 
     * @param characteristics
     */
    private static void validateCharacteristicIframe(List<Characteristic> characteristics) {

        if (ObjectUtils.isEmpty(characteristics)) {
            log.error("El campo characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        boolean phoneNumber = false;
        boolean redirectionOK = false;
        boolean redirectionKO = false;
        boolean transaction = false;

        for (Characteristic characteristic : characteristics) {
            if (Constants.PHONENUMBER.equalsIgnoreCase(characteristic.getName())) {
                phoneNumber = true;
            }
            if (Constants.REDIRECTION_OK.equalsIgnoreCase(characteristic.getName())) {
                redirectionOK = true;
            }
            if (Constants.REDIRECTION_KO.equalsIgnoreCase(characteristic.getName())) {
                redirectionKO = true;
            }
            if (Constants.TRANSACTION.equalsIgnoreCase(characteristic.getName())) {
                transaction = true;
            }
        }

        if (!phoneNumber) {
            log.error("El campo phone number de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (!redirectionOK) {
            log.error("El campo redirectionOK de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (!redirectionKO) {
            log.error("El campo redirectionKO de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (!transaction) {
            log.error("El campo transaction de characteristic debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    /**
     * This method validates paymentItem
     * 
     * @param listPaymentItem
     */
    private static void validatePaymentItem(List<PaymentItem> listPaymentItem) {

        if (ObjectUtils.isEmpty(listPaymentItem)) {
            log.error("El campo paymentitem debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        boolean identificador = false;

        for (PaymentItem paymentItem : listPaymentItem) {
            if (paymentItem.getItem() != null && Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())
                    && !ObjectUtils.isEmpty(paymentItem.getItem().getCharacteristic())) {
                identificador = validateCharacteristicPaymentItem(paymentItem.getItem().getCharacteristic());
            }
        }

        if (!identificador) {
            log.error("El campo paymentitem debe contener el identificador del Vap en BSCS");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    /**
     * This method validates characteristic the paymentItem
     * 
     * @param listCharacteristic
     * @return
     */
    private static boolean validateCharacteristicPaymentItem(List<Characteristic> listCharacteristic) {
        for (Characteristic characteristic : listCharacteristic) {
            if (Constants.BSCSCODE.equalsIgnoreCase(characteristic.getName()) && characteristic.getValue() != null) {
                return true;
            }
        }

        return false;
    }

    /**
     * This method validates totalAmount
     * 
     * @param totalAmount
     */
    private static void validateTotalAmount(Money totalAmount) {
        if (ObjectUtils.isEmpty(totalAmount)) {
            log.error("El campo total amount debe existir");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }

        if (ObjectUtils.isEmpty(totalAmount.getValue())) {
            log.error("El campo total amount debera contener el importe");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_BODY.toString());
        }
    }

    public static void validatePaymentFind(String characteristicName, String characteristicValue,
            String payerReferredType, String payerIndividualIdentificationIdentificationId,
            String payerIndividualIdentificationIdentificationType,
            String payerOrganizationIdentificationIdentificationId,
            String payerOrganizationIdentificationIdentificationType, String paymentItemItemId,
            String paymentItemItemRole) {

        if (StringUtils.isEmpty(characteristicName) && StringUtils.isEmpty(characteristicValue)
                && StringUtils.isEmpty(payerReferredType)
                && StringUtils.isEmpty(payerIndividualIdentificationIdentificationId)
                && StringUtils.isEmpty(payerIndividualIdentificationIdentificationType)
                && StringUtils.isEmpty(payerOrganizationIdentificationIdentificationId)
                && StringUtils.isEmpty(payerOrganizationIdentificationIdentificationType)
                && StringUtils.isEmpty(paymentItemItemId) && StringUtils.isEmpty(paymentItemItemRole)) {
            log.error("Todos los campos vienen a nulo");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.FIELD_NULL.toString());
        }

    }

    public static void validatePostTokenPayment(Payment payment) {

        checkTotalAmount(payment);
        checkPaymentMethod(payment);

        String phoneNumber = null;
        String transactionType = null;
        String proccesFlowId = null;

        for (Characteristic characteristic : payment.getCharacteristic()) {
            phoneNumber = fillPhoneNumber(phoneNumber, characteristic);
            transactionType = fillTransactionType(transactionType, characteristic);
            proccesFlowId = fillProccesFlowId(proccesFlowId, characteristic);
        }

        checkPhoneNumber(phoneNumber);
        checkTransactionType(transactionType);
        checkProccesFlowId(proccesFlowId);

    }

    public static String takeData(Characteristic characteristic, String characteristicName) {
        if (characteristicName.equalsIgnoreCase(characteristic.getName())) {
            if (StringUtils.isNotEmpty(characteristic.getValue())) {
                return characteristic.getValue();
            }
        }
        return null;
    }

    public static String fillProccesFlowId(String proccesFlowId, Characteristic characteristic) {
        if (StringUtils.isEmpty(proccesFlowId)) {
            proccesFlowId = takeData(characteristic, Constants.PROCESSFLOW_ID);
        }
        return proccesFlowId;
    }

    public static String fillTransactionType(String transactionType, Characteristic characteristic) {
        if (StringUtils.isEmpty(transactionType)) {
            transactionType = takeData(characteristic, Constants.TRANSACTION);
        }
        return transactionType;
    }

    public static String fillPhoneNumber(String phoneNumber, Characteristic characteristic) {
        if (StringUtils.isEmpty(phoneNumber)) {
            phoneNumber = takeData(characteristic, Constants.PHONENUMBER);
        }
        return phoneNumber;
    }

    private static void checkProccesFlowId(String proccesFlowId) {
        if (StringUtils.isEmpty(proccesFlowId)) {
            log.error("El proccesFlowId no se ha informado correctamente");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.PROCESS_FROLW_ID.toString());
        }
    }

    private static void checkTransactionType(String transactionType) {
        if (StringUtils.isEmpty(transactionType) || !Constants.SCHEDULED_TOP_UP.equalsIgnoreCase(transactionType)) {
            log.error("El transactionType no se ha informado correctamente");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.TRANSACTION_TYPE.toString());
        }
    }

    private static void checkPhoneNumber(String phoneNumber) {
        if (StringUtils.isEmpty(phoneNumber)) {
            log.error("El phoneNumber no se ha informado correctamente");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.PHONE_NUMBER.toString());
        }

    }

    public static void checkPaymentMethod(Payment payment) {
        if (ObjectUtils.isEmpty(payment.getPaymentMethod())
                || ObjectUtils.isEmpty(payment.getPaymentMethod().getId())) {
            log.error("El value del paymentMethod debe venir informado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.TOTAL_AMOUNT.toString());
        }
    }

    public static void checkTotalAmount(Payment payment) {
        if (ObjectUtils.isEmpty(payment.getTotalAmount()) || ObjectUtils.isEmpty(payment.getTotalAmount().getUnit())
                || ObjectUtils.isEmpty(payment.getTotalAmount().getValue())) {
            log.error("El totalAmount no está informado correctamente");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.TOTAL_AMOUNT.toString());
        }
    }

}