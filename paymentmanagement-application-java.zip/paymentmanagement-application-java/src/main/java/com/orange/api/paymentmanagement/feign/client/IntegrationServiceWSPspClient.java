package com.orange.api.paymentmanagement.feign.client;

import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client interface for WS integration service (PSP).
 */
@FeignClient(name = "integrationservicewspsp", url = "${spring.cloud.openfeign.client.config.integrationservicewspsp.url}")
public interface IntegrationServiceWSPspClient {

	@PostMapping(path = "/paymentLinkStatus")
	ResponseStatus paymentLinkStatus(@RequestBody RequestStatus requestWS);

	@PostMapping(path = "/paymentLinkGeneration")
	ResponseGeneration paymentLinkGeneration(@RequestBody RequestGeneration requestWS);

	@PostMapping(path = "/paymentAnnulation")
	ResponseAnnulationAndReturned paymentLinkAnnulation(@RequestBody RequestAnnulationAndReturned requestWS);
	
	@PostMapping(path = "/paymentReturned")
	ResponseAnnulationAndReturned paymentMarketPlaceReturn(@RequestBody RequestAnnulationAndReturned requestWS);
	
    @PostMapping(path = "/paymentPreauthorizationConfirmation")
    PreautorizacionConfirmacionResponse confirmationPreauthorizationPayment(@RequestBody PreautorizacionConfirmacionRequest requestWS);
    
    @PostMapping(path = "/paymentPreauthorizationCancelacion")
    PreautorizacionCancelacionResponse cancelationPreauthorizationPayment(@RequestBody PreautorizacionCancelacionRequest requestWS);

	@PostMapping(path = "/cancellationPaymentLink")
	ResponseCancellationPaymentLink cancellationPaymentLink(@RequestBody RequestCancellationPaymentLink requestWS);
    
    @PostMapping(path = "/tokenPayment")
    ResponseTokenPayment tokenPayment(@RequestBody RequestTokenPayment requestWS);
    
}