package com.orange.api.paymentmanagement.mappers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ObjectUtils;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentMethodRefOrValue;
import com.orange.api.paymentmanagement.web.model.StatusChange;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosLink;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosOperacion;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosTarjeta;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestStatus;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseStatus;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public final class StatusPaymentLinkMapper {

    public static void mapPaymentManagementDBToRequestStatus(PaymentRegistryDB paymentRegistryDB,
            RequestStatus requestWS) {

        DatosCliente datosCliente = new DatosCliente();
        datosCliente.setCoCliente(paymentRegistryDB.getClientCode());
        datosCliente.setCoComercio(paymentRegistryDB.getCommercialCode());
        datosCliente.setCoTerminal(paymentRegistryDB.getTerminalCode());
        datosCliente.setPalabraClave(Constants.PALABRA_CLAVE);

        requestWS.setDatosCliente(datosCliente);
        requestWS.setIdioma(paymentRegistryDB.getLanguage());
        requestWS.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        requestWS.setNumOperacionNNP(paymentRegistryDB.getPaymentLink());
        requestWS.setFechaOpOrigen(mapDateStatus());

    }

    private static String mapDateStatus() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    public static void mapResponseStatusToPayment(String id, ResponseStatus responseStatus, Payment payment, String type) {

        if (StringUtils.isEmpty(type)) {
            payment.setType(Constants.EPAYMENT);
        } else {
            payment.setType(type);
        }
        payment.setId(id);
        
        if (Constants.E_PREAUTH_PAYMENT.equals(type)) {
            payment.setStatus(PaymentManagementUtils.getStatusPreauth(responseStatus.getDatosLink()));
        } else {
            payment.setStatus(PaymentManagementUtils.getStatus(responseStatus.getDatosLink()));
        }
        
        boolean paid = false;
        if (Constants.PAID.equalsIgnoreCase(payment.getStatus())) {
            for (DatosOperacion datosOperacion : responseStatus.getOperaciones()) {
                if (datosOperacion.getResultadoOperacion() != null
                        && Constants.OK.equalsIgnoreCase(datosOperacion.getResultadoOperacion().getCodigo())) {
                    mapPaymentPaid(datosOperacion, payment, type);
                    paid = true;
                }
            }
        }

        if (Constants.E_PREAUTH_PAYMENT.equals(type)) {
        payment.setStatusChange(
                mapStatusChangePreauth(responseStatus.getDatosLink(), responseStatus.getFechaOpOrigen(), paid));
        }else {
            payment.setStatusChange(
                    mapStatusChange(responseStatus.getDatosLink(), responseStatus.getFechaOpOrigen(), paid));  
        }

    }

    /**
     * This method maps paymentRegistryDB
     * 
     * @param paymentRegistryDB
     * @param payment
     */
    public static void mapPaymentRegistryDB(PaymentRegistryDB paymentRegistryDB, Payment payment,
            ResponseStatus responseStatus) {

        log.info("Estado actualizado: {}", payment.getStatus());
        switch (payment.getStatus()) {
        case Constants.PAID: // Pago unico
            paymentRegistryDB.setStatus(Constants.COMPLETED);
            paymentRegistryDB.setStatusDescription(Constants.COMPLETED_DESC);
            break;
        case Constants.PENDING: // Cuota
            paymentRegistryDB.setStatus(Constants.PENDING);
            paymentRegistryDB.setStatusDescription(Constants.PENDIENTE_PAGO);
            break;
        case Constants.PAYMENTERROR:
            paymentRegistryDB.setStatus(Constants.PAYMENTERROR);
            paymentRegistryDB.setStatusDescription(Constants.PAYMENTERROR_DESC);
            break;
        case Constants.EXPIRED:
            paymentRegistryDB.setStatus(Constants.EXPIRED);
            paymentRegistryDB.setStatusDescription(Constants.EXPIRED_DESC);
            break;
        case Constants.PREAUTH_PENDING: // Cuota
            paymentRegistryDB.setStatus(Constants.PREAUTH_PENDING);
            paymentRegistryDB.setStatusDescription(Constants.PENDIENTE_PAGO);
            break;  
        case Constants.PREAUTH_EXPIRED: // Cuota
            paymentRegistryDB.setStatus(Constants.PREAUTH_EXPIRED);
            paymentRegistryDB.setStatusDescription(Constants.EXPIRED_DESC);
            break;    
        case Constants.PREAUTH_PAYMENT_ERROR: // Cuota
            paymentRegistryDB.setStatus(Constants.PREAUTH_PAYMENT_ERROR);
            paymentRegistryDB.setStatusDescription(Constants.PAYMENTERROR);
            break; 
        default:
            paymentRegistryDB.setStatus(payment.getStatus());
            paymentRegistryDB.setStatusDescription(payment.getStatus());
            break;
        }

        // actualizar el payment_update
        if (!ObjectUtils.isEmpty(responseStatus.getOperaciones())) {
            operaciones: for (DatosOperacion operacion : responseStatus.getOperaciones()) {
                if (!ObjectUtils.isEmpty(operacion.getResultadoOperacion())  && StringUtils.isNotEmpty(operacion.getResultadoOperacion().getCodigo())
                        && Constants.OK.equalsIgnoreCase(operacion.getResultadoOperacion().getCodigo())) {
                    if (StringUtils.isNotEmpty(operacion.getFechaOpOrigen())) {
                        paymentRegistryDB.setPaymentUpdate(operacion.getFechaOpOrigen());
                        break operaciones;

                    }
                }

            }

        }

    }

    private static void mapPaymentPaid(DatosOperacion datosOperacion, Payment payment, String type) {

        payment.setAuthorizationCode(datosOperacion.getNumAutorizacion());
        if (datosOperacion.getNumOperacionNNP() != null) {
            payment.setCorrelatorId(datosOperacion.getNumOperacionNNP().toString());
        }
        payment.setPaymentMethod(mapPaymentMethodPaid(datosOperacion));
        payment.setCharacteristic(mapCharacteristicPaid(datosOperacion, type));

    }

    private static PaymentMethodRefOrValue mapPaymentMethodPaid(DatosOperacion datosOperacion) {
        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
        if (datosOperacion.getDatosTarjeta() != null
                && StringUtils.isNotEmpty(datosOperacion.getDatosTarjeta().getBin())) {
            paymentMethod.setToken(datosOperacion.getDatosTarjeta().getBin());
            paymentMethod.setCharacteristic(mapCharacteristicPaymentMethod(datosOperacion.getDatosTarjeta()));
        } else {
            paymentMethod.setDescription(Constants.BIZUM_PAYMENT);
        }
        return paymentMethod;
    }

    private static List<Characteristic> mapCharacteristicPaymentMethod(DatosTarjeta datosTarjeta) {
        List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();
        characteristic.setName(Constants.BIN);
        characteristic.setValue(datosTarjeta.getBin());
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.MASKCREDIT);
        characteristic.setValue(datosTarjeta.getMascara());
        listCharacteristic.add(characteristic);

        return listCharacteristic;
    }

    private static List<Characteristic> mapCharacteristicPaid(DatosOperacion datosOperacion, String type) {
        List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();

        if (datosOperacion.getDatosResolutor() != null) {
            if (datosOperacion.getDatosResolutor().getIdSesion() != null) {
                characteristic.setName(Constants.SESSIONID);
                characteristic.setValue(datosOperacion.getDatosResolutor().getIdSesion().toString());
                listCharacteristic.add(characteristic);
            }

            if (datosOperacion.getDatosResolutor().getFechaSesion() != null) {
                characteristic = new Characteristic();
                characteristic.setName(Constants.SESSIONDATE);
                if (Constants.E_PREAUTH_PAYMENT.equals(type)) {
                characteristic.setValue(PaymentManagementUtils
                        .extractDateStatus(datosOperacion.getDatosResolutor().getFechaSesion().toString(), Constants.TIMEZONE_UTC));
                }else {
                    characteristic.setValue(PaymentManagementUtils
                            .extractDateStatus(datosOperacion.getDatosResolutor().getFechaSesion().toString(), Constants.TIMEZONE_EUROPE_MADRID));   
                }
                listCharacteristic.add(characteristic);
            }

            characteristic = new Characteristic();
            characteristic.setName(Constants.RESOLUTORID);
            characteristic.setValue(datosOperacion.getDatosResolutor().getIdResolutor());
            listCharacteristic.add(characteristic);

        } else {
            log.info("No nos llega informado el objeto DatosResolutor");
        }
        
        characteristic = new Characteristic();
        characteristic.setName("operationType");
        characteristic.setValue(Constants.CO_OPLINK);
        listCharacteristic.add(characteristic);
                
        return listCharacteristic;
    }

    private static List<StatusChange> mapStatusChange(DatosLink datos, String fechaOpOrigen, boolean paid) {
        if (datos != null) {

            List<StatusChange> listStatusChange = new ArrayList<StatusChange>();

            StatusChange statusChange = new StatusChange();
            statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(datos.getFxFinValidez(),Constants.TIMEZONE_EUROPE_MADRID));
            statusChange.setStatus(Constants.EXPIRED);
            listStatusChange.add(statusChange);

            statusChange = new StatusChange();
            statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(datos.getFxAltaLink(),Constants.TIMEZONE_EUROPE_MADRID));
            statusChange.setStatus(Constants.CREATED);
            listStatusChange.add(statusChange);

            if (paid) {
                statusChange = new StatusChange();
                statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(fechaOpOrigen,Constants.TIMEZONE_EUROPE_MADRID));
                statusChange.setStatus(Constants.COMPLETED);
                listStatusChange.add(statusChange);
            }

            return listStatusChange;
        }

        return null;
    }
    
    private static List<StatusChange> mapStatusChangePreauth(DatosLink datos, String fechaOpOrigen, boolean paid) {
        if (datos != null) {

            List<StatusChange> listStatusChange = new ArrayList<StatusChange>();

            StatusChange statusChange = new StatusChange();
            statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(datos.getFxFinValidez(),Constants.TIMEZONE_UTC));
            statusChange.setStatus(Constants.EXPIRED);
            listStatusChange.add(statusChange);

            statusChange = new StatusChange();
            statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(datos.getFxAltaLink(),Constants.TIMEZONE_UTC));
            statusChange.setStatus(Constants.CREATED);
            listStatusChange.add(statusChange);

            if (paid) {
                statusChange = new StatusChange();
                statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(fechaOpOrigen,Constants.TIMEZONE_UTC));
                statusChange.setStatus(Constants.COMPLETED);
                listStatusChange.add(statusChange);
            }

            return listStatusChange;
        }

        return null;
    }

}