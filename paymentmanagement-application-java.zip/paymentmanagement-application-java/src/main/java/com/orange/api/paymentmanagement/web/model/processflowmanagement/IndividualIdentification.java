package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * IndividualIdentification
 */
@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IndividualIdentification implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("identificationId")
	private String identificationId = null;

	@JsonProperty("identificationType")
	private String identificationType = null;
}