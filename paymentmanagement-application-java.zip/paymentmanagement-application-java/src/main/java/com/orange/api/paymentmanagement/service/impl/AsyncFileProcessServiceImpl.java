package com.orange.api.paymentmanagement.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.BpmPrepaidTopUpManagementClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.service.AsyncFileProcessService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.PspFile;
import com.orange.api.paymentmanagement.web.model.TaoFile;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AsyncFileProcessServiceImpl implements AsyncFileProcessService {

    @Value("${aws.s3.bucket-name}")
    private String S3_OSP_MICCLOUD_PAYMENT_BUCKET;

    private String uploadUrl;
    private PaymentMethod paymentMethod;
    private PaymentMethod paymentMethodInput;
    private PaymentMethod paymentMethodUpdate;
    private List<FixedValuesDB> listFixedValues;
    private FixedValuesDB fixedValues;
    private PaymentRegistryDB paymentRegistry;

    private PaymentMethodManagementClient paymentMethodManagementClient;
    private FixedValuesRepository fixedValuesRepository;
    private PaymentRegistryRepository paymentRegistryRepository;
    private BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement;

    @Autowired
    public AsyncFileProcessServiceImpl(PaymentMethodManagementClient paymentMethodManagementClient,
            FixedValuesRepository fixedValuesRepository, PaymentRegistryRepository paymentRegistryRepository,
            BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement) {
        this.paymentMethodManagementClient = paymentMethodManagementClient;
        this.fixedValuesRepository = fixedValuesRepository;
        this.paymentRegistryRepository = paymentRegistryRepository;
        this.bpmPrepaidTopUpManagement = bpmPrepaidTopUpManagement;
    }

    @Override
    @Async
    public CompletableFuture<String> proccesOutputFileProcessing(AmazonS3 s3Client, String fileInputName,
            String processFlowId, java.util.Date expiration, File inputFile, String zApp, String authorizationHeader) {
        log.info("Acceso al servicio de procesamiento asincrono del fichero de TAO");
        // Mapear fichero en un Objeto
        List<TaoFile> taoFileList = new ArrayList();
        taoFileList = mapFileToTaoFile(inputFile);

        File outputFile = new File(fileInputName + "_Enriquecido.csv");

        for (TaoFile taoFile : taoFileList) {
            paymentMethod = new PaymentMethod();
            listFixedValues =  new ArrayList<>();
            fixedValues = new FixedValuesDB();
            paymentRegistry = new PaymentRegistryDB();
            try {
                // Obtener datos del metodo de pago
                log.info("Llamada al PaymentMethod para completar el fichero: " + taoFile.getPaymentMethodId());
                paymentMethod = paymentMethodManagementClient.getPaymentMethodAsync(taoFile.getPaymentMethodId(),
                        Constants.TOKENIZED_CARD, authorizationHeader);
            } catch (Exception e) {
                e.printStackTrace();
                log.error("error en la llamada al PaymentMethodManagement: " + taoFile.getPaymentMethodId());
            }

            try {
                // Obtener datos de valores fijos
                log.info("Obtener registro de FixedValues para completar el fichero");
                listFixedValues = fixedValuesRepository.findByTransactiontypeAndApp(Constants.SCHEDULED_TOP_UP, zApp);
                fixedValues = Optional.ofNullable(listFixedValues).filter(list -> !list.isEmpty())
                        .map(list -> list.get(0)).orElse(null);
            } catch (Exception e) {
                e.printStackTrace();
                log.error("error obteniendo valores fijos. Transactiontype: " + Constants.SCHEDULED_TOP_UP + ". zapp: "
                        + zApp);
            }
            try {
                // Obtener datos del PaymentRegistry
                log.info("Obtener registro de PaymentRegistry para completar el fichero");
                paymentRegistry = paymentRegistryRepository.findByPaymentMethodId(taoFile.getPaymentMethodId());
            } catch (Exception e) {
                e.printStackTrace();
                log.error("error obteniendo registro de PaymentRegistry: " + taoFile.getPaymentMethodId());
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
                writeFile(Optional.ofNullable(fixedValues).map(FixedValuesDB::getClientCode).orElse(Constants.BLANK),
                        writer);

                writeFile(Optional.ofNullable(fixedValues).map(FixedValuesDB::getCommercialCode).orElse(Constants.BLANK), writer);

                // String commercialCode =
                // Optional.ofNullable(paymentMethod.getCharacteristic())
                // .stream()
                // .flatMap(List::stream)
                // .filter(characteristic ->
                // "CommercialCode".equalsIgnoreCase(characteristic.getName()))
                // .map(com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic::getValue)
                // .findFirst()
                // .orElse("");
                // writeFile(commercialCode, writer);

                writeFile(Optional.ofNullable(fixedValues).map(FixedValuesDB::getTerminalCode).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(fixedValues).map(FixedValuesDB::getLanguage).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getOriginOpnumber).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentMethod).map(PaymentMethod::getExpirationDate).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentMethod).map(PaymentMethod::getToken).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getUserId).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(taoFile).map(TaoFile::getAmount).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(fixedValues).map(FixedValuesDB::getCurrency).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable("R").orElse(Constants.BLANK), writer);

                String idCOF = Optional.ofNullable(paymentMethod)
                        .map(PaymentMethod::getExternalIdentifier)
                        .stream()
                        .flatMap(List::stream)
                        .filter(externalIdentifier -> Constants.ID_COF.equalsIgnoreCase(externalIdentifier.getType()))
                        .map(com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.ExternalIdentifier::getId)
                        .findFirst()
                        .orElse(Constants.BLANK);
                writeFile(idCOF, writer);

                writeFile(Optional.ofNullable(taoFile).map(TaoFile::getMsisdn).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getIdDocument).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getUserId).orElse(Constants.BLANK), writer);

                writer.newLine();

            } catch (Exception e) {
                e.printStackTrace();
                log.error("error escribiendo registro del fichero procesado: " + taoFile.toString());
            }
        }
        log.info("Archivo procesado generado exitosamente. Se va a subir al S3");
        // Subir de nuevo el archivo a S3
        uploadHttpFile(outputFile, outputFile.getName(), s3Client, expiration);
        log.info("Archivo procesado subido exitosamente al S3");

        return CompletableFuture.completedFuture("Finalizado el procesamiento del fichero de TAO exitosamente");
    }

    @Override
    @Async
    public CompletableFuture<String> proccesOutputFileValidating(AmazonS3 s3Client, String fileInputName,
            String processFlowId, java.util.Date expiration, File inputFile, String zApp, String authorizationHeader) {
        log.info("Acceso al servicio de procesamiento asincrono del fichero de PSP");
        // Mapear fichero en un Objeto
        List<PspFile> pspFileList = new ArrayList();
        pspFileList = mapFileToPspFile(inputFile);

        File outputFile = new File(fileInputName.replace("Enriquecido.csv.sal", "Procesado.csv"));

        for (PspFile pspFile : pspFileList) {
            paymentRegistry = new PaymentRegistryDB();
            paymentMethod = new PaymentMethod();
            paymentMethodInput = new PaymentMethod();
            paymentMethodUpdate = new PaymentMethod();
            try {
                // Obtener datos del PaymentRegistry
                log.info("Obtener registro de PaymentRegistry para completar el fichero");
                paymentRegistry = paymentRegistryRepository.findByOriginOpnumber(pspFile.getNumeroOperacionOrigen());
            } catch (Exception e) {
                e.printStackTrace();
                log.error("error obteniendo registro de PaymentRegistry: " + pspFile.getNumeroOperacionOrigen());
            }

            try {
                // Obtener datos del metodo de pago
                log.info("Llamada al PaymentMethod para completar el fichero: " + paymentRegistry.getPaymentMethodId());
                paymentMethod = paymentMethodManagementClient.getPaymentMethodAsync(paymentRegistry.getPaymentMethodId(),
                        Constants.TOKENIZED_CARD,authorizationHeader);
            } catch (Exception e) {
                e.printStackTrace();
                log.error(
                        "error en la llamada al PaymentMethodManagement Get: " + paymentRegistry.getPaymentMethodId());
            }

            if (null != pspFile.getCodigoFin() && !Constants.OK.equalsIgnoreCase(pspFile.getCodigoFin())) {
                try {
                    // Actualizar estado del metodo de pago
                    log.info("Llamada al PaymentMethod para actualizar el metodo de pago");
                    paymentMethodInput = new PaymentMethod();
                    paymentMethodInput.setType(Constants.TOKENIZED_CARD);
                    paymentMethodInput.setStatus("Inactive");
                    paymentMethodUpdate = paymentMethodManagementClient
                            .updatePaymentMethodAsync(paymentRegistry.getPaymentMethodId(), paymentMethodInput, authorizationHeader);
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error("error en la llamada al PaymentMethodManagement Update: ", paymentMethodInput.toString());
                }
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getCodigoDeCliente).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getCodigoDeComercio).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getCodigoDeTerminal).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getFechaOperacionOrigen).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getIdioma).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getNumeroOperacionOrigen).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getIdResolutor).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getIdSesion).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getAdquirente).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getFuc).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getMerchant).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getTerminalBancario).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getFechaDeSesion).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getNumeroOperacionNnp).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getNumeroAutorizacion).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getCodigoFin).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getMensajeFin).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getBinDeLaTarjeta).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getMascaraDeLaTarjeta).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getTokenDeLaTarjeta).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getImporte).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getMoneda).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(pspFile).map(PspFile::getTxId_COF).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getTypeDocument).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getIdDocument).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getType).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentRegistry).map(PaymentRegistryDB::getPhonenumber).orElse(Constants.BLANK), writer);

                writeFile(Optional.ofNullable(paymentMethod).map(PaymentMethod::getExpirationDate).orElse(Constants.BLANK), writer);

                writer.newLine();

            } catch (Exception e) {
                e.printStackTrace();
                log.error("error escribiendo registro del fichero validado: " + pspFile.toString());
            }
        }

        log.info("Archivo validado generado exitosamente. Se va a subir al S3");
        // Subir de nuevo el archivo a S3
        uploadHttpFile(outputFile, outputFile.getName(), s3Client, expiration);
        log.info("Archivo validado subido exitosamente al S3");

        // Avisamos a BPM de que hemos generado y subido el fichero
        TaskFlowObj taskFlowObj = new TaskFlowObj();
        List<com.orange.api.paymentmanagement.web.model.processflowmanagement.Characteristic> characteristicList = new ArrayList<com.orange.api.paymentmanagement.web.model.processflowmanagement.Characteristic>();
        com.orange.api.paymentmanagement.web.model.processflowmanagement.Characteristic characteristic = new com.orange.api.paymentmanagement.web.model.processflowmanagement.Characteristic();
        characteristic.setName("ProcessType");
        characteristic.setValue("prepaidTopUpFile");
        characteristicList.add(characteristic);
        taskFlowObj.setCharacteristic(characteristicList);

        try {
            log.info("Peticion bpmPrepaidTopUpManagement: " + taskFlowObj.toString());
            this.bpmPrepaidTopUpManagement.updateFile(processFlowId, taskFlowObj);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("error en la llamada a bpmPrepaidTopUpManagement.");
        }

        return CompletableFuture.completedFuture("Finalizado el procesamiento del fichero Final exitosamente");
    }

    private void writeFile(String text, BufferedWriter writer) throws IOException {
        text = text + Constants.PIPE;
        writer.write(Optional.ofNullable(text).filter(value -> !value.isEmpty()).orElse(Constants.PIPE));
    }

    private void uploadHttpFile(File file, String name, AmazonS3 s3Client, java.util.Date expiration) {

        Optional.ofNullable(s3Client.generatePresignedUrl(S3_OSP_MICCLOUD_PAYMENT_BUCKET, "ScheduledRecharges/" + name,
                expiration, HttpMethod.PUT)).ifPresent(url -> {
                    uploadUrl = url.toString();
                    log.info("Upload URL: {}", uploadUrl);
                });

        try (FileInputStream fis = new FileInputStream(file)) {
            URL url = new URL(uploadUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            conn.getOutputStream().write(IOUtils.toByteArray(fis));
            conn.getInputStream();
            fis.close();
            log.info("Archivo subido correctamente al S3");
            FileUtils.deleteQuietly(file);
        } catch (Exception e) {
            log.error("Error al subir el archivo: {}", e.getMessage());
            FileUtils.deleteQuietly(file);
            throw new RuntimeException("Error al subir el archivo", e);
        }
    }

    private static List<TaoFile> mapFileToTaoFile(File file) {
        List<TaoFile> taoFileList = new ArrayList<>();

        String line = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\\|");

                TaoFile taoFile = new TaoFile();
                taoFile.setMsisdn(getField(fields, 0));
                taoFile.setAmount(getField(fields, 1));
                taoFile.setPaymentMethodId(getField(fields, 2));
                taoFile.setRechargeReason(getField(fields, 3));

                taoFileList.add(taoFile);
            }
        } catch (IOException e) {
            log.error("Error conviritendo el fichero de TAO a Object: " + line);
        }

        return taoFileList;
    }

    private static List<PspFile> mapFileToPspFile(File file) {
        List<PspFile> pspFileList = new ArrayList<>();

        String line = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            while ((line = reader.readLine()) != null) {
                // Split the line using the | delimiter
                String[] fields = line.split("\\|");

                // Create a PaymentDetails object and map fields
                PspFile pspFile = new PspFile();
                pspFile.setCodigoDeCliente(getField(fields, 0));
                pspFile.setCodigoDeComercio(getField(fields, 1));
                pspFile.setCodigoDeTerminal(getField(fields, 2));
                pspFile.setFechaOperacionOrigen(getField(fields, 3));
                pspFile.setIdioma(getField(fields, 4));
                pspFile.setNumeroOperacionOrigen(getField(fields, 5));
                pspFile.setIdResolutor(getField(fields, 6));
                pspFile.setIdSesion(getField(fields, 7));
                pspFile.setAdquirente(getField(fields, 8));
                pspFile.setFuc(getField(fields, 9));
                pspFile.setMerchant(getField(fields, 10));
                pspFile.setTerminalBancario(getField(fields, 11));
                pspFile.setFechaDeSesion(getField(fields, 12));
                pspFile.setNumeroOperacionNnp(getField(fields, 13));
                pspFile.setNumeroAutorizacion(getField(fields, 14));
                pspFile.setCodigoFin(getField(fields, 15));
                pspFile.setMensajeFin(getField(fields, 16));
                pspFile.setBinDeLaTarjeta(getField(fields, 17));
                pspFile.setMascaraDeLaTarjeta(getField(fields, 18));
                pspFile.setTokenDeLaTarjeta(getField(fields, 19));
                pspFile.setImporte(getField(fields, 20));
                pspFile.setMoneda(getField(fields, 21));
                pspFile.setTxId_COF(getField(fields, 22));
                // Add the populated object to the list
                pspFileList.add(pspFile);
            }
        } catch (IOException e) {
            log.error("Error conviritendo el fichero de PSP a Object: " + line);
        }

        return pspFileList;
    }

    private static String getField(String[] fields, int index) {
        return Optional.ofNullable(fields).filter(arr -> arr.length > index).map(arr -> arr[index])
                .orElse(Constants.BLANK);
    }

}
