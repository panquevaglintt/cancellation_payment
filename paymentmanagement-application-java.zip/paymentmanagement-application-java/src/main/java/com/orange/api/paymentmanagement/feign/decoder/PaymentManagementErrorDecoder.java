package com.orange.api.paymentmanagement.feign.decoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiForbbidenException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiInternalServerErrorException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Primary
public class PaymentManagementErrorDecoder implements ErrorDecoder {

    final ErrorDecoder defaultDecoder = new ErrorDecoder.Default();

    @Autowired
    @Setter
    private ObjectMapper objectMapper;

    public PaymentManagementErrorDecoder(){}

    public PaymentManagementErrorDecoder(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public Exception decode(String methodKey, Response response) {
    	
    	if (response.status() == 500) {
            log.warn("La llamada al microservicio ha devuelto error 500");
            return new OpenApiInternalServerErrorException(OpenApiInternalServerErrorException.OrangeCommonError.INTERNAL_ERROR);
        }
    	
    	if (response.status() == 404) {
            log.warn("La llamada al microservicio ha devuelto error 404");
            return new OpenApiNotFoundException(OpenApiNotFoundException.OrangeCommonError.RESOURCE_NOT_FOUND);
        }
    	
        if (response.status() == 403) {
            log.warn("La llamada al microservicio ha devuelto error 403");
            return new OpenApiForbbidenException(OpenApiForbbidenException.OrangeCommonError.FORBIDDEN_USER);
        }
        return defaultDecoder.decode(methodKey, response);
    }

}
