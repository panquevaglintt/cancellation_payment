package com.orange.api.paymentmanagement.utils;

import java.util.List;

/**
 * Class containing microservice constants.
 */
public class Constants {

    public static final String LOG_ENTRADA_CONTROLLER = "Entrada al controller: ";
    public static final String LOG_SALIDA_CONTROLLER = "Salida del controller: ";
    
    public static final String PALABRA_CLAVE = "KGeeR7Ot1vo2";
    public static final String EPAYMENT = "E-PAYMENT";
    public static final String ACE = "ACE";
    public static final String PAID = "Paid - Order in process";
    public static final String DEN = "DEN";
    public static final String EXPIRED = "Expired";
    public static final String EXPIRED_DESC = "Expirado";
    public static final String PREAUTH_EXPIRED = "PreauthorizationExpired";
    public static final String PRO = "PRO";
    public static final String PENDING = "Pending";
    public static final String PREAUTH_PENDING = "PreauthorizationPending";
    public static final String PREAUTH_REALIZED = "PreauthorizationRealized";
    public static final String CERO = "CERO";
    public static final String PAYMENTERROR = "Payment error";
    public static final String PAYMENTERROR_DESC = "Error al realizar el pago";
    public static final String PREAUTH_PAYMENT_ERROR = "PreauthorizationPaymentError";
    public static final String CREATED = "Created";

    public static final String VAP = "VAP";
    public static final String BSCSCODE = "BscsCode";
    public static final String PHONENUMBER = "PhoneNumber";
    public static final String VALIDITYTIME = "ValidityTime";
    public static final String PAYMENTRETRIES = "PaymentRetries";
    public static final String PROCESSFLOW_ID = "ProcessFlowId";
    public static final String CLIENT = "Client";
    public static final String REFERRED_TYPE_INDIVIDUAL = "Individual";
    public static final String REFERRED_TYPE_ORGANIZATION = "Organization";
    public static final String ORANGE = "ORANGE";
    public static final String FDC = "fichadecliente";
    public static final String PANGEA = "pangea";
    public static final String COD_COMERCIO_FDC = "20001";
    public static final String COD_COMERCIO_PANGEA = "20002";
    public static final String COD_TERMINAL = "00000000";
    public static final String ES = "es";
    public static final String TIMEZONE_EUROPE_MADRID = "Europe/Madrid";
    public static final String TIMEZONE_UTC = "UTC";   
    public static final String C_ZULU = "Z";
    public static final String C_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String C_YYYY_MM_DD_T_HH_MM_SSSXXX = "yyyy-MM-dd'T'HH:mm:sssXXX";
    public static final String C_YYYY_MM_DD_T_HH_MM_SS_SSSXXX = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    public static final String C_YYYY_MM_DD_T_HH_MM_SSXXX = "yyyy-MM-dd'T'HH:mm:ssXXX";
    public static final String C_DD_MM_YYYY_HH_MM_SS_Z = "dd/MM/yyyy HH:mm:ss Z";
    public static final String MONEDA = "978";
    public static final String INTENTOS = "3";
    public static final String CO_OPLINK = "0013";
    public static final String TRANSACTION = "TransactionType";
    public static final String MSISDN = "msisdn";
    public static final String DOCUMENTO = "documento";
    public static final String USUARIO = "usuario";
    public static final String PEDIDOCRM = "pedidoCRM";
    public static final String PEDIDOTOL = "pedidoTOL";
    public static final String PAYMENTLINK = "PaymentLink";
    public static final String PENDIENTE_PAGO = "Pendiente de pago";
    public static final String PENDIENTE_PREAUTH = "Pendiente de preautorización";
    public static final String CANCELLED = "Cancelled";
    public static final String PREAUTH_CONFIRMED = "PreauthorizationConfirmed";
    public static final String PREAUTH_CONFIRMED_DESC = "Preatorizacion confirmada";
    public static final String PREAUTH_CONFIRMED_ERROR = "PreauthorizationConfirmationError";
    public static final String PREAUTH_CONFIRMED_ERROR_DESC = "Error al confirmar la preautorizacion";
    public static final String PREAUTH_CONFIRMED_TIMEOUT_RESUL = "Fallo en la llamada al servicio de confirmacion de preautorizacion";
    public static final String PREAUTH_CONFIRMED_TIMEOUT_DESC = "Timeout al realizar la confirmación de preautorización";
    public static final String PREAUTH_CANCELLED = "PreauthorizationCancelled";
    public static final String PREAUTH_CANCELLED_DESC = "Preatorizacion cancelada";
    public static final String PREAUTH_CANCELLED_ERROR = "PreauthorizationCancellationError";
    public static final String PREAUTH_CANCELLED_ERROR_DESC = "Error al cancelar la preautorizacion";
    public static final String PREAUTH_CANCELLED_TIMEOUT_RESUL = "Fallo en la llamada al servicio de cancelacion de preautorizacion";
    public static final String PREAUTH_CANCELLED_TIMEOUT_DESC = "Timeout al realizar la camcelacion de preautorización";
    public static final String CANCELLED_DESC = "Cancelado";
    public static final String CANCELLATION_ERROR = "Cancellation Error";
    public static final String CANCELLATION_ERROR_DESC = "Error al Cancelar";
    public static final String CANCELLATION_ERROR_PSP_RESPONSE_DESC = "Error en la respuesta de PSP al cancelar";
    public static final String CANCELLATION_TIMEOUT_DESC = "Timeout al realizar la cancelación o devolucion";
    public static final String ANNULALATION_TIMEOUT_RESUL = "Fallo en la llamada al servicio de anulación o devolucion";
    public static final String ANNULATION_TIMEOUT_DESC = "Timeout al realizar la anulación o devolucion";
    public static final String PAYMENT_LINK_CANCELLATION_ERROR = "Error al cancelar un payment link";
    public static final String PAYMENT_LINK_CANCELLATION_TIME_OUT_ERROR = "Timeout en la petición al integrationwspsp cancelarLink";
    public static final String PAYMENT_LINK_CANCELLATION_ERROR_DESC = "Error en la petición al integrationwspsp cancelarLink";
    public static final String PAYMENT_LINK_CANCELLATION_OK_STATUS = "PaymentLink cancelado";
    public static final String PAYMENT_LINK_CANCELLATION_OK_DESC = "Se ha cancelado paymentLink correctamente";

    public static final String PAYMENT = "Payment";
    public static final String PAYMENT_REALIZED = "PaymentRealized";
    public static final String PAYMENT_ERROR = "PaymentError";
    public static final String E_PAYMENT = "E-Payment";
    public static final String E_PREAUTH_PAYMENT = "E-PreauthorizationPayment";
    public static final String IFRAME_PREAUTH_PAYMENT = "Iframe-PreauthorizationPayment";
    public static final String TOKEN_PAYMENT = "Token-Payment";
    public static final String COM_DENEGADA = "COM_DENEGADA";
    public static final String UPDATE = "Update";
    public static final String FAILED = "Failed";
    public static final String AUTHORIZATIONCODE = "AuthorizationCode";
    public static final String NNPOPERATIONNUMBER = "NNPOperationNumber";
    public static final String BIN = "Bin";
    public static final String MASK = "Mask";
    public static final String MASKCREDIT = "creditCardMask";
    public static final String TOKEN = "Token";
    public static final String PAYMENTMETHOD = "PaymentMethod";
    public static final String COMMERCIALCODE = "CommercialCode";
    public static final String TERMINAL = "Terminal";
    public static final String PAYMENT_STATUSREASON = "paymentStatusReason";
    public static final String TARJETA = "Tarjeta";
    public static final String BIZUM = "Bizum";
    public static final String EXPIRYDATE = "ExpiryDate";
    public static final String EXPIRATIONDATE = "ExpirationDate";
    public static final String SESSIONID = "SessionId";
    public static final String SESSIONDATE = "SessionDate";
    public static final String RESOLUTORID = "ResolutorId";
    public static final String OPERATIONTYPE = "OperationType";
    public static final String COMPLETED = "Completed";
    public static final String COMPLETED_DESC = "Pago completado";
    public static final String OK = "OK";
    public static final String KO = "KO";
    public static final String NUMOPORIGEN = "NumOpOrigen";
    public static final String EUR = "EUR";
    public static final String BIZUM_PAYMENT = "Bizum-Payment";
    public static final String CHANNEL = "channel";
    public static final String MP_PAYMENT = "MP-Payment";
    public static final String PAYMENT_METHOD_EXTERNAL = "external";
    public static final String PAYMENT_FLOW_MARKETPLACE = "MarketPlace";
    public static final String TRANSACTION_TYPE_MARKETPLACE = "marketplacepurchase";
    public static final String STATUS_RETURNED = "Returned";
    public static final String STATUS_RETURNED_DESC = "Devuelto";
    public static final String RETURNED_ERROR = "Returned Error";
    public static final String RETURNED_ERROR_DESC = "Error en la devolucion";
    public static final String PAYMENT_LINK_TYPE_CANCELLATION = "E-PaymentCancellation";

    // Constante para Iframe
    public static final String C_UTF8 = "UTF-8";
    public static final String REDIRECTION_OK = "PaymentRedirectionOk";
    public static final String REDIRECTION_KO = "PaymentRedirectionKo";
    public static final String BILLINGACCOUNT = "billingAccount";
    public static final String PAYMENTLINKIFRAME = "PaymentIframeLink";
    public static final String URL_IFRAME = "https://www.test.indra-netplus.com/frontal/ventaWeb/iframeVenta.html";
    public static final String PAYMENT_FLOW_IFRAME = "Iframe";
    public static final String TOP_UP = "top_up";

    // Constante para UpdateStatus
    public static final String AMORTIZATION = "amortization";
    public static final String RECOVERY = "recovery";
    public static final String IFRAME = "iframe";
    public static final String PURCHASE = "purchase";
    public static final String CUSTOMER_CODE = "CustomerCode";
    public static final String CUSTCODE = "customer_code";

    // Constante para GenerationPaymentLink
    public static final String PAYMENT_FLOW_PL = "PaymentLink";

    // Constantes para AnnulationPaymentLink
    public static final String ENRQ_PREV_NO_ENCONTRADA = "ENRQ_PREV_NO_ENCONTRADA";
    public static final String ANULLATION_ERROR_RESULT = "Fallo en la llamada al servicio de anulación o devolucion";
    public static final String ANULLATION_ERROR_DESC = "Se ha producido un error en el integrationServiceWSPspClient al anular o devolucion";

    // Constantes para CSV
    public static final Integer TAPARTNER_EXCEL_COLUMN_COUNT = 17;
    public static final String[] TAPARTNER_EXCEL_HEADERS = { "numOpOrigen", "fechaOpOrigen", "codComercio", "Importe",
            "Estado", "metodoPago", "token", "fechaCaducidad", "msisdn", "documento", "numOpOrigenAnulacion",
            "fechaOpOrigenAnulacion", "estadoAnulacion", "vapId", "processFlowId", "numOpOrigenConfirmacion",
            "fechaOpOrigenConfirmacion" };
    public static final String CSV_ENDLINE = "\n";
    public static final String CSV_DELIMITER = ";";
    
    // Constantes para regarga programada
    public static final String SCHEDULED_PAYMENT_PROCCESING = "Scheduled-Payment-Processing";
    public static final String SCHEDULED_PAYMENT_VALIDATING = "Scheduled-Payment-Validating";
    public static final String PIPE = "|";
    public static final String BLANK = "";
    public static final String SCHEDULED_TOP_UP = "scheduled_top_up";
    public static final String TOKENIZED_CARD = "TokenizedCard";
    public static final String ID_COF = "IdCOF";
    
    public static final String IFRAME_SCHEDULED_PAYMENT = "Iframe-ScheduledPayment";
    public static final String SCHEDULED_REQUESTED = "Recarga programada solicitada";
    public static final String SCHEDULED_CONFIRMED = "Recarga programada confirmada";
    public static final String SCHEDULED_ERROR = "Error Recarga Programada";
    public static final String FILE_NAME = "FileName";
    
    public static final List<String> DATE_FORMATS_MARKETPLACE_CREATE = List.of("yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm'Z'");
    

}