package com.orange.api.paymentmanagement.service;

import java.io.File;
import java.util.concurrent.CompletableFuture;

import com.amazonaws.services.s3.AmazonS3;

public interface AsyncFileProcessService {

    CompletableFuture<String> proccesOutputFileProcessing(AmazonS3 s3Client, String fileInputName,
            String processFlowId, java.util.Date expiration, File inputFile, String zApp, String authorizationHeader);
    
    CompletableFuture<String> proccesOutputFileValidating(AmazonS3 s3Client, String fileInputName, String processFlowId,
            java.util.Date expiration, File inputFile, String zApp, String authorizationHeader);
}
