package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

public interface CancellationPreauthorizationPaymentService {


	Payment cancellationPreauthorizationPayment(Payment payment, String numOrigin);
}