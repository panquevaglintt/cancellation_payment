package com.orange.api.paymentmanagement.db.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.orange.api.paymentmanagement.db.entities.PaymentHistoricalRegistryDB;

/**
 * Spring Data repository for the PaymentHistoricalRegistryDB entity
 */

@Repository
public interface PaymentHistoricalRegistryRepository extends JpaRepository<PaymentHistoricalRegistryDB, Long> {

    /**
     * This method obtains all registries.
     * 
     * @return List<PaymentHistoricalRegistryDB>
     */
    List<PaymentHistoricalRegistryDB> findAll();
    
    @Query(value = "call paymentmanagement_app.payment_historical_registry_purge()",nativeQuery = true)
    @Transactional 
    @Modifying(clearAutomatically = true)
    void paymentHistoricalRegistryPurge();

    /**
     * This method deletes all existing registries updated before an input
     * deletionDate.
     * 
     * @param deletionDate
     */
    @Transactional
    @Modifying
    void deleteByUpdateDateBefore(Date deletionDate);

}
