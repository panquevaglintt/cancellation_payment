package com.orange.api.paymentmanagement.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.HttpMethod;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.orange.api.paymentmanagement.service.AsyncFileProcessService;
import com.orange.api.paymentmanagement.service.TransferFileService;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransferFileImpl implements TransferFileService {

    @Value("${aws.s3.bucket-name}")
    private String S3_OSP_MICCLOUD_PAYMENT_BUCKET;

    private String downloadUrl = null;

    private AsyncFileProcessService asyncFileProcessService;

    @Autowired
    public TransferFileImpl(AsyncFileProcessService asyncFileProcessService) {

        this.asyncFileProcessService = asyncFileProcessService;
    }

    @Override
    public Payment paymentProcessingFile(Payment payment, String zApp, String authorizationHeader) {
        // Creamos el cliente de S3
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withEndpointConfiguration(new EndpointConfiguration(
                "bucket.vpce-07839ebe8361d7c9e-2mse82xk.s3.eu-west-1.vpce.amazonaws.com", "eu-west-1")).build();

        String fileInputName = Optional.ofNullable(payment.getCharacteristic()).orElse(Collections.emptyList()).stream()
                .filter(c -> "FileName".equalsIgnoreCase(c.getName())).map(Characteristic::getValue)
                .filter(Objects::nonNull).map(value -> value).findFirst().orElse("");

        String processFlowId = Optional.ofNullable(payment.getCharacteristic()).orElse(Collections.emptyList()).stream()
                .filter(c -> "ProcessFlowId".equalsIgnoreCase(c.getName())).map(Characteristic::getValue)
                .filter(Objects::nonNull).findFirst().orElse("");

        // Descargar archivo de S3
        log.info("Descargando fichero de Tao");
        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 600 * 1000; // 10 mins
        expiration.setTime(expTimeMillis);
        File inputFile = downloadFileFromS3(fileInputName, s3Client, expiration);

        CompletableFuture<String> completableFuture = asyncFileProcessService.proccesOutputFileProcessing(s3Client,
                fileInputName, processFlowId, expiration, inputFile, zApp, authorizationHeader);
        return payment;

    }

    @Override
    public Payment paymentValidatingFile(Payment payment, String zApp, String authorizationHeader) {
        // Creamos el cliente de S3
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withEndpointConfiguration(new EndpointConfiguration(
                "bucket.vpce-07839ebe8361d7c9e-2mse82xk.s3.eu-west-1.vpce.amazonaws.com", "eu-west-1")).build();

        String fileInputName = Optional.ofNullable(payment.getCharacteristic()).orElse(Collections.emptyList()).stream()
                .filter(c -> "FileName".equalsIgnoreCase(c.getName())).map(Characteristic::getValue)
                .filter(Objects::nonNull).map(value -> value).findFirst().orElse("");

        String processFlowId = Optional.ofNullable(payment.getCharacteristic()).orElse(Collections.emptyList()).stream()
                .filter(c -> "ProcessFlowId".equalsIgnoreCase(c.getName())).map(Characteristic::getValue)
                .filter(Objects::nonNull).findFirst().orElse("");

        // Descargar archivo de S3
       log.info("Descargando fichero de Psp");
        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 600 * 1000; // 10 mins
        expiration.setTime(expTimeMillis);
        File inputFile = downloadFileFromS3(fileInputName, s3Client, expiration);

        CompletableFuture<String> completableFuture = asyncFileProcessService.proccesOutputFileValidating(s3Client,
                fileInputName, processFlowId, expiration, inputFile, zApp, authorizationHeader);
        return payment;

    }

    private File downloadFileFromS3(String nameFile, AmazonS3 s3Client, java.util.Date expiration) {
        File inputFile = null;

        Optional.ofNullable(s3Client.generatePresignedUrl(S3_OSP_MICCLOUD_PAYMENT_BUCKET,
                "ScheduledRecharges/" + nameFile, expiration, HttpMethod.GET)).ifPresent(url -> {
                    downloadUrl = url.toString();
                    log.info("Download URL: {}", downloadUrl);
                });
        try (InputStream in = new URL(downloadUrl).openStream()) {
            inputFile = new File("src/main/resources/" + nameFile);
            FileUtils.copyInputStreamToFile(in, inputFile);
            log.info("Archivo descargado exitosamente.");
        } catch (IOException e) {
            log.error("Error al descargar archivo: {}", e.getMessage());
            throw new RuntimeException("Error descargando archivo de S3", e);
        }
        return inputFile;
    }

}
