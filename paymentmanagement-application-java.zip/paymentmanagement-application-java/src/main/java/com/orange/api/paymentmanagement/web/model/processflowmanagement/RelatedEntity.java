package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.StatusChange;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@referredType")
	private String referredType;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("name")
	private String name;

	@JsonProperty("role")
	private String role;

	@JsonProperty("token")
	private String token;

	@JsonProperty("description")
	private String description;

	@JsonProperty("url")
	private String url;

	@JsonProperty("status")
	private String status;

	@JsonProperty("totalAmount")
	private Money totalAmount;

	@Valid
	@JsonProperty("paymentItem")
	private List<PaymentItem> paymentItem;

	@Valid
	@JsonProperty("statusChange")
	private List<StatusChange> statusChange;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}