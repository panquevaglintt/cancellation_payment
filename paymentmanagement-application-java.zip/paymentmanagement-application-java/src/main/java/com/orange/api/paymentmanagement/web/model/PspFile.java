package com.orange.api.paymentmanagement.web.model;
import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PspFile {

    @JsonProperty("codigoDeCliente")
    private String codigoDeCliente;

    @JsonProperty("codigoDeComercio")
    private String codigoDeComercio;

    @JsonProperty("codigoDeTerminal")
    private String codigoDeTerminal;

    @JsonProperty("fechaOperacionOrigen")
    private String fechaOperacionOrigen;

    @JsonProperty("idioma")
    private String idioma;

    @JsonProperty("numeroOperacionOrigen")
    private String numeroOperacionOrigen;

    @JsonProperty("idResolutor")
    private String idResolutor;

    @JsonProperty("idSesion")
    private String idSesion;

    @JsonProperty("adquirente")
    private String adquirente;

    @JsonProperty("fuc")
    private String fuc;

    @JsonProperty("merchant")
    private String merchant;

    @JsonProperty("terminalBancario")
    private String terminalBancario;

    @JsonProperty("fechaDeSesion")
    private String fechaDeSesion;

    @JsonProperty("numeroOperacionNnp")
    private String numeroOperacionNnp;

    @JsonProperty("numeroAutorizacion")
    private String numeroAutorizacion;

    @JsonProperty("codigoFin")
    private String codigoFin;

    @JsonProperty("mensajeFin")
    private String mensajeFin;

    @JsonProperty("binDeLaTarjeta")
    private String binDeLaTarjeta;

    @JsonProperty("mascaraDeLaTarjeta")
    private String mascaraDeLaTarjeta;

    @JsonProperty("tokenDeLaTarjeta")
    private String tokenDeLaTarjeta;

    @JsonProperty("importe")
    private String importe;

    @JsonProperty("moneda")
    private String moneda;

    @JsonProperty("txId_COF")
    private String txId_COF;
}
