package com.orange.api.paymentmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.ObjectUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.mappers.PaymentMarketPlaceMapper;
import com.orange.api.paymentmanagement.service.GenerationPaymentMarketPlaceService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GenerationPaymentMarketPlaceServiceImpl implements GenerationPaymentMarketPlaceService {


    private PaymentRegistryRepository paymentRegistryRepository;
    private FixedValuesRepository fixedValuesRepository;

    @Autowired
    public GenerationPaymentMarketPlaceServiceImpl(
    		PaymentRegistryRepository paymentmanagementRepository,
    		FixedValuesRepository fixedValuesRepository) {

        this.paymentRegistryRepository = paymentmanagementRepository;
        this.fixedValuesRepository = fixedValuesRepository;
    }
    
    /**
     * Get fixedValues from BBDD
     * 
     * @param payment
     * @param app
     * @param transactiontype
     * @return
     */
    private FixedValuesDB getFixedValues(String app, String transactiontype) {

        List<FixedValuesDB> listFixedValues = this.fixedValuesRepository
                .findByTransactiontypeAndApp(transactiontype.toLowerCase(), app.toLowerCase());

        if (!ObjectUtils.isEmpty(listFixedValues)) {
            return listFixedValues.get(0);
        } else {
            log.error("La transacción o zapp no coincide con lo esperado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
        }
    }

    @Override
    public Payment generationPaymentMarketPlace(Payment payment, String app, String zlogin) {
    	
        String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.TRANSACTION);
        FixedValuesDB fixedValues = getFixedValues(app, transactiontype);

        registerPaymentMarketPlace(payment, app, transactiontype, zlogin, fixedValues);

        log.info("Se ha generado paymentMarketPlace con Numero Operacion Origen: " + payment.getId());

        return payment;
    }

   

    /**
     * Register paymentMarketPlace to BBDD
     * 
     * @param payment
     * @param app
     * @param fixedValues
     * @param transactiontype
     * @param requestWS
     * @param zlogin
     * @param responseGeneration
     */
    private void registerPaymentMarketPlace(Payment payment, String app, String transactiontype,
            String zlogin, FixedValuesDB fixedValues) {

        this.paymentRegistryRepository.save(PaymentMarketPlaceMapper.mapPaymentManagementDB(payment, app,
               transactiontype, fixedValues, zlogin));
        log.info("Se ha registrado el paymentMarketPlace en BBDD");

    }

}