package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface GenerationPreauthorizationPaymentLinkService {
	

	Payment generationPreauthorizationPaymentLink(Payment payment, String app, String zlogin, String zCallerIp);

}