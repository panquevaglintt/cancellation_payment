package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MediumCharacteristic implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("city")
	private String city;

	@JsonProperty("country")
	private String country;

	@JsonProperty("emailAddress")
	private String emailAddress;

	@JsonProperty("phoneNumber")
	private String phoneNumber;

	@JsonProperty("postCode")
	private String postCode;

	@JsonProperty("stateOrProvince")
	private String stateOrProvince;

	@JsonProperty("street1")
	private String street1;

	@JsonProperty("street2")
	private String street2;
}