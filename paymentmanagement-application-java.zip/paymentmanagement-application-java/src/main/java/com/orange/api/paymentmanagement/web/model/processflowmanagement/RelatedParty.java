package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedParty implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("@referredType")
	private String referredType;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("name")
	private String name;

	@JsonProperty("role")
	private String role;

	@Valid
	@JsonProperty("individualIdentification")
	private List<IndividualIdentification> individualIdentification;

	@Valid
	@JsonProperty("organizationIdentification")
	private List<OrganizationIdentification> organizationIdentification;

	@Valid
	@JsonProperty("contactMedium")
	private List<ContactMedium> contactMedium;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}