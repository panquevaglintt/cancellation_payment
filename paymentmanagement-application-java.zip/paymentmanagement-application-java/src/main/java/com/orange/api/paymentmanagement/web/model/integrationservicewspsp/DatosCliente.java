package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosCliente implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("coCliente")
	private String coCliente;

	@JsonProperty("coComercio")
	private String coComercio;

	@JsonProperty("coTerminal")
	private String coTerminal;

	@JsonProperty("palabraClave")
	private String palabraClave;
}