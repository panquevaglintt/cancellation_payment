package com.orange.api.paymentmanagement.service.impl;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.mappers.GenerationTokenPaymentMapper;
import com.orange.api.paymentmanagement.service.GenerationTokenPaymentService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.OrganizationIdentification;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentMethodRefOrValue;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestTokenPayment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseTokenPayment;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GenerationTokenPaymentServiceImpl implements GenerationTokenPaymentService{
    
    private FixedValuesRepository fixedValuesRepository;
    private PaymentRegistryRepository paymentRegistryRepository;
    private PaymentMethodManagementClient paymentmethodmanagement;
    private IntegrationServiceWSPspClient integrationServiceWSPspClient;
    
    public GenerationTokenPaymentServiceImpl(FixedValuesRepository fixedValuesRepository, PaymentRegistryRepository paymentRegistryRepository,
            PaymentMethodManagementClient paymentmethodmanagement, IntegrationServiceWSPspClient integrationServiceWSPspClient) {
        this.fixedValuesRepository = fixedValuesRepository;
        this.paymentRegistryRepository = paymentRegistryRepository;
        this.paymentmethodmanagement = paymentmethodmanagement;
        this.integrationServiceWSPspClient = integrationServiceWSPspClient;
    }

    @Override
    public Payment generationTokenPayment(Payment payment, String zApp, String zLogin, String zCallerIp) {

        String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.TRANSACTION);
        PaymentRegistryDB paymentRegistryDB = this.paymentRegistryRepository.findByPaymentMethodId(payment.getPaymentMethod().getId());
        if(ObjectUtils.isEmpty(paymentRegistryDB)) {
            log.error("No se han encontrado registros en la tabla payment registry");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
        }else {
        	log.error("Se ha recuperado el siguente registro de base de datos: " + paymentRegistryDB.toString());
        }
        FixedValuesDB fixedValues = getFixedValues(zApp, transactiontype);
        
        PaymentMethod responseGet = null;
        responseGet = this.paymentmethodmanagement.getPaymentMethod(payment.getPaymentMethod().getId(), Constants.TOKENIZED_CARD);
        
        RequestTokenPayment pspWsRequest = null;
        pspWsRequest = GenerationTokenPaymentMapper.mapPspWsRequest(fixedValues, payment, zLogin,transactiontype, zCallerIp, paymentRegistryDB, responseGet);
        
        log.info("Se llama al integration PSP con la petición: " + pspWsRequest.toString());
        ResponseTokenPayment responseReturned = new ResponseTokenPayment();
        responseReturned = this.integrationServiceWSPspClient.tokenPayment(pspWsRequest);
        log.info("Se recuperan los siguientes datos del integration PSP: " + responseReturned.toString());
        
        Payment paymentResponse = new Payment();
        paymentResponse.setId(responseReturned.getNumOpOrigen());
        paymentResponse.setType(Constants.TOKEN_PAYMENT);
        if(ObjectUtils.isNotEmpty(responseReturned.getResultadoOperacion()) && Constants.OK.equalsIgnoreCase(responseReturned.getResultadoOperacion().getCodigo())) {
            paymentResponse.setStatus(Constants.PAYMENT_REALIZED);
        }
        paymentResponse.setStatusDate(PaymentManagementUtils.extractDate(responseReturned.getFechaOpOrigen(), Constants.TIMEZONE_EUROPE_MADRID, Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX));
        
        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
        paymentMethod.setDescription(Constants.TARJETA);
        paymentResponse.setPaymentMethod(paymentMethod);
        List<Characteristic> characteristicList = new ArrayList<>();
        fillToken(paymentRegistryDB, characteristicList);
        fillMask(responseReturned, characteristicList);
        fillPaymentMethod(characteristicList);
        fillExpirationDate(responseGet, characteristicList);
        paymentResponse.setCharacteristic(characteristicList);
        fillIndividualIdentification(responseGet, paymentResponse);
        fillOrganizationIdentification(responseGet, paymentResponse);
        
        int year = Integer.parseInt(responseGet.getExpirationDate().substring(0, 2));
        int month = Integer.parseInt(responseGet.getExpirationDate().substring(2, 4));
        year += 2000;
        
        YearMonth fechaExpirado = YearMonth.of(year, month);
        LocalDate fechaActual = LocalDate.now();
        
        //Si el resultado devuelto por psp es un error COM_DENEGADA se pone como type PaymentError
        if(checkCode(responseReturned) || checkExpirationDate(fechaExpirado, fechaActual)) {
            paymentResponse.setType(Constants.PAYMENT_ERROR);
        }

        return paymentResponse;
    }

    /**
     * @param fechaExpirado
     * @param fechaActual
     * @return
     */
    public boolean checkExpirationDate(YearMonth fechaExpirado, LocalDate fechaActual) {
        return fechaExpirado.getYear()<= fechaActual.getYear() && fechaExpirado.getMonthValue() < fechaActual.getMonthValue();
    }

    /**
     * @param responseReturned
     * @return
     */
    public boolean checkCode(ResponseTokenPayment responseReturned) {
        return ObjectUtils.isNotEmpty(responseReturned.getResultadoOperacion()) && Constants.COM_DENEGADA.equalsIgnoreCase(responseReturned.getResultadoOperacion().getCodigo());
    }

    /**
     * @param responseGet
     * @param paymentResponse
     */
    public void fillOrganizationIdentification(PaymentMethod responseGet, Payment paymentResponse) {
        Optional.ofNullable(responseGet.getRelatedParty())
                .filter(relatedParty -> Constants.REFERRED_TYPE_ORGANIZATION.equalsIgnoreCase(relatedParty.getReferredType()))
                .ifPresent(relatedParty -> {
                    RelatedParty payer = new RelatedParty();
                    payer.setReferredType(relatedParty.getReferredType());
                    payer.setRole(Constants.CLIENT);

                    List<OrganizationIdentification> organizationList = Optional.ofNullable(relatedParty.getOrganizationIdentification())
                            .filter(list -> !list.isEmpty())
                            .map(orgIdentifications -> {
                                OrganizationIdentification organization = new OrganizationIdentification();
                                organization.setIdentificationType(Optional.ofNullable(orgIdentifications.get(0).getIdentificationType()).orElse(""));
                                organization.setIdentificationId(Optional.ofNullable(orgIdentifications.get(0).getIdentificationId()).orElse(""));
                                return List.of(organization);
                            })
                            .orElseGet(ArrayList::new);

                    payer.setOrganizationIdentification(organizationList);
                    paymentResponse.setPayer(payer);
                });
    }

    /**
     * @param responseGet
     * @param paymentResponse
     */
    public void fillIndividualIdentification(PaymentMethod responseGet, Payment paymentResponse) {
        Optional.ofNullable(responseGet.getRelatedParty())
                .filter(relatedParty -> Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(relatedParty.getReferredType()))
                .ifPresent(relatedParty -> {
                    RelatedParty payer = new RelatedParty();
                    payer.setReferredType(relatedParty.getReferredType());
                    payer.setRole(Constants.CLIENT);

                    List<IndividualIdentification> individualList = Optional.ofNullable(relatedParty.getIndividualIdentification())
                            .filter(list -> !list.isEmpty())
                            .map(individualIdentifications -> {
                                IndividualIdentification individual = new IndividualIdentification();
                                individual.setIdentificationType(
                                        Optional.ofNullable(individualIdentifications.get(0).getIdentificationType()).orElse(""));
                                individual.setIdentificationId(
                                        Optional.ofNullable(individualIdentifications.get(0).getIdentificationId()).orElse(""));
                                return List.of(individual);
                            })
                            .orElseGet(ArrayList::new); // Provide an empty list if individualIdentification is null or empty.

                    payer.setIndividualIdentification(individualList);
                    paymentResponse.setPayer(payer);
                });
    }

    public void fillExpirationDate(PaymentMethod responseGet, List<Characteristic> characteristicList) {
        Characteristic characteristic;
        if(StringUtils.isNotEmpty(responseGet.getExpirationDate())) {
            characteristic = new Characteristic();
            characteristic.setName(Constants.EXPIRATIONDATE);
            characteristic.setValue(responseGet.getExpirationDate());
            characteristicList.add(characteristic);
        }
    }

    public void fillPaymentMethod(List<Characteristic> characteristicList) {
        Characteristic characteristic;
        characteristic = new Characteristic();
        characteristic.setName(Constants.PAYMENTMETHOD);
        characteristic.setValue(Constants.TARJETA);
        characteristicList.add(characteristic);
    }

    public void fillMask(ResponseTokenPayment responseReturned, List<Characteristic> characteristicList) {
        Characteristic characteristic;
        if(ObjectUtils.isNotEmpty(responseReturned.getDatosTarjeta()) && StringUtils.isNotEmpty(responseReturned.getDatosTarjeta().getMascara())) {
            characteristic = new Characteristic();
            characteristic.setName(Constants.MASK);
            characteristic.setValue(responseReturned.getDatosTarjeta().getMascara());
            characteristicList.add(characteristic);
        }
    }

    public void fillToken(PaymentRegistryDB paymentRegistryDB, List<Characteristic> characteristicList) {
        Characteristic characteristic;
        if(StringUtils.isNotEmpty(paymentRegistryDB.getToken())) {
            characteristic = new Characteristic();
            characteristic.setName(Constants.TOKEN);
            characteristic.setValue(paymentRegistryDB.getToken());
            characteristicList.add(characteristic);
        }
    }
    
    private FixedValuesDB getFixedValues(String app, String transactiontype) {
        
        List<FixedValuesDB> listFixedValues = this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(transactiontype, app, Constants.IFRAME);
        
        if (!ObjectUtils.isEmpty(listFixedValues)) {
            return listFixedValues.get(0);
        } else {
            log.error("La transacción o zapp no coincide con lo esperado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
        }       
    }

}
