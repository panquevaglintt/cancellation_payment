package com.orange.api.paymentmanagement.mappers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosTarjetaTP;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestTokenPayment;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.ExternalIdentifier;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;

public class GenerationTokenPaymentMapper {

    public static RequestTokenPayment mapPspWsRequest(FixedValuesDB fixedValues, Payment payment, String zLogin,
            String transactiontype, String zCallerIp, PaymentRegistryDB paymentRegistryDB, PaymentMethod responseGet) {
        RequestTokenPayment requestGeneration = new RequestTokenPayment();
        DatosCliente datosCliente = new DatosCliente();
        datosCliente.setCoCliente(fixedValues.getClientCode());
        datosCliente.setCoComercio(fixedValues.getCommercialCode());
        datosCliente.setCoTerminal(fixedValues.getTerminalCode());
        datosCliente.setPalabraClave(fixedValues.getKeyword());
        
        DatosTarjetaTP datosTarjeta = new DatosTarjetaTP();
        datosTarjeta.setFechaCaducidad(responseGet.getExpirationDate());
        datosTarjeta.setToken(paymentRegistryDB.getToken());
        
        ParametrosAdicionales parametrosAdicionales = new ParametrosAdicionales();
        List<Entry> parametrosAdicionalesList = new ArrayList<>();
        Entry entry = new Entry();
        
        for (Characteristic characteristic : payment.getCharacteristic()) {
            
            if(Constants.PHONENUMBER.equalsIgnoreCase(characteristic.getName()) && StringUtils.isNotEmpty(characteristic.getValue())) {
                entry = new Entry();
                entry.setKey(Constants.MSISDN);
                entry.setValue(characteristic.getValue());
                parametrosAdicionalesList.add(entry);
            }
            
            if(Constants.PROCESSFLOW_ID.equalsIgnoreCase(characteristic.getName()) && StringUtils.isNotEmpty(characteristic.getValue())) {
                entry = new Entry();
                entry.setKey(Constants.PEDIDOCRM);
                entry.setValue(characteristic.getValue());
                parametrosAdicionalesList.add(entry);
            }
            
        }
        
        if(StringUtils.isNotEmpty(zLogin)) {
            entry = new Entry();
            entry.setKey(Constants.USUARIO);
            entry.setValue(zLogin);
            parametrosAdicionalesList.add(entry);
        }
        
        if(StringUtils.isNotEmpty(paymentRegistryDB.getCustCode())) {
            entry.setKey(Constants.CUSTCODE);
            entry.setValue(paymentRegistryDB.getCustCode());
            parametrosAdicionalesList.add(entry);
        }
        
        if(StringUtils.isNotEmpty(zCallerIp)) {
            entry = new Entry();
            entry.setKey(Constants.PEDIDOTOL);
            entry.setValue(zCallerIp);
            parametrosAdicionalesList.add(entry);
        }
        
        parametrosAdicionales.setEntry(parametrosAdicionalesList);
        
        requestGeneration.setDatosCliente(datosCliente);
        requestGeneration.setFechaOpOrigen(mapDate());
        requestGeneration.setIdioma(fixedValues.getLanguage());
        requestGeneration.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        requestGeneration.setImporte(payment.getTotalAmount().getValue().longValue());
        requestGeneration.setMoneda(fixedValues.getCurrency());
        requestGeneration.setParametrosAdicionales(parametrosAdicionales);
        requestGeneration.setDatosTarjeta(datosTarjeta);
        for (ExternalIdentifier externalIdentifier : responseGet.getExternalIdentifier()) {
            if(Constants.ID_COF.equalsIgnoreCase(externalIdentifier.getType()) && StringUtils.isNotEmpty(externalIdentifier.getId())) {
                requestGeneration.setTxId_COF(externalIdentifier.getId());
            }
        }
        requestGeneration.setPagoRecurrente("R");
        
        return requestGeneration;
    }
    
    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }
    
}
