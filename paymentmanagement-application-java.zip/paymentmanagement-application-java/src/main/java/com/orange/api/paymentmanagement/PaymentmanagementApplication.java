package com.orange.api.paymentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * SpringBoot application starter for Paymentmanagement.
 */
@SpringBootApplication
@EnableFeignClients
@EnableAsync
public class PaymentmanagementApplication {

	/**
	 * Constructor.
	 * 
	 * @param args Arguments
	 */
	public static void main(String[] args) {
		// Metodo que inicializa el microservicio.
		SpringApplication.run(PaymentmanagementApplication.class, args); // NOSONAR
	}
	
}