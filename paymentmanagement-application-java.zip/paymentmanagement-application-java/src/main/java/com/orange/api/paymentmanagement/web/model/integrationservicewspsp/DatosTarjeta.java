package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data

public class DatosTarjeta implements Serializable {
	private static final long serialVersionUID = 1L;
	  
	  @JsonProperty("bin")
	  private String bin;

	  @JsonProperty("mascara")
	  private String mascara;

	  @JsonProperty("numeroCifrado")
	  private String numeroCifrado;
	

	
}