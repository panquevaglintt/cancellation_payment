package com.orange.api.paymentmanagement.mappers;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.StatusChange;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.ExternalIdentifier;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.Characteristic;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.OrganizationIdentification;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.ProcessInstanceObj;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.RelatedEntity;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.RelatedParty;
import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;


public final class UpdateStatusPaymentMapper {


    public static void mapPaymentToTaskFlowObj(Payment body, TaskFlowObj taskFlowObj,
            PaymentRegistryDB paymentRegistryDB, String id) {
        taskFlowObj.setRelatedEntity(mapRelatedEntity(body, id));
        taskFlowObj.setRelatedParty(mapRelatedParty(paymentRegistryDB));
    }
    
    public static void mapPaymentToTaskFlowObjBpmPfSales(Payment body, TaskFlowObj taskFlowObj,
            PaymentRegistryDB paymentRegistryDB, String id) {
        taskFlowObj.setRelatedEntity(mapRelatedEntityBpmPfSales(body, id, paymentRegistryDB));
        taskFlowObj.setRelatedParty(mapRelatedParty(paymentRegistryDB));
    }
    
    public static void mapPaymentToTaskFlowObjbpmScheduled(Payment body, TaskFlowObj taskFlowObj,
            PaymentRegistryDB paymentRegistryDB, PaymentMethod paymentMethod) {
        List<Characteristic> characteristicList = new ArrayList<Characteristic>();
        Characteristic characteristic = new Characteristic();
        characteristic = new Characteristic();
        characteristic.setName("ProcessType");
        characteristic.setValue("prepaidTopUpProgram");
        characteristicList.add(characteristic);
        taskFlowObj.setCharacteristic(characteristicList);

        List<RelatedEntity> listRelatedEntity = new ArrayList<RelatedEntity>();
        RelatedEntity relatedEntity = new RelatedEntity();
        relatedEntity.setReferredType(Constants.PAYMENT);
        relatedEntity.setType(Constants.E_PAYMENT);
        relatedEntity.setId(paymentMethod.getId());
        if (!CollectionUtils.isEmpty(body.getStatusChange())) {
            relatedEntity.setStatus(mapStatus(body.getStatusChange()));
        }else {
            relatedEntity.setStatus(Constants.PAID);
        }
        
        listRelatedEntity.add(relatedEntity);
        taskFlowObj.setRelatedEntity(listRelatedEntity);

    }
    
    public static PaymentMethod mapCreatePaymentMethod(Payment body, PaymentRegistryDB paymentManagementDB) {
        PaymentMethod paymentMethodInput = new PaymentMethod();
        paymentMethodInput.setType(Constants.TOKENIZED_CARD);
        paymentMethodInput.setToken(body.getPaymentMethod().getToken());
        for ( com.orange.api.paymentmanagement.web.model.Characteristic characteristic: body.getPaymentMethod().getCharacteristic()) {
            if ("expirationDate".equalsIgnoreCase(characteristic.getName())){
                paymentMethodInput.setExpirationDate(characteristic.getValue());  
            }
        }
        List<ExternalIdentifier> externalIdentifierList = new ArrayList<>();
        ExternalIdentifier externalIdentifier = new ExternalIdentifier();
        externalIdentifier.setType(Constants.ID_COF);
        for ( com.orange.api.paymentmanagement.web.model.Characteristic characteristic: body.getCharacteristic()) {
            if (Constants.ID_COF.equalsIgnoreCase(characteristic.getName())){
                externalIdentifier.setId(characteristic.getValue());  
            }
        }
        externalIdentifierList.add(externalIdentifier);
        paymentMethodInput.setExternalIdentifier(externalIdentifierList);
        
        List<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic> characteristicList = new ArrayList<>();
        
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic characteristicPhoneNumber = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic();
        characteristicPhoneNumber.setName(Constants.PHONENUMBER);
        characteristicPhoneNumber.setValue(paymentManagementDB.getPhonenumber());
        characteristicList.add(characteristicPhoneNumber);
        
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic characteristicCardMask = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic();
        characteristicCardMask.setName(Constants.MASKCREDIT);
        for ( com.orange.api.paymentmanagement.web.model.Characteristic characteristic: body.getPaymentMethod().getCharacteristic()) {
            if (Constants.MASKCREDIT.equalsIgnoreCase(characteristic.getName())){
                characteristicCardMask.setValue(characteristic.getValue()); 
            }
        }
        characteristicList.add(characteristicCardMask);
        
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic characteristicCommercialCode = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.Characteristic();
        characteristicCommercialCode.setName(Constants.COMMERCIALCODE);
        characteristicCommercialCode.setValue(paymentManagementDB.getCommercialCode());
        characteristicList.add(characteristicCommercialCode);
        
        paymentMethodInput.setCharacteristic(characteristicList);
        
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.RelatedParty relatedParty = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.RelatedParty();
        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(paymentManagementDB.getType())) {
            relatedParty.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
            List<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification> individualIdentificationList = new ArrayList<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification>();
            com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification individualIdentification = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification();
            individualIdentification.setIdentificationType(paymentManagementDB.getTypeDocument());
            individualIdentification.setIdentificationId(paymentManagementDB.getIdDocument());
            individualIdentificationList.add(individualIdentification);              
            relatedParty.setIndividualIdentification(individualIdentificationList);
            
        }else if (Constants.REFERRED_TYPE_ORGANIZATION.equalsIgnoreCase(paymentManagementDB.getType())) {
            relatedParty.setReferredType(Constants.REFERRED_TYPE_ORGANIZATION);
            List<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification> organizationIdentificationList = new ArrayList<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification>();
            com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification organizationIdentification = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification();
            organizationIdentification.setIdentificationType(paymentManagementDB.getTypeDocument());
            organizationIdentification.setIdentificationId(paymentManagementDB.getIdDocument());
            organizationIdentificationList.add(organizationIdentification);
            relatedParty.setOrganizationIdentification(organizationIdentificationList);
        }
        paymentMethodInput.setRelatedParty(relatedParty);
        return paymentMethodInput;
    }

    private static List<RelatedParty> mapRelatedParty(PaymentRegistryDB paymentRegistryDB) {
        List<RelatedParty> listRelatedParty = new ArrayList<RelatedParty>();
        RelatedParty relatedParty = new RelatedParty();
        relatedParty.setReferredType(paymentRegistryDB.getType());
        relatedParty.setRole(Constants.CLIENT);
        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(paymentRegistryDB.getType())) {
            List<IndividualIdentification> listIndividualIdentification = new ArrayList<IndividualIdentification>();
            IndividualIdentification individualIdentification = new IndividualIdentification();
            individualIdentification.setIdentificationId(paymentRegistryDB.getIdDocument());
            individualIdentification.setIdentificationType(paymentRegistryDB.getTypeDocument());
            listIndividualIdentification.add(individualIdentification);
            relatedParty.setIndividualIdentification(listIndividualIdentification);
        } else {
            List<OrganizationIdentification> listOrganizationIdentification = new ArrayList<OrganizationIdentification>();
            OrganizationIdentification organizationIdentification = new OrganizationIdentification();
            organizationIdentification.setIdentificationId(paymentRegistryDB.getIdDocument());
            organizationIdentification.setIdentificationType(paymentRegistryDB.getTypeDocument());
            listOrganizationIdentification.add(organizationIdentification);
            relatedParty.setOrganizationIdentification(listOrganizationIdentification);
        }

        listRelatedParty.add(relatedParty);

        return listRelatedParty;
    }

    private static List<RelatedEntity> mapRelatedEntity(Payment body, String id) {
        List<RelatedEntity> listRelatedEntity = new ArrayList<RelatedEntity>();

        RelatedEntity relatedEntity = new RelatedEntity();

        relatedEntity.setReferredType(Constants.PAYMENT);
        if(StringUtils.isEmpty(body.getType())){
            relatedEntity.setType(Constants.E_PAYMENT);
        } else {
            relatedEntity.setType(body.getType());
        }
        relatedEntity.setId(id);
        relatedEntity.setStatus(mapStatus(body.getStatusChange()));
        if(!CollectionUtils.isEmpty(body.getStatusChange())) {
        relatedEntity.setStatusChange(mapStatusChange(body.getStatusChange(), Constants.UPDATE));
        }
        if(!CollectionUtils.isEmpty(body.getCharacteristic())) {
        relatedEntity.setCharacteristic(mapCharacteristic(body));
        }

        listRelatedEntity.add(relatedEntity);

        return listRelatedEntity;
    }
    
    private static List<RelatedEntity> mapRelatedEntityBpmPfSales(Payment body, String id, PaymentRegistryDB paymentRegistryDB) {
        List<RelatedEntity> listRelatedEntity = new ArrayList<RelatedEntity>();

        RelatedEntity relatedEntity = new RelatedEntity();

        relatedEntity.setReferredType(Constants.PAYMENT);
        if (StringUtils.isNotEmpty(paymentRegistryDB.getHash())) {
            relatedEntity.setType(Constants.IFRAME_PREAUTH_PAYMENT);
        } else {
            relatedEntity.setType(Constants.E_PREAUTH_PAYMENT);
        }
            
        relatedEntity.setId(id);
        relatedEntity.setStatus(mapStatusBpmPfSales(body.getStatusChange()));
        if(!CollectionUtils.isEmpty(body.getStatusChange())) {
        relatedEntity.setStatusChange(mapStatusChange(body.getStatusChange(), Constants.CREATED));
        }
        if(!CollectionUtils.isEmpty(body.getCharacteristic())) {
        relatedEntity.setCharacteristic(mapCharacteristicBpmPfSales(body, paymentRegistryDB));
        }
        if(!ObjectUtils.isEmpty(body.getTotalAmount())) {
        relatedEntity.setTotalAmount(body.getTotalAmount());
        relatedEntity.getTotalAmount().setUnit(Constants.EUR);
        }
        
        listRelatedEntity.add(relatedEntity);

        return listRelatedEntity;
    }

    private static List<Characteristic> mapCharacteristic(Payment body) {
        List<Characteristic> Characteristic = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();
        characteristic.setName(Constants.AUTHORIZATIONCODE);
        characteristic.setValue(body.getAuthorizationCode());
        Characteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.NNPOPERATIONNUMBER);
        characteristic.setValue(body.getCorrelatorId());
        Characteristic.add(characteristic);

        if (body.getPaymentMethod() != null && body.getPaymentMethod().getToken() != null) {
            characteristic = new Characteristic();
            characteristic.setName(Constants.BIN);
            characteristic.setValue(mapCharacteristicCard(body.getPaymentMethod().getCharacteristic(), Constants.BIN));
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.MASK);
            characteristic
                    .setValue(mapCharacteristicCard(body.getPaymentMethod().getCharacteristic(), Constants.MASKCREDIT));
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.TOKEN);
            characteristic.setValue(body.getPaymentMethod().getToken());
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.PAYMENTMETHOD);
            characteristic.setValue(Constants.TARJETA);
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.EXPIRYDATE);
            characteristic.setValue(
                    mapCharacteristicCard(body.getPaymentMethod().getCharacteristic(), Constants.EXPIRATIONDATE));
            Characteristic.add(characteristic);

        } else {
            characteristic = new Characteristic();
            characteristic.setName(Constants.PAYMENTMETHOD);
            characteristic.setValue(Constants.BIZUM);
            Characteristic.add(characteristic);
        }

        characteristic = new Characteristic();
        characteristic.setName(Constants.SESSIONID);
        characteristic.setValue(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.SESSIONID));
        Characteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.SESSIONDATE);
        characteristic.setValue(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.SESSIONDATE));
        Characteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.RESOLUTORID);
        characteristic.setValue(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.RESOLUTORID));
        Characteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.OPERATIONTYPE);
        characteristic.setValue(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.OPERATIONTYPE));
        Characteristic.add(characteristic);

        return Characteristic;
    }
    
    private static List<Characteristic> mapCharacteristicBpmPfSales(Payment body, PaymentRegistryDB paymentRegistryDB) {
        List<Characteristic> Characteristic = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();
            characteristic = new Characteristic();
            characteristic.setName(Constants.MASK);
            characteristic
                    .setValue(mapCharacteristicCard(body.getPaymentMethod().getCharacteristic(), Constants.MASKCREDIT));
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.TOKEN);
            characteristic.setValue(body.getPaymentMethod().getToken());
            Characteristic.add(characteristic);

            characteristic = new Characteristic();
            characteristic.setName(Constants.COMMERCIALCODE);
            characteristic.setValue(paymentRegistryDB.getCommercialCode());
            Characteristic.add(characteristic);
            
            characteristic = new Characteristic();
            characteristic.setName(Constants.TERMINAL);
            characteristic.setValue(paymentRegistryDB.getTerminalCode());
            Characteristic.add(characteristic);

            if (!CollectionUtils.isEmpty(body.getStatusChange())
                    && !CollectionUtils.isEmpty(body.getStatusChange().get(0).getCharacteristic())) {
                characteristic = new Characteristic();
                characteristic.setName(Constants.PAYMENT_STATUSREASON);
                characteristic.setValue(body.getStatusChange().get(0).getCharacteristic().get(0).getValue());
                Characteristic.add(characteristic);
            }



        return Characteristic;
    }

    private static String mapCharacteristicCard(
            List<com.orange.api.paymentmanagement.web.model.Characteristic> characteristic, String value) {
        String valueCharacteristic = null;

        if (characteristic != null) {
            valueCharacteristic = PaymentManagementUtils.searchValueCharacteristic(characteristic, value);
        }

        return valueCharacteristic;
    }

    private static String mapStatus(List<StatusChange> listStatusChange) {
        String status = null;
        for (StatusChange statusChange : listStatusChange) {
            if (Constants.FAILED.equalsIgnoreCase(statusChange.getStatus())) {
                status = Constants.PAYMENTERROR;
            } else {
                status = Constants.PAID;
            }
        }

        return status;
    }
    
    private static String mapStatusBpmPfSales(List<StatusChange> listStatusChange) {
        String status = null;
        for (StatusChange statusChange : listStatusChange) {
            if (Constants.FAILED.equalsIgnoreCase(statusChange.getStatus())) {
                status = Constants.PREAUTH_PAYMENT_ERROR;
            } else if (Constants.COMPLETED.equalsIgnoreCase(statusChange.getStatus())) {
                status = Constants.PREAUTH_REALIZED;
            }
        }

        return status;
    }

    private static List<StatusChange> mapStatusChange(List<StatusChange> listStatusChangeBody, String status) {
        List<StatusChange> listStatusChange = new ArrayList<StatusChange>();
        StatusChange statusChange = new StatusChange();

        for (StatusChange statusChangeBody : listStatusChangeBody) {
            statusChange.setChangeDate(statusChangeBody.getChangeDate());
        }

        statusChange.setStatus(status);

        listStatusChange.add(statusChange);

        return listStatusChange;
    }

    public static void mapPaymentRegistryDB(PaymentRegistryDB paymentRegistryDB, Payment body, String processid) {

        mapStatusDB(body.getStatusChange(), paymentRegistryDB);
        paymentRegistryDB.setPaymentResult(mapPaymentResult(body.getStatusChange()));
        paymentRegistryDB.setResultDescription(mapPaymentResultDescription(body.getStatusChange()));
        paymentRegistryDB.setPaymentUpdate(mapPaymentUpdateDate(body.getStatusChange()));
        paymentRegistryDB.setAuthorizationNumber(body.getAuthorizationCode());
        paymentRegistryDB.setPaymentId(body.getCorrelatorId());

        if (body.getPaymentMethod() != null && body.getPaymentMethod().getToken() != null) {
            paymentRegistryDB.setPaymentMethod(Constants.TARJETA);
            paymentRegistryDB.setBankNumber(PaymentManagementUtils
                    .searchValueCharacteristic(body.getPaymentMethod().getCharacteristic(), Constants.BIN));
            paymentRegistryDB.setCardNumber(PaymentManagementUtils
                    .searchValueCharacteristic(body.getPaymentMethod().getCharacteristic(), Constants.MASKCREDIT));
            paymentRegistryDB.setToken(body.getPaymentMethod().getToken());
        } else {
            paymentRegistryDB.setPaymentMethod(Constants.BIZUM);
        }

        paymentRegistryDB.setSessionId(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.SESSIONID));
        String sessionDate = PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(),
                Constants.SESSIONDATE);
        if (sessionDate != null) {
            paymentRegistryDB.setSessionDate(sessionDate);
        }
        paymentRegistryDB.setResolutorId(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.RESOLUTORID));
        paymentRegistryDB.setOperationType(
                PaymentManagementUtils.searchValueCharacteristic(body.getCharacteristic(), Constants.OPERATIONTYPE));

        paymentRegistryDB.setProcessflowId(processid);

    }

    private static String mapPaymentResultDescription(List<StatusChange> listStatusChange) {
        String statusBBDD = null;
        for (StatusChange status : listStatusChange) {
            if (Constants.COMPLETED.equalsIgnoreCase(status.getStatus())) {
                statusBBDD = Constants.OK;
            } else {
                statusBBDD = Constants.KO;
            }
        }

        return statusBBDD;
    }

    private static String mapPaymentUpdateDate(List<StatusChange> listStatusChange) {
        for (StatusChange status : listStatusChange) {
            return status.getChangeDate();
        }
        return null;
    }

    private static void mapStatusDB(List<StatusChange> listStatusChange, PaymentRegistryDB paymentRegistryDB) {
        for (StatusChange statusChange : listStatusChange) {
            if (Constants.FAILED.equalsIgnoreCase(statusChange.getStatus())) {
                paymentRegistryDB.setStatus(Constants.PAYMENTERROR);
                paymentRegistryDB.setStatusDescription(Constants.PAYMENTERROR_DESC);
            } else {
                paymentRegistryDB.setStatus(Constants.COMPLETED);
                paymentRegistryDB.setStatusDescription(Constants.COMPLETED_DESC);
            }
        }

    }

    private static String mapPaymentResult(List<StatusChange> listStatusChange) {
        for (StatusChange status : listStatusChange) {
            return status.getChangeReason();
        }
        return null;
    }

    public static String mapProcessId(ResponseEntity<String> responseGet) {
        String processId = null;
        if (!ObjectUtils.isEmpty(responseGet)) {
            Gson gson = new Gson();
            Type collectionProcesinstance = new TypeToken<List<ProcessInstanceObj>>() {
            }.getType();
            List<ProcessInstanceObj> listProcess = gson.fromJson(responseGet.getBody(), collectionProcesinstance);
            if (!ObjectUtils.isEmpty(listProcess)) {
                processId = listProcess.get(0).getId();
            }
        }
        return processId;
    }
}