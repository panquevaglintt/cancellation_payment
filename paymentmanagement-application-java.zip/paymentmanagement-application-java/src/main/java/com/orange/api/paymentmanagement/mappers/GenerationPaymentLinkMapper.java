package com.orange.api.paymentmanagement.mappers;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.springframework.util.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.StatusChange;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Presentacion;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestGeneration;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseGeneration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class GenerationPaymentLinkMapper {

    public static void mapPaymentToRequestGeneration(Payment payment, RequestGeneration requestGeneration,
            String zlogin, FixedValuesDB fixedValues) {

        requestGeneration.setDatosCliente(mapClientData(fixedValues));
        requestGeneration.setIdioma(fixedValues.getLanguage());
        requestGeneration.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        requestGeneration.setImporte(payment.getTotalAmount().getValue().longValue());
        requestGeneration.setMoneda(fixedValues.getCurrency());
        requestGeneration.setParametrosAdicionales(mapAdditionalParameters(payment, zlogin));
        mapCharacteristic(payment.getCharacteristic(), requestGeneration, fixedValues);
        requestGeneration.setCoTipoOpLink(fixedValues.getCoTipoOpLink());
        requestGeneration.setPresentacion(getPresentation(fixedValues));
        requestGeneration.setCardType(fixedValues.getCardType());
        log.info("Se va a generar paymentLink con Numero Operacion Origen: " + requestGeneration.getNumOpOrigen());

    }
    
    private static DatosCliente mapClientData(FixedValuesDB fixedValues) {
        DatosCliente datosCliente = new DatosCliente();

        datosCliente.setCoCliente(fixedValues.getClientCode());
        datosCliente.setCoComercio(fixedValues.getCommercialCode());
        datosCliente.setCoTerminal(fixedValues.getTerminalCode());
        datosCliente.setPalabraClave(fixedValues.getKeyword());

        return datosCliente;
    }

    private static Presentacion getPresentation(FixedValuesDB fixedValues) {
        Presentacion presentation = new Presentacion();

        presentation.setUrlLogo(fixedValues.getUrlLogo());
        presentation.setColor(fixedValues.getColor());
        presentation.setTextoCvv(fixedValues.getTextcvv());
        presentation.setTextoBoton(fixedValues.getTextButton());
        presentation.setTextoFxCaducidad(fixedValues.getTextFxExpiration());
        presentation.setTextoTarjeta(fixedValues.getTextCard());
        presentation.setTextoTitulo(fixedValues.getTextTitle());

        return presentation;
    }

    private static void mapCharacteristic(List<Characteristic> listCharacteristic, RequestGeneration requestGeneration,
            FixedValuesDB fixedValues) {

        requestGeneration.setFxFinValidez(mapStatusDateValidate(fixedValues.getValidityTime()));
        requestGeneration.setNumIntentos(fixedValues.getPaymentRetries());
        for (Characteristic characteristic : listCharacteristic) {
            if (Constants.VALIDITYTIME.equalsIgnoreCase(characteristic.getName())) {
                int minutes = Integer.valueOf(characteristic.getValue()) * 60;
                requestGeneration.setFxFinValidez(mapStatusDateValidate(String.valueOf(minutes)));
            }

            if (Constants.PAYMENTRETRIES.equalsIgnoreCase(characteristic.getName())) {
                requestGeneration.setNumIntentos(characteristic.getValue());
            }
        }

    }

    private static ParametrosAdicionales mapAdditionalParameters(Payment payment, String zlogin) {
        ParametrosAdicionales parametrosAdicionales = new ParametrosAdicionales();
        List<Entry> listEntry = new ArrayList<Entry>();

        Entry entry = new Entry();
        entry.setKey(Constants.MSISDN);
        entry.setValue(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.PHONENUMBER));
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.DOCUMENTO);
        entry.setValue(PaymentManagementUtils.mapDocument(payment.getPayer()));
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.USUARIO);
        entry.setValue(zlogin);
        listEntry.add(entry);

        if (payment.getPaymentItem() != null) {
            entry = new Entry();
            entry.setKey(Constants.PEDIDOCRM);
            entry.setValue(payment.getPaymentItem().get(0).getItem().getId());
            listEntry.add(entry);
        }

        String custCode = PaymentManagementUtils.mapCustomerCode(payment.getPayer());
        if (custCode != null) {
            entry = new Entry();
            entry.setKey(Constants.CUSTCODE);
            entry.setValue(custCode);
            listEntry.add(entry);
        }

        parametrosAdicionales.setEntry(listEntry);

        return parametrosAdicionales;
    }
    
    public static String mapTypeDocument(RelatedParty payer) {

        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
            return payer.getIndividualIdentification().get(0).getIdentificationType();
        } else {
            return payer.getOrganizationIdentification().get(0).getIdentificationType();
        }

    }

    public static void mapResponseGenerationToPayment(ResponseGeneration responseGeneration, Payment payment) {

        payment.setId(responseGeneration.getNumOpOrigen());
        payment.setCharacteristic(getCharacteristicResponse(responseGeneration, payment.getCharacteristic()));
        payment.setStatus(Constants.PENDING);
        payment.setStatusDate(PaymentManagementUtils.extractDate(responseGeneration.getFxAltaLink(), Constants.TIMEZONE_EUROPE_MADRID, Constants.C_YYYY_MM_DD_T_HH_MM_SS_SSSXXX));
        
        if(!StringUtils.isEmpty(responseGeneration.getFxFinValidez())){
        List<StatusChange> listStatusChange = new ArrayList<StatusChange>();

        StatusChange statusChange = new StatusChange();
        statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(responseGeneration.getFxFinValidez(), Constants.TIMEZONE_EUROPE_MADRID));
        statusChange.setStatus(Constants.EXPIRED);
        listStatusChange.add(statusChange);
        
        payment.setStatusChange(listStatusChange);
        }
    }
    
    private static List<Characteristic> getCharacteristicResponse(ResponseGeneration responseGeneration,
            List<Characteristic> listCharacteristic) {
        Characteristic characteristic = new Characteristic();

        characteristic.setName(Constants.PAYMENTLINK);
        characteristic.setValue(responseGeneration.getLink());

        listCharacteristic.add(characteristic);

        return listCharacteristic;
    }

    public static String mapBscs(List<PaymentItem> listPaymentItem) {
        String codebscs = null;
        if (listPaymentItem != null) {
            for (PaymentItem paymentItem : listPaymentItem) {
                if (Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())) {
                    codebscs = PaymentManagementUtils
                            .searchValueCharacteristic(paymentItem.getItem().getCharacteristic(), Constants.BSCSCODE);
                }
            }
        }

        return codebscs;
    }

    public static Timestamp mapStatusDate(OffsetDateTime statusDate, List<Characteristic> listCharacteristic, FixedValuesDB fixedValues) {

        Timestamp timestamp = Timestamp.valueOf(statusDate.atZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        calendar.setTime(timestamp);
        
        String validTime = null;
        if(!StringUtils.isEmpty(PaymentManagementUtils.searchValueCharacteristic(listCharacteristic, Constants.VALIDITYTIME))) {
            int minutes = Integer.valueOf(PaymentManagementUtils.searchValueCharacteristic(listCharacteristic, Constants.VALIDITYTIME)) * 60;
            validTime = String.valueOf(minutes);
        }else {
            validTime = fixedValues.getValidityTime();
        }            

        calendar.add(Calendar.MINUTE, Integer.parseInt(validTime));
                                                                                                
        Timestamp timestampCal = new Timestamp(calendar.getTimeInMillis());

        return timestampCal;
    }

    private static String mapStatusDateValidate(String value) {

        Calendar gc = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        gc.set(Calendar.MINUTE, gc.get(Calendar.MINUTE) + Integer.valueOf(value));

        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(gc.getTime());

        return date;
    }

    public static PaymentRegistryDB mapPaymentManagementDB(Payment payment, String zapp, FixedValuesDB fixedValues,
            String transaction, RequestGeneration requestWS, String zlogin, ResponseGeneration responseWS,
            String processFlowId) {

        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();

        paymentRegistryDB.setAmount(payment.getTotalAmount().getValue().toString());
        paymentRegistryDB.setBscsIdentifier(mapBscs(payment.getPaymentItem()));
        paymentRegistryDB.setChannel(zapp);
        paymentRegistryDB.setClientCode(fixedValues.getClientCode());
        paymentRegistryDB.setCommercialCode(fixedValues.getCommercialCode());
        paymentRegistryDB.setCurrency(fixedValues.getCurrency());
        paymentRegistryDB.setIdDocument(PaymentManagementUtils.mapDocument(payment.getPayer()));
        paymentRegistryDB.setTypeDocument(mapTypeDocument(payment.getPayer()));
        paymentRegistryDB.setPhonenumber(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.PHONENUMBER));
        paymentRegistryDB.setType(payment.getPayer().getReferredType());
        if (payment.getPaymentItem() != null) {
            paymentRegistryDB.setVapId(payment.getPaymentItem().get(0).getItem().getId());
        }
        paymentRegistryDB.setLanguage(fixedValues.getLanguage());
        paymentRegistryDB.setLink(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.PAYMENTLINK));
        paymentRegistryDB.setLinkExpiration(mapStatusDate(payment.getStatusDate(), payment.getCharacteristic(), fixedValues));
        paymentRegistryDB.setLinkId(responseWS.getIdLink());
        paymentRegistryDB.setLinkCode(fixedValues.getCoTipoOpLink());
        paymentRegistryDB.setLinkRegistration(Timestamp.from(payment.getStatusDate().toInstant()));
        paymentRegistryDB.setOriginOpnumber(requestWS.getNumOpOrigen());
        paymentRegistryDB.setPaymentAttempts(PaymentManagementUtils
                .searchValueCharacteristic(payment.getCharacteristic(), Constants.PAYMENTRETRIES));
        paymentRegistryDB.setPaymentLink(responseWS.getNumOperacionNNP());
        paymentRegistryDB.setStatus(Constants.PENDING);
        paymentRegistryDB.setStatusDescription(Constants.PENDIENTE_PAGO);
        paymentRegistryDB.setTransactiontype(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.TRANSACTION));
        paymentRegistryDB.setTerminalCode(fixedValues.getTerminalCode());
        paymentRegistryDB.setUserId(zlogin);
        paymentRegistryDB.setProcessflowId(processFlowId);
        paymentRegistryDB.setPaymentFlow(Constants.PAYMENT_FLOW_PL);
        paymentRegistryDB.setCustCode(PaymentManagementUtils.mapCustomerCode(payment.getPayer()));

        log.info("Se ha creado el objeto para guardar en bbdd");

        return paymentRegistryDB;
    }

}