package com.orange.api.paymentmanagement.db.entities;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "PAYMENT_FIXED_VALUES", indexes = {
		@Index(name = "paymentfixedvalues_transactiontype_app_typelink_index", columnList = "transactiontype, app, typelink"),
		@Index(name = "paymentfixedvalues_transactiontype_app_index", columnList = "transactiontype, app") })
public class FixedValuesDB {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "creation_date")
	@CreationTimestamp
	private Timestamp creationDate;

	@Column(name = "update_date")
	@UpdateTimestamp
	private Timestamp updateDate;

	@Column(name = "client_code")
	private String clientCode;

	@Column(name = "transactiontype")
	private String transactiontype;

	@Column(name = "app")
	private String app;

	@Column(name = "commercial_code")
	private String commercialCode;

	@Column(name = "terminal_code")
	private String terminalCode;

	@Column(name = "keyword")
	private String keyword;

	@Column(name = "language")
	private String language;

	@Column(name = "cotipooplink")
	private String coTipoOpLink;

	@Column(name = "urllogo")
	private String urlLogo;

	@Column(name = "color")
	private String color;

	@Column(name = "text")
	private String text;

	@Column(name = "textcvv")
	private String textcvv;

	@Column(name = "textbutton")
	private String textButton;

	@Column(name = "textfxexpiration")
	private String textFxExpiration;

	@Column(name = "textcard")
	private String textCard;

	@Column(name = "textTitle")
	private String textTitle;

	@Column(name = "textMask")
	private String textMask;

	@Column(name = "cardtype")
	private String cardType;

	@Column(name = "currency")
	private String currency;

	@Column(name = "seed")
	private String seed;

	@Column(name = "form_button")
	private String formButton;

	@Column(name = "template")
	private String template;

	@Column(name = "paymentretries")
	private String paymentRetries;

	@Column(name = "validitytime")
	private String validityTime;

	@Column(name = "target")
	private String target;

	@Column(name = "url_css")
	private String urlCss;

	@Column(name = "typelink")
	private String typelink;
	
    @Column(name = "payment_method")
    private String paymentMethod;

}
