package com.orange.api.paymentmanagement.configuration;

import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.module.afterburner.AfterburnerModule;

/**
 * Makes Jackson operations faster.
 * @return
 */
public class JacksonConfig {
    @Bean
    public AfterburnerModule afterburnerModule() {
        return new AfterburnerModule();
    }

}
