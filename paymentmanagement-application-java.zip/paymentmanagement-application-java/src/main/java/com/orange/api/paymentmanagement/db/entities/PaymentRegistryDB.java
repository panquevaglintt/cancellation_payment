package com.orange.api.paymentmanagement.db.entities;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "PAYMENT_REGISTRY", indexes = { @Index(name = "paymentregistry_idpayment", columnList = "id"),
        @Index(name = "paymentregistry_linkid_index", columnList = "link_id"),
        @Index(name = "paymentregistry_originopnumber_index", columnList = "origin_opnumber"),
        @Index(name = "paymentregistry_iddocument_index", columnList = "id_document"),
        @Index(name = "paymentregistry_vapid_index", columnList = "vap_id"),
        @Index(name = "paymentregistry_phonenumber_index", columnList = "phonenumber"),
        @Index(name = "paymentregistry_update_date_index", columnList = "update_date"),
        @Index(name = "paymentregistry_creation_date_index", columnList = "creation_date"),
        @Index(name = "paymentregistry_payment_method_id_index", columnList = "payment_method_id"),
        @Index(name = "paymentregistry_status_index", columnList = "status") })
public class PaymentRegistryDB {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "creation_date")
    @CreationTimestamp
    private Timestamp creationDate;

    @Column(name = "update_date")
    @UpdateTimestamp
    private Timestamp updateDate;

    @Column(name = "client_code")
    private String clientCode;

    @Column(name = "commercial_code")
    private String commercialCode;

    @Column(name = "terminal_code")
    private String terminalCode;

    @Column(name = "language")
    private String language;

    @Column(name = "amount")
    private String amount;

    @Column(name = "currency")
    private String currency;

    @Column(name = "status")
    private String status;

    @Column(name = "status_description")
    private String statusDescription;

    @Column(name = "origin_opnumber", unique = true)
    private String originOpnumber;

    @Column(name = "phonenumber")
    private String phonenumber;

    @Column(name = "id_document")
    private String idDocument;

    @Column(name = "type_document")
    private String typeDocument;

    @Column(name = "type")
    private String type;

    @Column(name = "transactiontype")
    private String transactiontype;

    @Column(name = "bscs_identifier")
    private String bscsIdentifier;

    @Column(name = "vap_id")
    private String vapId;

    @Column(name = "processflow_id")
    private String processflowId;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "payment_flow")
    private String paymentFlow;

    @Column(name = "payment_attempts")
    private String paymentAttempts;

    @Column(name = "link_expiration")
    private Timestamp linkExpiration;

    @Column(name = "link_code")
    private String linkCode;

    @Column(name = "link")
    private String link;

    @Column(name = "link_registration")
    private Timestamp linkRegistration;

    @Column(name = "link_id")
    private String linkId;

    @Column(name = "payment_link")
    private String paymentLink;

    @Column(name = "payment_result")
    private String paymentResult;

    @Column(name = "result_description")
    private String resultDescription;

    @Column(name = "payment_update")
    private String paymentUpdate;

    @Column(name = "authorization_number")
    private String authorizationNumber;

    @Column(name = "payment_id")
    private String paymentId;

    @Column(name = "channel")
    private String channel;

    @Column(name = "payment_method")
    private String paymentMethod;

    @Column(name = "bank_number")
    private String bankNumber;

    @Column(name = "card_number")
    private String cardNumber;

    @Column(name = "token")
    private String token;

    @Column(name = "session_id")
    private String sessionId;

    @Column(name = "session_date")
    private String sessionDate;

    @Column(name = "resolutor_id")
    private String resolutorId;

    @Column(name = "operation_type")
    private String operationType;

    @Column(name = "annulation_date")
    private Timestamp annulationDate;

    @Column(name = "annulation_opnumber")
    private String annulationOpnumber;

    @Column(name = "annulation_id")
    private String annulationId;

    @Column(name = "annulation_result")
    private String annulationResult;

    @Column(name = "annulation_description")
    private String annulationDescription;
    
    @Column(name = "confirmation_origin_opnumber")
    private String confirmationOriginOpnumber;
    
    @Column(name = "confirmation_origin_opdate")
    private Timestamp confirmationOriginOpdate;

    @Column(name = "urlok")
    private String urlOk;

    @Column(name = "urlko")
    private String urlKo;

    @Column(name = "hash")
    private String hash;

    @Column(name = "custcode")
    private String custCode;
    
    @Column(name = "marketplace_order_id")
    private String marketplaceOrderId;
    
    @Column(name = "url_iframe", length = 100000)
    private String urlIframe;
    
    @Column(name = "payment_method_id")
    private String paymentMethodId;

}
