package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosLink implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("cardType")
	private String cardType;

	@JsonProperty("coTipoOpLink")
	private String coTipoOpLink;

	@JsonProperty("datosCliente")
	private DatosCliente datosCliente;

	@JsonProperty("email")
	private String email;

	@JsonProperty("fechaCaducidad")
	private String fechaCaducidad;

	@JsonProperty("fxFinValidez")
	private String fxFinValidez;

	@JsonProperty("fxAltaLink")
	private String fxAltaLink;

	@JsonProperty("idioma")
	private String idioma;

	@JsonProperty("importe")
	private Long importe;

	@JsonProperty("ip")
	private String ip;

	@JsonProperty("mascara")
	private String mascara;

	@JsonProperty("moneda")
	private String moneda;

	@JsonProperty("numIntentos")
	private Integer numIntentos;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("pagoRecurrente")
	private String pagoRecurrente;

	@JsonProperty("parametrosAdicionales")
	private ParametrosAdicionales parametrosAdicionales;

	@JsonProperty("paypal")
	private Boolean paypal;

	@JsonProperty("presentacion")
	private Presentacion presentacion;

	@JsonProperty("productDescription")
	private String productDescription;

	@JsonProperty("token")
	private String token;

	@JsonProperty("usuario")
	private String usuario;

	@JsonProperty("estado")
	private String estado;
}