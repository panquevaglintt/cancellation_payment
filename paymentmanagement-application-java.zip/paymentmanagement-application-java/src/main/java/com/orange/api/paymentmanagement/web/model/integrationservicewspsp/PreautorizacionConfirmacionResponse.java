package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PreautorizacionConfirmacionResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("datosTarjeta")
	private Object datosTarjeta;

	@JsonProperty("importe")
	private Long importe;

	@JsonProperty("moneda")
	private String moneda;

	@JsonProperty("datosResolutor")
	private Object datosResolutor;

	@JsonProperty("numAutorizacion")
	private String numAutorizacion;

	@JsonProperty("numOperacionNNP")
	private Integer numOperacionNNP;

	@JsonProperty("parametrosAdicionales")
	private ParametrosAdicionales parametrosAdicionales;

	@JsonProperty("resultadoOperacion")
	private ResultadoOperacion resultadoOperacion;

	@JsonProperty("datosCliente")
	private DatosCliente datosCliente;

	@JsonProperty("fechaOpOrigen")
	private String fechaOpOrigen;

	@JsonProperty("idioma")
	private String idioma;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("usuario")
	private String usuario;
}