package com.orange.api.paymentmanagement.mappers;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.springframework.util.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.StatusChange;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Presentacion;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestGeneration;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseGeneration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class GenerationPreauthorizationPaymentLinkMapper {
    
    public static void mapPreauthorizationPaymentToRequestGeneration(Payment paymentPL, RequestGeneration requestGenerationPL,
            String zlogin, FixedValuesDB fixedValues, String zCallerIp) {

        requestGenerationPL.setDatosCliente(mapClientData(fixedValues));
        requestGenerationPL.setIdioma(fixedValues.getLanguage());
        requestGenerationPL.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        requestGenerationPL.setImporte(paymentPL.getTotalAmount().getValue().longValue());
        requestGenerationPL.setMoneda(fixedValues.getCurrency());
        requestGenerationPL.setParametrosAdicionales(mapAdditionalParametersPreauthorization(paymentPL, zlogin, zCallerIp));
        mapCharacteristic(paymentPL.getCharacteristic(), requestGenerationPL, fixedValues);
        requestGenerationPL.setCoTipoOpLink(fixedValues.getCoTipoOpLink());
        requestGenerationPL.setPresentacion(getPresentation(fixedValues));
        requestGenerationPL.setCardType(fixedValues.getCardType());
        log.info("Se va a generar paymentLink de preautorización con Numero Operacion Origen: " + requestGenerationPL.getNumOpOrigen());

    }

    private static DatosCliente mapClientData(FixedValuesDB fixedValues) {
        DatosCliente datosClientePL = new DatosCliente();

        datosClientePL.setCoCliente(fixedValues.getClientCode());
        datosClientePL.setCoComercio(fixedValues.getCommercialCode());
        datosClientePL.setCoTerminal(fixedValues.getTerminalCode());
        datosClientePL.setPalabraClave(fixedValues.getKeyword());

        return datosClientePL;
    }

    private static Presentacion getPresentation(FixedValuesDB fixedValues) {
        Presentacion presentationPL = new Presentacion();

        presentationPL.setUrlLogo(fixedValues.getUrlLogo());
        presentationPL.setColor(fixedValues.getColor());
        presentationPL.setTextoCvv(fixedValues.getTextcvv());
        presentationPL.setTextoBoton(fixedValues.getTextButton());
        presentationPL.setTextoFxCaducidad(fixedValues.getTextFxExpiration());
        presentationPL.setTextoTarjeta(fixedValues.getTextCard());
        presentationPL.setTextoTitulo(fixedValues.getTextTitle());

        return presentationPL;
    }

    private static void mapCharacteristic(List<Characteristic> listCharacteristic, RequestGeneration requestGenerationPL,
            FixedValuesDB fixedValues) {

        requestGenerationPL.setFxFinValidez(mapStatusDateValidate(fixedValues.getValidityTime()));
        requestGenerationPL.setNumIntentos(fixedValues.getPaymentRetries());
        for (Characteristic characteristicPL : listCharacteristic) {
            if (Constants.VALIDITYTIME.equalsIgnoreCase(characteristicPL.getName())) {
                int minutes = Integer.valueOf(characteristicPL.getValue()) * 60;
                requestGenerationPL.setFxFinValidez(mapStatusDateValidate(String.valueOf(minutes)));
            }

            if (Constants.PAYMENTRETRIES.equalsIgnoreCase(characteristicPL.getName())) {
                requestGenerationPL.setNumIntentos(characteristicPL.getValue());
            }
        }

    }
    
    private static ParametrosAdicionales mapAdditionalParametersPreauthorization(Payment paymentPL, String zlogin, String zCallerIp) {
        ParametrosAdicionales parametrosAdicionales = new ParametrosAdicionales();
        List<Entry> listEntry = new ArrayList<Entry>();

        Entry entry2 = new Entry();
        entry2.setKey(Constants.MSISDN);
        entry2.setValue(
                PaymentManagementUtils.searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.PHONENUMBER));
        listEntry.add(entry2);

        entry2 = new Entry();
        entry2.setKey(Constants.DOCUMENTO);
        entry2.setValue(PaymentManagementUtils.mapDocument(paymentPL.getPayer()));
        listEntry.add(entry2);

        entry2 = new Entry();
        entry2.setKey(Constants.USUARIO);
        entry2.setValue(zlogin);
        listEntry.add(entry2);
        
        entry2 = new Entry();
        entry2.setKey(Constants.PEDIDOCRM);
        entry2.setValue(
                PaymentManagementUtils.searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.PROCESSFLOW_ID));
        listEntry.add(entry2);
        
        entry2 = new Entry();
        entry2.setKey(Constants.PEDIDOTOL);
        entry2.setValue(zCallerIp);
        listEntry.add(entry2);
        
        String custCode = PaymentManagementUtils.mapCustomerCode(paymentPL.getPayer());
        if (custCode != null) {
            entry2 = new Entry();
            entry2.setKey(Constants.CUSTCODE);
            entry2.setValue(custCode);
            listEntry.add(entry2);
        }

        parametrosAdicionales.setEntry(listEntry);

        return parametrosAdicionales;
    }

    public static String mapTypeDocument(RelatedParty payer) {

        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
            return payer.getIndividualIdentification().get(0).getIdentificationType();
        } else {
            return payer.getOrganizationIdentification().get(0).getIdentificationType();
        }

    }
    
    public static void mapResponseGenerationToPreauthorizationPayment(ResponseGeneration responseGeneration, Payment paymentPL) {

        paymentPL.setId(responseGeneration.getNumOpOrigen());
        paymentPL.setCharacteristic(getCharacteristicResponse(responseGeneration, paymentPL.getCharacteristic()));
        paymentPL.setStatus(Constants.PREAUTH_PENDING);
        paymentPL.setStatusDate(PaymentManagementUtils.extractDate(responseGeneration.getFxAltaLink(), Constants.TIMEZONE_UTC, Constants.C_YYYY_MM_DD_T_HH_MM_SS_SSSXXX));
        
        if(!StringUtils.isEmpty(responseGeneration.getFxFinValidez())){
        List<StatusChange> listStatusChange = new ArrayList<StatusChange>();

        StatusChange statusChange = new StatusChange();
        statusChange.setChangeDate(PaymentManagementUtils.extractDateStatus(responseGeneration.getFxFinValidez(), Constants.TIMEZONE_UTC));
        statusChange.setStatus(Constants.EXPIRED);
        listStatusChange.add(statusChange);
        
        paymentPL.setStatusChange(listStatusChange);
        }
    }


    private static List<Characteristic> getCharacteristicResponse(ResponseGeneration responseGeneration,
            List<Characteristic> listCharacteristic) {
        Characteristic characteristicPL = new Characteristic();

        characteristicPL.setName(Constants.PAYMENTLINK);
        characteristicPL.setValue(responseGeneration.getLink());

        listCharacteristic.add(characteristicPL);

        return listCharacteristic;
    }

    public static String mapBscs(List<PaymentItem> listPaymentItem) {
        String codebscs = null;
        if (listPaymentItem != null) {
            for (PaymentItem paymentItemPL : listPaymentItem) {
                if (Constants.VAP.equalsIgnoreCase(paymentItemPL.getItem().getRole())) {
                    codebscs = PaymentManagementUtils
                            .searchValueCharacteristic(paymentItemPL.getItem().getCharacteristic(), Constants.BSCSCODE);
                }
            }
        }

        return codebscs;
    }

    public static Timestamp mapStatusDate(OffsetDateTime statusDate, List<Characteristic> listCharacteristic, FixedValuesDB fixedValues) {

        Timestamp timestamp = Timestamp.valueOf(statusDate.atZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        calendar.setTime(timestamp);
        
        String validTime = null;
        if(!StringUtils.isEmpty(PaymentManagementUtils.searchValueCharacteristic(listCharacteristic, Constants.VALIDITYTIME))) {
            int minutes = Integer.valueOf(PaymentManagementUtils.searchValueCharacteristic(listCharacteristic, Constants.VALIDITYTIME)) * 60;
            validTime = String.valueOf(minutes);
        }else {
            validTime = fixedValues.getValidityTime();
        }  
        
        calendar.add(Calendar.MINUTE, Integer.parseInt(validTime));

        Timestamp timestampCal = new Timestamp(calendar.getTimeInMillis());

        return timestampCal;
    }

    private static String mapStatusDateValidate(String value) {

        Calendar gc = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        gc.set(Calendar.MINUTE, gc.get(Calendar.MINUTE) + Integer.valueOf(value));

        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(gc.getTime());

        return date;
    }
    
    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    public static PaymentRegistryDB mapPreauthorizationPaymentManagementDB(Payment paymentPL, String zapp, FixedValuesDB fixedValues,
            String transaction, RequestGeneration requestWS, String zlogin, ResponseGeneration responseWS,
            String processFlowId) {

        PaymentRegistryDB paymentRegistryPLDB = new PaymentRegistryDB();

        paymentRegistryPLDB.setAmount(paymentPL.getTotalAmount().getValue().toString());
        paymentRegistryPLDB.setBscsIdentifier(mapBscs(paymentPL.getPaymentItem()));
        paymentRegistryPLDB.setChannel(zapp);
        paymentRegistryPLDB.setClientCode(fixedValues.getClientCode());
        paymentRegistryPLDB.setCommercialCode(fixedValues.getCommercialCode());
        paymentRegistryPLDB.setCurrency(fixedValues.getCurrency());
        paymentRegistryPLDB.setIdDocument(PaymentManagementUtils.mapDocument(paymentPL.getPayer()));
        paymentRegistryPLDB.setTypeDocument(mapTypeDocument(paymentPL.getPayer()));
        paymentRegistryPLDB.setPhonenumber(
                PaymentManagementUtils.searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.PHONENUMBER));
        paymentRegistryPLDB.setType(paymentPL.getPayer().getReferredType());
        if (paymentPL.getPaymentItem() != null) {
            paymentRegistryPLDB.setVapId(paymentPL.getPaymentItem().get(0).getItem().getId());
        }
        paymentRegistryPLDB.setLanguage(fixedValues.getLanguage());
        paymentRegistryPLDB.setLink(
                PaymentManagementUtils.searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.PAYMENTLINK));
        paymentRegistryPLDB.setLinkExpiration(mapStatusDate(paymentPL.getStatusDate(), paymentPL.getCharacteristic(), fixedValues));
        paymentRegistryPLDB.setLinkId(responseWS.getIdLink());
        paymentRegistryPLDB.setLinkCode(fixedValues.getCoTipoOpLink());
        paymentRegistryPLDB.setLinkRegistration(Timestamp.from(paymentPL.getStatusDate().toInstant()));
        paymentRegistryPLDB.setOriginOpnumber(requestWS.getNumOpOrigen());
        paymentRegistryPLDB.setPaymentAttempts(PaymentManagementUtils
                .searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.PAYMENTRETRIES));
        paymentRegistryPLDB.setPaymentLink(responseWS.getNumOperacionNNP());
        paymentRegistryPLDB.setStatus(Constants.PREAUTH_PENDING);
        paymentRegistryPLDB.setStatusDescription(Constants.PENDIENTE_PREAUTH);
        paymentRegistryPLDB.setTransactiontype(
                PaymentManagementUtils.searchValueCharacteristic(paymentPL.getCharacteristic(), Constants.TRANSACTION));
        paymentRegistryPLDB.setTerminalCode(fixedValues.getTerminalCode());
        paymentRegistryPLDB.setUserId(zlogin);
        paymentRegistryPLDB.setProcessflowId(processFlowId);
        paymentRegistryPLDB.setPaymentFlow(Constants.PAYMENT_FLOW_PL);
        paymentRegistryPLDB.setCustCode(PaymentManagementUtils.mapCustomerCode(paymentPL.getPayer()));
        paymentRegistryPLDB.setPaymentUpdate(mapDate());
        
        log.info("Se ha creado el objeto para guardar en bbdd");

        return paymentRegistryPLDB;
    }

}