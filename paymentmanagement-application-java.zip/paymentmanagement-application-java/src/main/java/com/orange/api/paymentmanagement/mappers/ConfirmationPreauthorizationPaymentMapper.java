package com.orange.api.paymentmanagement.mappers;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosPrevia;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionConfirmacionRequest;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionConfirmacionResponse;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class ConfirmationPreauthorizationPaymentMapper {


    public static void mapPaymentToPreautorizacionConfirmacionRequest(Payment payment, PreautorizacionConfirmacionRequest preautorizacionConfirmacionRequest,
            PaymentRegistryDB confirmationPaymentRegistryDB, FixedValuesDB fixedValues) {

        preautorizacionConfirmacionRequest.setDatosCliente(mapClientData(fixedValues, confirmationPaymentRegistryDB));
        preautorizacionConfirmacionRequest.setFechaOpOrigen(mapDate());
        preautorizacionConfirmacionRequest.setIdioma(fixedValues.getLanguage());
        preautorizacionConfirmacionRequest.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        preautorizacionConfirmacionRequest.setImporte((long)Double.parseDouble(confirmationPaymentRegistryDB.getAmount()));
        preautorizacionConfirmacionRequest.setMoneda(fixedValues.getCurrency());
        preautorizacionConfirmacionRequest.setParametrosAdicionales(mapAdditionalParameters(payment, confirmationPaymentRegistryDB));
        preautorizacionConfirmacionRequest.setDatosPrevia(mapPreviousData(confirmationPaymentRegistryDB));
        log.info("Se va a generar la confirmacion de preautorizacion con Numero Operacion Origen: " + preautorizacionConfirmacionRequest.getNumOpOrigen());

    }
    
    public static void mapPreautorizacionConfirmacionResponseToPayment(Payment payment, PreautorizacionConfirmacionResponse preautorizacionConfirmacionResponse, String numOrigin) {
        payment.setId(numOrigin);
        payment.setStatusDate(PaymentManagementUtils.extractDate(preautorizacionConfirmacionResponse.getFechaOpOrigen(),
                Constants.TIMEZONE_EUROPE_MADRID, Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX));
        List<Characteristic> characteristics = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();
        characteristic.setName("PreauthorizationConfirmationId");
        characteristic.setValue(preautorizacionConfirmacionResponse.getNumOpOrigen());
        characteristics.add(characteristic);

        payment.setCharacteristic(characteristics);
    }

    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    private static DatosPrevia mapPreviousData(PaymentRegistryDB confirmationPaymentRegistryDB) {
        DatosPrevia datosPrevia = new DatosPrevia();

        datosPrevia.setCoComercio(confirmationPaymentRegistryDB.getCommercialCode());
        datosPrevia.setCoTerminal(confirmationPaymentRegistryDB.getTerminalCode());
        datosPrevia.setFechaOpOrigen(confirmationPaymentRegistryDB.getPaymentUpdate());
        datosPrevia.setNumOpOrigen(confirmationPaymentRegistryDB.getOriginOpnumber());

        return datosPrevia;
    }

    private static ParametrosAdicionales mapAdditionalParameters(Payment payment, PaymentRegistryDB confirmationPaymentRegistryDB) {
        ParametrosAdicionales parametros = new ParametrosAdicionales();
        List<Entry> listEntry = new ArrayList<Entry>();

        Entry entry = new Entry();
        entry.setKey(Constants.MSISDN);
        entry.setValue(confirmationPaymentRegistryDB.getPhonenumber());
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.DOCUMENTO);
        entry.setValue(confirmationPaymentRegistryDB.getIdDocument());
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.USUARIO);
        entry.setValue(confirmationPaymentRegistryDB.getUserId());
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.PEDIDOCRM);
        entry.setValue(confirmationPaymentRegistryDB.getProcessflowId());
        listEntry.add(entry);
        
        parametros.setEntry(listEntry);

        return parametros;
    }

    private static DatosCliente mapClientData(FixedValuesDB fixedValues, PaymentRegistryDB confirmationPaymentRegistryDB) {
        DatosCliente datosCliente = new DatosCliente();

        datosCliente.setCoCliente(fixedValues.getClientCode());
        if (confirmationPaymentRegistryDB.getCommercialCode() != null) {
            datosCliente.setCoComercio(confirmationPaymentRegistryDB.getCommercialCode());
        } else {
            datosCliente.setCoComercio(fixedValues.getCommercialCode());
        }
        datosCliente.setCoTerminal(fixedValues.getTerminalCode());
        datosCliente.setPalabraClave(fixedValues.getKeyword());

        return datosCliente;
    }

    public static void mapPaymentRegistry(PaymentRegistryDB confirmationPaymentRegistryDB, PreautorizacionConfirmacionResponse responseConfirmationAndCancellation,
            PreautorizacionConfirmacionRequest requestWS, String status, String statusDescription) {

        confirmationPaymentRegistryDB.setStatus(status);
        confirmationPaymentRegistryDB.setStatusDescription(statusDescription);
        confirmationPaymentRegistryDB.setConfirmationOriginOpdate(mapTimestamp(requestWS.getFechaOpOrigen()));
        confirmationPaymentRegistryDB.setConfirmationOriginOpnumber(String.valueOf(responseConfirmationAndCancellation.getNumOpOrigen()));
        mapResultOperation(responseConfirmationAndCancellation.getResultadoOperacion(), confirmationPaymentRegistryDB);
    }

    public static void mapPaymentRegistryError(PaymentRegistryDB confirmationPaymentRegistryDB, PreautorizacionConfirmacionRequest requestWS,
            String status, String statusDescription) {

        confirmationPaymentRegistryDB.setStatus(status);
        confirmationPaymentRegistryDB.setStatusDescription(statusDescription);
        confirmationPaymentRegistryDB.setConfirmationOriginOpdate(mapTimestamp(requestWS.getFechaOpOrigen()));
        confirmationPaymentRegistryDB.setConfirmationOriginOpnumber(requestWS.getNumOpOrigen());
        mapResultOperationError(confirmationPaymentRegistryDB);
    }

    private static Timestamp mapTimestamp(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        java.util.Date parsedDate = null;
        try {
            parsedDate = dateFormat.parse(date);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }
        Timestamp timestamp = new Timestamp(parsedDate.getTime());
        return timestamp;
    }

    private static void mapResultOperation(ResultadoOperacion resultado, PaymentRegistryDB confirmationPaymentRegistryDB) {

        if (Constants.ENRQ_PREV_NO_ENCONTRADA.equalsIgnoreCase(resultado.getCodigo())) {
            confirmationPaymentRegistryDB.setStatus(Constants.PREAUTH_EXPIRED);
            confirmationPaymentRegistryDB.setStatusDescription(Constants.EXPIRED_DESC);
            confirmationPaymentRegistryDB.setResultDescription(Constants.KO);
        } else if (!Constants.OK.equalsIgnoreCase(resultado.getCodigo())) {
            confirmationPaymentRegistryDB.setStatus(Constants.PREAUTH_CONFIRMED_ERROR);
            confirmationPaymentRegistryDB.setStatusDescription(Constants.PREAUTH_CONFIRMED_ERROR_DESC);
            confirmationPaymentRegistryDB.setResultDescription(Constants.KO);
        }

    }

    private static void mapResultOperationError(PaymentRegistryDB confirmationPaymentRegistryDB) {

        if (Constants.PREAUTH_CONFIRMED_TIMEOUT_DESC.equalsIgnoreCase(confirmationPaymentRegistryDB.getStatusDescription())) {
            confirmationPaymentRegistryDB.setAnnulationResult(Constants.ANNULALATION_TIMEOUT_RESUL);
            confirmationPaymentRegistryDB.setAnnulationDescription(Constants.ANNULATION_TIMEOUT_DESC);
        } else {

            confirmationPaymentRegistryDB.setAnnulationResult(Constants.ANULLATION_ERROR_RESULT);
            confirmationPaymentRegistryDB.setAnnulationDescription(Constants.ANULLATION_ERROR_DESC);
        }
        confirmationPaymentRegistryDB.setResultDescription(Constants.KO);

    }

}