package com.orange.api.paymentmanagement.mappers;

import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ObjectUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.OrganizationIdentification;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.RelatedParty;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class PaymentMarketPlaceMapper {

	/**
	 * This method extract document the payer
	 * 
	 * @param payer
	 * @return
	 */
	public static String mapTypeDocument(RelatedParty payer) {

		if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
			return payer.getIndividualIdentification().get(0).getIdentificationType();
		} else {
			return payer.getOrganizationIdentification().get(0).getIdentificationType();
		}

	}

	public static List<Payment> mapRespSearchByPhonenumberAndDocumentId(List<PaymentRegistryDB> paymentRegistryDBList,
			String phoneNumber, String idDocument, String payerReferredType, String typeDocument) {

		List<Payment> paymentList = new ArrayList<>();
		for (PaymentRegistryDB paymentRegistry : paymentRegistryDBList) {
			Payment payment = new Payment();
			payment.setType(Constants.MP_PAYMENT);
			payment.setId(paymentRegistry.getOriginOpnumber());
			if (StringUtils.isNotEmpty(phoneNumber)) {
				List<Characteristic> listCharacteristic = new ArrayList<>();
				Characteristic characteristic = new Characteristic();
				characteristic.setName(Constants.MSISDN);
				characteristic.setValue(phoneNumber);
				listCharacteristic.add(characteristic);
				payment.setCharacteristic(listCharacteristic);
			} else {
				RelatedParty payer = new RelatedParty();
				if (payerReferredType.equalsIgnoreCase(Constants.REFERRED_TYPE_INDIVIDUAL)) {
					payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
					List<IndividualIdentification> individualIdentificationList = new ArrayList<>();
					IndividualIdentification individualIdentification = new IndividualIdentification();
					individualIdentification.setIdentificationId(idDocument);
					individualIdentification.setIdentificationType(typeDocument);
					individualIdentificationList.add(individualIdentification);
					payer.setIndividualIdentification(individualIdentificationList);
				} else {
					payer.setReferredType(Constants.REFERRED_TYPE_ORGANIZATION);
					List<OrganizationIdentification> organizationIdentificationList = new ArrayList<>();
					OrganizationIdentification organizationIdentification = new OrganizationIdentification();
					organizationIdentification.setIdentificationId(idDocument);
					organizationIdentification.setIdentificationType(typeDocument);
					organizationIdentificationList.add(organizationIdentification);
					payer.setOrganizationIdentification(organizationIdentificationList);
				}
				payment.setPayer(payer);
			}
			paymentList.add(payment);
		}

		return paymentList;
	}

	public static PaymentRegistryDB mapPaymentManagementDB(Payment payment, String zapp, String transaction,
			FixedValuesDB fixedValues, String zlogin) {

		PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
		paymentRegistryDB.setClientCode(fixedValues.getClientCode());
		paymentRegistryDB.setTerminalCode(fixedValues.getTerminalCode());
		paymentRegistryDB.setCommercialCode(fixedValues.getCommercialCode());
		paymentRegistryDB.setPaymentUpdate(mapDateAndStatusDate(payment.getStatusDate()));
		paymentRegistryDB.setLanguage(fixedValues.getLanguage());
		paymentRegistryDB.setOriginOpnumber(payment.getId());
		paymentRegistryDB.setCurrency(fixedValues.getCurrency());
		paymentRegistryDB.setAmount(payment.getTotalAmount().getValue().toString());
		paymentRegistryDB.setPaymentMethod(fixedValues.getTypelink());
		paymentRegistryDB.setPaymentResult(Constants.OK);
		paymentRegistryDB.setTransactiontype(transaction);
		paymentRegistryDB.setPaymentFlow(Constants.PAYMENT_FLOW_MARKETPLACE);
		paymentRegistryDB.setPhonenumber(
				PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.PHONENUMBER));
		paymentRegistryDB.setIdDocument(PaymentManagementUtils.mapDocument(payment.getPayer()));
		paymentRegistryDB.setTypeDocument(PaymentMarketPlaceMapper.mapTypeDocument(payment.getPayer()));
		paymentRegistryDB.setChannel(zapp);
		paymentRegistryDB.setStatus(payment.getStatus());
		paymentRegistryDB.setStatusDescription(Constants.COMPLETED_DESC);
		paymentRegistryDB.setResultDescription(Constants.OK);
		paymentRegistryDB.setType(payment.getPayer().getReferredType());
		paymentRegistryDB.setUserId(zlogin);
		// necesario??
		paymentRegistryDB.setOperationType("0113");
		// Columnas Nuevas
		if (!ObjectUtils.isEmpty(payment.getPaymentItem())
				&& !ObjectUtils.isEmpty(payment.getPaymentItem().get(0).getItem())) {
			paymentRegistryDB.setMarketplaceOrderId(payment.getPaymentItem().get(0).getItem().getId());
		}
		
		log.info("Se ha creado el objeto para guardar en bbdd");

		return paymentRegistryDB;
	}

    private static String mapDateAndStatusDate(OffsetDateTime statusDate) {
        String statusDateString = statusDate.toString();

        if (statusDate.getSecond() == 0) {
            statusDateString = statusDateString.replace(Constants.C_ZULU, ":00Z");
        }

        String paymentUpdate = null;
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());
        if (statusDateString.indexOf(Constants.C_ZULU) != -1 && date.indexOf("+") != -1) {
            paymentUpdate = statusDateString.split(Constants.C_ZULU)[0] + "+" + date.split("\\+")[1];
        } else {
            paymentUpdate = statusDateString;
        }

        return paymentUpdate;
    }

}