package com.orange.api.paymentmanagement.mappers;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.zone.ZoneRules;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosPrevia;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.Entry;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestAnnulationAndReturned;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseAnnulationAndReturned;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class AnnulationAndReturnedPaymentMapper {

    public static void mapPaymentToRequestAnnulationAndReturned(Payment payment, RequestAnnulationAndReturned requestAnnulationAndReturned,
            PaymentRegistryDB paymentRegistryDB, FixedValuesDB fixedValues) {

        requestAnnulationAndReturned.setDatosCliente(mapClientData(fixedValues, paymentRegistryDB));
        requestAnnulationAndReturned.setFechaOpOrigen(mapDate());
        requestAnnulationAndReturned.setIdioma(fixedValues.getLanguage());
        requestAnnulationAndReturned.setNumOpOrigen(PaymentManagementUtils.getNumOrigen());
        requestAnnulationAndReturned.setImporte(payment.getTotalAmount().getValue().longValue());
        requestAnnulationAndReturned.setMoneda(fixedValues.getCurrency());
        requestAnnulationAndReturned.setParametrosAdicionales(mapAdditionalParameters(payment, paymentRegistryDB));
        requestAnnulationAndReturned.setDatosPrevia(mapPreviousData(paymentRegistryDB));
        log.info("Se va a generar anulacion o devolucion con Numero Operacion Origen: " + requestAnnulationAndReturned.getNumOpOrigen());

    }

    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }

    private static DatosPrevia mapPreviousData(PaymentRegistryDB paymentRegistryDB) {
        DatosPrevia datosPrevia = new DatosPrevia();

        datosPrevia.setCoComercio(paymentRegistryDB.getCommercialCode());
        datosPrevia.setCoTerminal(paymentRegistryDB.getTerminalCode());
        datosPrevia.setNumOpOrigen(paymentRegistryDB.getOriginOpnumber());
        if (null != paymentRegistryDB.getPaymentUpdate()
                && Constants.TRANSACTION_TYPE_MARKETPLACE.equalsIgnoreCase(paymentRegistryDB.getTransactiontype())) {
            mapFechaOpOrigenMarketplace(paymentRegistryDB, datosPrevia);
        } else {
            datosPrevia.setFechaOpOrigen(paymentRegistryDB.getPaymentUpdate());
        }

        return datosPrevia;
    }
    
    private static void mapFechaOpOrigenMarketplace(PaymentRegistryDB paymentRegistryDB, DatosPrevia datosPrevia) {
        // Obtener uso horario
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);

            LocalDateTime localDateTime = LocalDateTime.parse(paymentRegistryDB.getPaymentUpdate(), inputFormatter);

            ZoneId zoneId = ZoneId.of(Constants.TIMEZONE_EUROPE_MADRID);
            ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, zoneId);
            ZoneRules rules = zoneId.getRules();

            boolean isDaylightSavings = rules.isDaylightSavings(zonedDateTime.toInstant());

            // Añadir horas
            String dateString = paymentRegistryDB.getPaymentUpdate();

            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
            sdf.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
            cal.setTime(sdf.parse(dateString));

            String finalDate = "";

            if (isDaylightSavings) {
                cal.add(Calendar.HOUR_OF_DAY, 1);
            } else {
                cal.add(Calendar.HOUR_OF_DAY, 2);
            }

            finalDate = sdf.format(cal.getTime());

            datosPrevia.setFechaOpOrigen(finalDate);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static ParametrosAdicionales mapAdditionalParameters(Payment payment, PaymentRegistryDB paymentRegistryDB) {
        ParametrosAdicionales parametros = new ParametrosAdicionales();
        List<Entry> listEntry = new ArrayList<Entry>();

        Entry entry = new Entry();
        entry.setKey(Constants.MSISDN);
        entry.setValue(paymentRegistryDB.getPhonenumber());
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.DOCUMENTO);
        entry.setValue(paymentRegistryDB.getIdDocument());
        listEntry.add(entry);

        entry = new Entry();
        entry.setKey(Constants.USUARIO);
        entry.setValue(paymentRegistryDB.getUserId());
        listEntry.add(entry);

        if (payment.getPaymentItem() != null) {
            entry = new Entry();
            entry.setKey(Constants.PEDIDOCRM);
            entry.setValue(mapIDVAP(payment.getPaymentItem()));
            listEntry.add(entry);
        }

        parametros.setEntry(listEntry);

        return parametros;
    }

    private static String mapIDVAP(@Valid List<PaymentItem> listPaymentItem) {
        for (PaymentItem paymentItem : listPaymentItem) {
            if (Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())) {
                return paymentItem.getItem().getId();
            }
        }
        return null;
    }

    private static DatosCliente mapClientData(FixedValuesDB fixedValues, PaymentRegistryDB paymentRegistryDB) {
        DatosCliente datosCliente = new DatosCliente();

        datosCliente.setCoCliente(fixedValues.getClientCode());
        if (paymentRegistryDB.getCommercialCode() != null) {
            datosCliente.setCoComercio(paymentRegistryDB.getCommercialCode());
        } else {
            datosCliente.setCoComercio(fixedValues.getCommercialCode());
        }
        datosCliente.setCoTerminal(fixedValues.getTerminalCode());
        datosCliente.setPalabraClave(fixedValues.getKeyword());

        return datosCliente;
    }

    public static void mapPaymentRegistry(PaymentRegistryDB paymentRegistryDB, ResponseAnnulationAndReturned responseAnnulationAndReturned,
            RequestAnnulationAndReturned requestWS, String status, String statusDescription) {

        paymentRegistryDB.setStatus(status);
        paymentRegistryDB.setStatusDescription(statusDescription);
        paymentRegistryDB.setAnnulationDate(mapTimestampAnnulationAndReturned(requestWS.getFechaOpOrigen()));
        paymentRegistryDB.setAnnulationId(String.valueOf(responseAnnulationAndReturned.getNumOperacionNNP()));
        paymentRegistryDB.setAnnulationOpnumber(requestWS.getNumOpOrigen());
        mapResultOperation(responseAnnulationAndReturned.getResultadoOperacion(), paymentRegistryDB);
    }

    public static void mapPaymentRegistryError(PaymentRegistryDB paymentRegistryDB, RequestAnnulationAndReturned requestWS,
            String status, String statusDescription) {

        paymentRegistryDB.setStatus(status);
        paymentRegistryDB.setStatusDescription(statusDescription);
        paymentRegistryDB.setAnnulationDate(mapTimestampAnnulationAndReturned(requestWS.getFechaOpOrigen()));
        paymentRegistryDB.setAnnulationOpnumber(requestWS.getNumOpOrigen());
        mapResultOperationError(paymentRegistryDB);
    }

    private static Timestamp mapTimestampAnnulationAndReturned(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        java.util.Date parsedDate = null;
        try {
            parsedDate = dateFormat.parse(date);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }
        Timestamp timestamp = new Timestamp(parsedDate.getTime());
        return timestamp;
    }

    private static void mapResultOperation(ResultadoOperacion resultado, PaymentRegistryDB paymentRegistryDB) {

        paymentRegistryDB.setAnnulationResult(resultado.getCodigo());
        paymentRegistryDB.setAnnulationDescription(resultado.getMensaje());

        if (Constants.ENRQ_PREV_NO_ENCONTRADA.equalsIgnoreCase(resultado.getCodigo())) {
            paymentRegistryDB.setStatus(Constants.EXPIRED);
            paymentRegistryDB.setStatusDescription(Constants.EXPIRED_DESC);
            paymentRegistryDB.setResultDescription(Constants.KO);
        } else if (!Constants.OK.equalsIgnoreCase(resultado.getCodigo())) {
            paymentRegistryDB.setStatus(Constants.CANCELLATION_ERROR);
            paymentRegistryDB.setStatusDescription(Constants.CANCELLATION_ERROR_PSP_RESPONSE_DESC);
            paymentRegistryDB.setResultDescription(Constants.KO);
        }

    }

    private static void mapResultOperationError(PaymentRegistryDB paymentRegistryDB) {

        if (Constants.CANCELLATION_TIMEOUT_DESC.equalsIgnoreCase(paymentRegistryDB.getStatusDescription())) {
            paymentRegistryDB.setAnnulationResult(Constants.ANNULALATION_TIMEOUT_RESUL);
            paymentRegistryDB.setAnnulationDescription(Constants.ANNULATION_TIMEOUT_DESC);
        } else {

            paymentRegistryDB.setAnnulationResult(Constants.ANULLATION_ERROR_RESULT);
            paymentRegistryDB.setAnnulationDescription(Constants.ANULLATION_ERROR_DESC);
        }
        paymentRegistryDB.setResultDescription(Constants.KO);

    }

}