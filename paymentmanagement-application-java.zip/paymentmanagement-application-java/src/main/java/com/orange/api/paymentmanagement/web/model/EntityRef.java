package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EntityRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("role")
	private String role;

	@JsonProperty("amount")
	private Money amount;

	@JsonProperty("taxAmount")
	private Money taxAmount;

	@JsonProperty("totalAmount")
	private Money totalAmount;

	@JsonProperty("item")
	private EntityRef item;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;
}