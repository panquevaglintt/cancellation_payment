package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Describes a given characteristic of an object or entity through a name/value
 * pair.
 */
@Data
@Validated
@JsonInclude(Include.NON_NULL)
public class Characteristic implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("name")
	private String name;

	@JsonProperty("value")
	private String value;

	@JsonProperty("valueType")
	private String valueType;
}