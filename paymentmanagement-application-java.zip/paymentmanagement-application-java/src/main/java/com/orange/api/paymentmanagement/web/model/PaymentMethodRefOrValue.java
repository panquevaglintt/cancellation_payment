package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentMethodRefOrValue implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@referredType")
	private String referredType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("name")
	private String name;

	@JsonProperty("description")
	private String description;

	@JsonProperty("isPreferred")
	private boolean isPreferred;

	@JsonProperty("status")
	private String status;

	@JsonProperty("statusDate")
	private String statusDate;

	@JsonProperty("validFor")
	private TimePeriod validFor;

	@JsonProperty("relatedParty")
	private RelatedParty relatedParty;

	@Valid
	@JsonProperty("account")
	private List<AccountRef> account;

	@JsonProperty("token")
	private String token;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;
}