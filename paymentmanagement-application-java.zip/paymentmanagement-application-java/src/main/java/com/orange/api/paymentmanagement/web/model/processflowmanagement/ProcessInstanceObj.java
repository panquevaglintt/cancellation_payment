package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessInstanceObj implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("processFlowSpecification")
	private String processFlowSpecification;

	@JsonProperty("processFlowDate")
	private String processFlowDate;

	@JsonProperty("state")
	private String state;

	@Valid
	@JsonProperty("channel")
	private List<Channel> channel;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;

	@Valid
	@JsonProperty("relatedEntity")
	private List<RelatedEntity> relatedEntity;

	@Valid
	@JsonProperty("relatedParty")
	private List<RelatedParty> relatedParty;

	@Valid
	@JsonProperty("taskFlow")
	private List<TaskFlow> taskFlow;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}