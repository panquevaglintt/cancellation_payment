package com.orange.api.paymentmanagement.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.ObjectUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.mappers.GenerationIframeMapper;
import com.orange.api.paymentmanagement.service.GenerationIframeService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Iframe;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GenerationIframeServiceImpl implements GenerationIframeService {

    @Value("${urlIframe}")
    private String urlIframe;
    
    @Value("${urlIframe3DS2}")
    private String urlIframe3DS2;

	private FixedValuesRepository fixedValuesRepository;

	private PaymentRegistryRepository paymentRegistryRepository;

	@Autowired
	public GenerationIframeServiceImpl(FixedValuesRepository fixedValuesRepository,
			PaymentRegistryRepository paymentmanagementRepository) {
		this.fixedValuesRepository = fixedValuesRepository;
		this.paymentRegistryRepository = paymentmanagementRepository;
	}

	@Override
	public Payment generationIframe(Payment payment, String app, String zlogin) {
		
		String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
				Constants.TRANSACTION);
		
		FixedValuesDB fixedValues = getFixedValues(app, transactiontype);
		Iframe iframe = null;
		try {
			iframe = GenerationIframeMapper.mapPaymentToIframe(fixedValues, payment, zlogin,transactiontype, urlIframe, urlIframe3DS2);
		} catch (UnsupportedEncodingException e) {
			log.error("Ha fallado el encode de uno de los valores del iframe");
		}
		
		GenerationIframeMapper.mapIframeToPayment(iframe, payment);
		
		registerIframe(payment, app, fixedValues, transactiontype, iframe, zlogin);

		log.info("Se ha generado iframe con Numero Operacion Origen: "+iframe.getNumOpOrigen());

		return payment;
	}

	/**
	 * Register iframe to BBDD
	 * @param payment
	 * @param app
	 * @param fixedValues
	 * @param transactiontype
	 * @param requestWS
	 * @param zlogin
	 * @param responseGeneration
	 */
	private void registerIframe(Payment payment, String app, FixedValuesDB fixedValues, String transactiontype,
			Iframe iframe, String zlogin) {

		String processFlowId = null;
		if(!Constants.AMORTIZATION.equalsIgnoreCase(transactiontype)) {
			processFlowId = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
					Constants.PROCESSFLOW_ID);
		}
		this.paymentRegistryRepository.save(GenerationIframeMapper.mapPaymentManagementDB(payment, app,
				fixedValues, transactiontype, iframe, zlogin, processFlowId));
		log.info("Se ha registrado el iframe en BBDD");

	}
	
	/**
	 * Get fixedValues from BBDD
	 * @param payment
	 * @param app
	 * @param transactiontype 
	 * @return
	 */
	private FixedValuesDB getFixedValues(String app, String transactiontype) {
		
		List<FixedValuesDB> listFixedValues = this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(transactiontype,
				app,Constants.IFRAME);
		
		if (!ObjectUtils.isEmpty(listFixedValues)) {
			return listFixedValues.get(0);
		} else {
			log.error("La transacción o zapp no coincide con lo esperado");
			throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
		}		
	}
	

}