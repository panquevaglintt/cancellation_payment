package com.orange.api.paymentmanagement.db.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;

@Repository
public interface PaymentRegistryRepository extends JpaRepository<PaymentRegistryDB, Long> {

    List<PaymentRegistryDB> findAll();

    public PaymentRegistryDB findByLinkId(String id);

    public PaymentRegistryDB findByOriginOpnumber(String id);
    
    public PaymentRegistryDB findByPaymentMethodId(String id);

    public List<PaymentRegistryDB> findByIdDocument(String document);

    public List<PaymentRegistryDB> findByPhonenumber(String msisdn);

    public List<PaymentRegistryDB> findByVapId(String idVap);


    @Query(value = "from PaymentRegistryDB f WHERE  "
            + "(f.creationDate >= to_date(:startDate, 'yyyy-mm-dd') AND f.creationDate < to_date(:endDate, 'yyyy-mm-dd')) AND f.status IN ('Completed','Cancelled','Cancellation Error','Expired','PreauthorizationRealized','PreauthorizationPaymentError','PreauthorizationConfirmed','PreauthorizationCancelled','PreauthorizationCancellationError','PreauthorizationExpired')")

    List<PaymentRegistryDB> findByCreationDate(@Param("startDate") String startDate, @Param("endDate") String endDate);

    @Query(value = "call paymentmanagement_app.payment_registry_purge()",nativeQuery = true)
    @Transactional 
    @Modifying(clearAutomatically = true)
    void paymentRegistryPurge();

    @Transactional
    @Modifying
    void deleteByUpdateDateBefore(Date deletionDate);

}
