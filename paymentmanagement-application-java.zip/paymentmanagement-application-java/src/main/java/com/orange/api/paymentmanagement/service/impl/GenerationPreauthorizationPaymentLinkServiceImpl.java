package com.orange.api.paymentmanagement.service.impl;

import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.mappers.GenerationPreauthorizationPaymentLinkMapper;
import com.orange.api.paymentmanagement.service.GenerationPreauthorizationPaymentLinkService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestGeneration;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseGeneration;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GenerationPreauthorizationPaymentLinkServiceImpl implements GenerationPreauthorizationPaymentLinkService {

    private IntegrationServiceWSPspClient integrationServiceWSPspClient;

    private FixedValuesRepository fixedValuesRepository;

    private PaymentRegistryRepository paymentRegistryRepository;

    @Autowired
    public GenerationPreauthorizationPaymentLinkServiceImpl(IntegrationServiceWSPspClient integrationServiceWSPspClient,
            FixedValuesRepository fixedValuesRepository, PaymentRegistryRepository paymentmanagementRepository) {
        this.integrationServiceWSPspClient = integrationServiceWSPspClient;
        this.fixedValuesRepository = fixedValuesRepository;
        this.paymentRegistryRepository = paymentmanagementRepository;
    }

    @Override
    public Payment generationPreauthorizationPaymentLink(Payment payment, String app, String zlogin, String zCallerIp) {
        RequestGeneration requestWS = new RequestGeneration();

        String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                Constants.TRANSACTION);

        FixedValuesDB fixedValues = getFixedValues(app, transactiontype);

        GenerationPreauthorizationPaymentLinkMapper.mapPreauthorizationPaymentToRequestGeneration(payment, requestWS, zlogin, fixedValues, zCallerIp);
        log.info("Request generationPreauthorizationPaymentLink: " + requestWS.toString());
        ResponseGeneration responseGeneration = this.integrationServiceWSPspClient.paymentLinkGeneration(requestWS);
        log.info("La llamada para generar el paymentLink por preautorización ha ido correctamente: " + responseGeneration.toString());

        GenerationPreauthorizationPaymentLinkMapper.mapResponseGenerationToPreauthorizationPayment(responseGeneration, payment);

        registerPreauthorizationPaymentLink(payment, app, fixedValues, transactiontype, requestWS, zlogin, responseGeneration);

        log.info("Se ha generado paymentLink por preautorización con Numero Operacion Origen: " + requestWS.getNumOpOrigen());

        return payment;
    }


    private FixedValuesDB getFixedValues(String app, String transactiontype) {

        List<FixedValuesDB> listFixedValues = this.fixedValuesRepository
                .findByTransactiontypeAndAppAndTypelink(transactiontype, app, Constants.PAYMENTLINK);

        if (!ObjectUtils.isEmpty(listFixedValues)) {
            return listFixedValues.get(0);
        } else {
            log.error("La transacción o zapp no coincide con lo esperado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
        }
    }


    private void registerPreauthorizationPaymentLink(Payment payment, String app, FixedValuesDB fixedValues, String transactiontype,
            RequestGeneration requestWS, String zlogin, ResponseGeneration responseGeneration) {

        String processFlowId = null;
            processFlowId = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
                    Constants.PROCESSFLOW_ID);
       
        this.paymentRegistryRepository.save(GenerationPreauthorizationPaymentLinkMapper.mapPreauthorizationPaymentManagementDB(payment, app,
                fixedValues, transactiontype, requestWS, zlogin, responseGeneration, processFlowId));
        log.info("Se ha registrado el paymentLink por preautorización en BBDD");

    }

}