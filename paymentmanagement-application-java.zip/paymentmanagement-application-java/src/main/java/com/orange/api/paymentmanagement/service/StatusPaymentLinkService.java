package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface StatusPaymentLinkService {
	
	Payment statusPaymentLink(String id, String type);

}