package com.orange.api.paymentmanagement.web.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

import java.io.Serial;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Payment implements Serializable {
	@Serial
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("name")
	private String name;

	@JsonProperty("description")
	private String description;

	@JsonProperty("amount")
	private Money amount;

	@JsonProperty("authorizationCode")
	private String authorizationCode;

	@JsonProperty("correlatorId")
	private String correlatorId;

	@JsonProperty("paymentDate")
	private String paymentDate;

	@JsonProperty("status")
	private String status;

	@JsonProperty("statusDate")
	private OffsetDateTime statusDate;

	@JsonProperty("taxAmount")
	private Money taxAmount;

	@JsonProperty("totalAmount")
	private Money totalAmount;

	@JsonProperty("account")
	private AccountRef account;

	@JsonProperty("channel")
	private ChannelRef channel;

	@JsonProperty("payer")
	private RelatedParty payer;

	@JsonProperty("paymentMethod")
	private PaymentMethodRefOrValue paymentMethod;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;

	@Valid
	@JsonProperty("paymentItem")
	private List<PaymentItem> paymentItem;

	@Valid
	@JsonProperty("statusChange")
	private List<StatusChange> statusChange;
}