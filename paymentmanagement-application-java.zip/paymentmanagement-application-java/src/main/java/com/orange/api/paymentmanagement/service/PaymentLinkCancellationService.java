package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

public interface PaymentLinkCancellationService {

    Payment paymentLinkCancellation(Payment payment, String numOrigin, String zLogin);
}
