package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseGeneration implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("coTipoOpLink")
	private String coTipoOpLink;

	@JsonProperty("datosCliente")
	private DatosCliente datosCliente;

	@JsonProperty("fxAltaLink")
	private String fxAltaLink;

	@JsonProperty("fxFinValidez")
	private String fxFinValidez;

	@JsonProperty("idLink")
	private String idLink;

	@JsonProperty("idioma")
	private String idioma;

	@JsonProperty("importe")
	private String importe;

	@JsonProperty("link")
	private String link;

	@JsonProperty("moneda")
	private String moneda;

	@JsonProperty("numIntentos")
	private Integer numIntentos;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("numOperacionNNP")
	private String numOperacionNNP;

	@JsonProperty("parametrosAdicionales")
	private ParametrosAdicionales parametrosAdicionales;

	@JsonProperty("paypal")
	private Boolean paypal;

	@JsonProperty("resultadoOperacion")
	private ResultadoOperacion resultadoOperacion;
}