package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskFlowRelationship implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("relationshipType")
	private String relationshipType;

	@JsonProperty("taskFlow")
	private TaskFlow taskFlow;
}