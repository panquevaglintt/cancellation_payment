package com.orange.api.paymentmanagement.web.model.processflowmanagement;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskFlowObj implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("id")
	private String id;

	@JsonProperty("href")
	private String href;

	@JsonProperty("completionMethod")
	private String completionMethod;

	@JsonProperty("isMandatory")
	private Boolean isMandatory;

	@JsonProperty("priority")
	private Integer priority;

	@JsonProperty("taskFlowSpecification")
	private String taskFlowSpecification;

	@JsonProperty("state")
	private String state;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic = null;

	@Valid
	@JsonProperty("relatedEntity")
	private List<RelatedEntity> relatedEntity = null;

	@Valid
	@JsonProperty("relatedParty")
	private List<RelatedParty> relatedParty = null;

	@Valid
	@JsonProperty("channel")
	private List<Channel> channel = null;

	@Valid
	@JsonProperty("taskFlowRelationship")
	private List<TaskFlowRelationship> taskFlowRelationship = null;
}