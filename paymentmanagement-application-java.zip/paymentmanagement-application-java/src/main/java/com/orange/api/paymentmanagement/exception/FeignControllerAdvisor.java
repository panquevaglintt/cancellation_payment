package com.orange.api.paymentmanagement.exception;

import java.net.SocketTimeoutException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;

import com.orange.api.paymentmanagement.errors.CommonServiceErrors;
import com.orange.openapiosp.boot.errorhandler.domain.ErrorMessage;
import com.orange.openapiosp.boot.errorhandler.exception.OrangeCommonErrorData;

import feign.RetryableException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class FeignControllerAdvisor {

	@ExceptionHandler(value = { RetryableException.class })
	public ResponseEntity<ErrorMessage> handleException(RetryableException ex, ServletWebRequest request) {

		log.error("Controlled error when calling WebService: {}", ex.getMessage(), ex);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");

		String customErrorCode = null;
		HttpStatus status = null;

		if (ex.getCause() instanceof SocketTimeoutException) {
			status = HttpStatus.GATEWAY_TIMEOUT;
			customErrorCode = CommonServiceErrors.SERVICE_UNAVAILABLE.toString();
		} else {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			customErrorCode = CommonServiceErrors.SERVICE_UNABLE_CONNECT.toString();
		}

		// Generar respuesta
		OrangeCommonErrorData errorData = OrangeCommonErrorData.builder()
				.fromMessageProperties(status.value(), customErrorCode).build();
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setCode(errorData.getCode());
		errorMessage.setMessage(errorData.getMessage());
		errorMessage.setDescription(errorData.getDescription());

		return new ResponseEntity<ErrorMessage>(errorMessage, headers, status);
	}
}