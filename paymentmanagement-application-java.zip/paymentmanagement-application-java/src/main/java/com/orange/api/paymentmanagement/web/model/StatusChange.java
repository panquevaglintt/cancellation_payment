package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * StatusChange
 */
@Data
@Validated
@JsonInclude(Include.NON_NULL)
public class StatusChange implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("@baseType")
	private String baseType;

	@JsonProperty("@schemaLocation")
	private String schemaLocation;

	@JsonProperty("@type")
	private String type;

	@JsonProperty("changeDate")
	private String changeDate;

	@JsonProperty("changeReason")
	private String changeReason;

	@JsonProperty("status")
	private String status;

	@Valid
	@JsonProperty("characteristic")
	private List<Characteristic> characteristic;
}