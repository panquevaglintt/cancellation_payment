package com.orange.api.paymentmanagement.errors;

public enum CommonServiceErrors {
    SERVICE_ERROR_REQUEST,	// La peticion enviada no es valida
	SERVICE_ERROR_RESPONSE, // El servicio me ha respondido con un error
	SERVICE_UNAVAILABLE,	// Servicio no disponible/timeout
	SERVICE_UNABLE_CONNECT,	// Fallo al conectar con el servicio (retryable, incluye recurso fisico no encontrado)
	SERVICE_ERROR_CALL, 		// Para el resto de errores en la llamada
    WEB_SERVICE_ERROR_REQUEST,	// La peticion enviada no es valida
	WEB_SERVICE_ERROR_RESPONSE, // El servicio me ha respondido con un error
	WEB_SERVICE_ERROR_CALL, 		// Para el resto de errores en la llamada
    MDW_SERVICE_ERROR_REQUEST,	// La peticion enviada no es valida
	MDW_SERVICE_ERROR_RESPONSE, // El servicio me ha respondido con un error
	ERROR_CONNECTION_BBDD, // El servicio me ha respondido con un error al conectar a BBDD
	MDW_SERVICE_ERROR_CALL 		// Para el resto de errores en la llamada
}