package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

public interface GenerationTokenPaymentService {

    Payment generationTokenPayment(Payment payment, String zApp, String zLogin, String zCallerIp);

}
