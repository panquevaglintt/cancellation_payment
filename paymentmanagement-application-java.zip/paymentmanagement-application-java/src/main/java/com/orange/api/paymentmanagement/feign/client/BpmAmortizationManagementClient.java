package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;

@FeignClient(name = "bpmamortizationmanagement", url = "${spring.cloud.openfeign.client.config.bpmamortizationmanagement.url}")
public interface BpmAmortizationManagementClient {

	@PatchMapping(path = "/processFlow/amortizationManagement/{processFlowId}/taskFlow/update")
	ResponseEntity<String> updateStatus(@PathVariable("processFlowId") String processFlowId,
			@RequestBody TaskFlowObj inputJson);

	@GetMapping(path = "/processFlow/amortizationManagement?relatedEntity.type=E-Payment&relatedEntity.paymentItem.item.id={relatedEntity.paymentItem.id}&relatedEntity.paymentItem.item.role=VAP")
	ResponseEntity<String> getProccessFlow(@PathVariable(value = "relatedEntity.paymentItem.id") String paymentItemId);
}