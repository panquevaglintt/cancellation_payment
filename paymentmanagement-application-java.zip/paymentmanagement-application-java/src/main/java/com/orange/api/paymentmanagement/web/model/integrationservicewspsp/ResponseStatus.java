package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("datosLink")
	private DatosLink datosLink;

	@JsonProperty("operaciones")
	private List<DatosOperacion> operaciones;

	@JsonProperty("datosResolutor")
	private DatosResolutor datosResolutor;

	@JsonProperty("numAutorizacion")
	private String numAutorizacion;

	@JsonProperty("numOperacionNNP")
	private Integer numOperacionNNP;

	@JsonProperty("parametrosAdicionales")
	private ParametrosAdicionales parametrosAdicionales;

	@JsonProperty("resultadoOperacion")
	private ResultadoOperacion resultadoOperacion;

	@JsonProperty("datosCliente")
	private DatosCliente datosCliente;

	@JsonProperty("fechaOpOrigen")
	private String fechaOpOrigen;

	@JsonProperty("idioma")
	private String idioma;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("usuario")
	private String usuario;

	@JsonProperty("estado")
	private String estado;

	@JsonProperty("fxAltaLink")
	private OffsetDateTime fxAltaLink;

	@JsonProperty("link")
	private String link;

	@JsonProperty("numIntentosRestantes")
	private Integer numIntentosRestantes;
}