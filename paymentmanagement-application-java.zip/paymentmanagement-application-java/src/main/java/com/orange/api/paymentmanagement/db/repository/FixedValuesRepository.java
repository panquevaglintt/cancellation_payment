package com.orange.api.paymentmanagement.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;

/**
 * Spring Data repository for the FixedValuesDB entity
 */
@Repository
public interface FixedValuesRepository
		extends JpaRepository<FixedValuesDB, Long> {

	/**
	 * This method obtains all registries.
	 * 
	 * @return FixedValuesDB
	 * 
	 */
	List<FixedValuesDB> findAll();
	
	/**
	 * This method obtains one registry 
	 * @param transaction
	 * @param app
	 * @return
	 */
    public List<FixedValuesDB> findByTransactiontypeAndAppAndTypelink(String transactiontype, String app, String typeLink);

	
    public List<FixedValuesDB> findByTransactiontypeAndApp(String transactiontype, String app);

	


}
