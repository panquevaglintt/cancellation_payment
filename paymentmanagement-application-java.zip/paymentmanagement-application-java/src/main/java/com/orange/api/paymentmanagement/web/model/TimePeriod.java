package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimePeriod  implements Serializable  {
  private static final long serialVersionUID = 1L;

  @JsonProperty("endDateTime")
  private String endDateTime = null;

  @JsonProperty("startDateTime")
  private String startDateTime = null;

  
}
