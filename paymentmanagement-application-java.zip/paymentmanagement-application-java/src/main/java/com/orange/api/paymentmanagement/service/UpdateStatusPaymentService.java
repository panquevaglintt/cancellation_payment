package com.orange.api.paymentmanagement.service;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface UpdateStatusPaymentService {
	
	
	/**
	 * This service return status payment
	 * @param id
	 * @return
	 */
	Payment updateStatusPayment(String id, Payment body);

}