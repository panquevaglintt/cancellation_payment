package com.orange.api.paymentmanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.db.repository.PaymentHistoricalRegistryRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.service.CleanDBService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CleanDBServiceImpl implements CleanDBService {

    private PaymentRegistryRepository paymentRegistryRepository;
    private PaymentHistoricalRegistryRepository paymentHistoricalRegistryRepository;

    @Autowired
    public CleanDBServiceImpl(PaymentRegistryRepository paymentRegistryRepository,
            PaymentHistoricalRegistryRepository paymentHistoricalRegistryRepository) {
        this.paymentRegistryRepository = paymentRegistryRepository;
        this.paymentHistoricalRegistryRepository = paymentHistoricalRegistryRepository;
    }

    @Override
    public void cleanDb() {
        
        try {           
            log.info("Se llama al proceso de purgado de la tabla payment_registry");
            paymentRegistryRepository.paymentRegistryPurge();
            log.info("Se llama al proceso de purgado de la tabla payment_historical_registry");
            paymentHistoricalRegistryRepository.paymentHistoricalRegistryPurge();
            log.info("El purgado ha finalizado correctamente");
        } catch (Exception e) {
            // Si falla la bbdd se sigue la ejecución
            log.error("Error en el purgado del payment_registry.", e.getMessage());  
        }
    }
}
