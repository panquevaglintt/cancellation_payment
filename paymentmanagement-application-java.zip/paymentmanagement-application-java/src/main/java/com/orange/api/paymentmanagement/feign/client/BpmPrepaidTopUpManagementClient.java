package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;

@FeignClient(name = "bpmprepaidtopupmanagement", url = "${spring.cloud.openfeign.client.config.bpmprepaidtopupmanagement.url}")
public interface BpmPrepaidTopUpManagementClient {

	@PatchMapping(path = "/processFlow/prepaidTopUpManagement/{processFlowId}/taskFlow/updateIframe")
	ResponseEntity<String> updateStatusIframe(@PathVariable("processFlowId") String processFlowId,
			@RequestBody TaskFlowObj inputJson);
	
    @PatchMapping(path = "/processFlow/prepaidTopUpManagement/{processFlowId}/taskFlow/updateFile")
    ResponseEntity<String> updateFile(@PathVariable("processFlowId") String processFlowId,
            @RequestBody TaskFlowObj inputJson);
    
    @PatchMapping(path = "/processFlow/prepaidTopUpManagement/{processFlowId}/taskFlow/updateScheduled")
    ResponseEntity<String> updateScheduled(@PathVariable("processFlowId") String processFlowId,
            @RequestBody TaskFlowObj inputJson);

}