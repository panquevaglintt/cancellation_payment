package com.orange.api.paymentmanagement.mappers;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Iframe;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public final class GenerationPreauthorizationIframeMapper {
   
    public static Iframe mapPreauthorizationPaymentToIframe(FixedValuesDB fixedValues, Payment paymentIframe, String zLogin, String transactiontype, String urlIframe, String zCallerIp)
            throws UnsupportedEncodingException {
        String urlPL = urlIframe;
        String date = mapDate();
        String msisdn = PaymentManagementUtils.searchValueCharacteristic(paymentIframe.getCharacteristic(),
                Constants.PHONENUMBER);
        String documento = PaymentManagementUtils.mapDocument(paymentIframe.getPayer());
        int amountInt = paymentIframe.getTotalAmount().getValue().intValue();
        String amount = String.valueOf(amountInt);
        String custCode = PaymentManagementUtils.mapCustomerCode(paymentIframe.getPayer());
        String numOpOrigen = PaymentManagementUtils.getNumOrigen();
        log.info("Se va a generar iframe de preautoricacion con Numero Operacion Origen: " + numOpOrigen);

        String urlOK = PaymentManagementUtils.searchValueCharacteristic(paymentIframe.getCharacteristic(),
                Constants.REDIRECTION_OK);
        String urlKO = PaymentManagementUtils.searchValueCharacteristic(paymentIframe.getCharacteristic(),
                Constants.REDIRECTION_KO);

        StringBuilder strHashBuilder = new StringBuilder();
        strHashBuilder.append(date).append(amount).append(fixedValues.getClientCode())
                .append(fixedValues.getCommercialCode()).append(fixedValues.getTerminalCode()).append(numOpOrigen)
                .append(urlOK).append(fixedValues.getSeed());
        String hash = DigestUtils.sha256Hex(strHashBuilder.toString());

        urlPL += "?coCliente=" + fixedValues.getClientCode();
        urlPL += "&coComercio=" + fixedValues.getCommercialCode();
        urlPL += "&coTerminal=" + fixedValues.getTerminalCode();

        urlPL += "&fechaOpOrigen=" + URLEncoder.encode(date, Constants.C_UTF8);
        urlPL += "&idioma=" + fixedValues.getLanguage();
        urlPL += "&numOpOrigen=" + numOpOrigen;
        urlPL += "&importe=" + amount;
        urlPL += "&urlOk=" + URLEncoder.encode(urlOK, Constants.C_UTF8);
        urlPL += "&urlKo=" + URLEncoder.encode(urlKO, Constants.C_UTF8);
        urlPL += "&moneda=" + fixedValues.getCurrency();
        urlPL += "&hash=" + hash;
        urlPL += "&urlCss=" + URLEncoder.encode(fixedValues.getUrlCss(), Constants.C_UTF8);
        urlPL += "&botonForm=" + fixedValues.getFormButton();
        urlPL += "&template=" + fixedValues.getTemplate();
        urlPL += "&cardType=" + fixedValues.getCardType();
        urlPL += "&msisdn=" + msisdn;
        urlPL += "&documento=" + documento;
        urlPL += "&usuario=" + zLogin;
        if(StringUtils.isNotEmpty(custCode)) {
            urlPL += "&customer_code=" + custCode;
        }
        urlPL += "&target=" + fixedValues.getTarget();
        
        String processFlowId = null;
        processFlowId = PaymentManagementUtils.searchValueCharacteristic(paymentIframe.getCharacteristic(),
                Constants.PROCESSFLOW_ID);
        urlPL += "&PedidoCRM=" + processFlowId;
        urlPL += "&pedidoTOL=" + zCallerIp;
        

        Iframe iframeObject = new Iframe();

        iframeObject.setDate(date);
        iframeObject.setIframe(urlPL);
        iframeObject.setNumOpOrigen(numOpOrigen);
        iframeObject.setUrlKo(urlKO);
        iframeObject.setUrlOk(urlOK);
        iframeObject.setHash(hash);
        iframeObject.setCustCode(custCode);

        return iframeObject;

    }


    private static String mapDate() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        return date;
    }
    
    public static void mapIframeToPreauthorizationPayment(Iframe iframe, Payment paymentIframe) {

        paymentIframe.setId(iframe.getNumOpOrigen());
        paymentIframe.setCharacteristic(mapCharacteristicResponse(iframe.getIframe(), paymentIframe.getCharacteristic()));
        paymentIframe.setStatus(Constants.PREAUTH_PENDING);
        log.info("La fechaPayment de entrada al metod para formatear es : {}", iframe.getDate());
        paymentIframe.setStatusDate(PaymentManagementUtils.extractDateOriginIframe(iframe.getDate(), Constants.TIMEZONE_UTC));
        log.info("La fechaPayment de salida al metod para formatear es : {}", iframe.getDate());
    }

    private static List<Characteristic> mapCharacteristicResponse(String iframe,
            List<Characteristic> listCharacteristic) {
        Characteristic characteristicIframe = new Characteristic();

        characteristicIframe.setName(Constants.PAYMENTLINKIFRAME);
        characteristicIframe.setValue(iframe);

        listCharacteristic.add(characteristicIframe);

        return listCharacteristic;
    }

    public static PaymentRegistryDB mapPreauthorizationPaymentManagementDB(Payment paymentIframe, String zapp, FixedValuesDB fixedValues,
            String transaction, Iframe iframe, String zlogin, String processFlowId) {

        PaymentRegistryDB paymentRegistryIframeDB = new PaymentRegistryDB();

        paymentRegistryIframeDB.setAmount(paymentIframe.getTotalAmount().getValue().toString());
        if (paymentIframe.getPaymentItem() != null) {
            paymentRegistryIframeDB.setBscsIdentifier(mapBscs(paymentIframe.getPaymentItem()));
        }
        paymentRegistryIframeDB.setChannel(zapp);
        paymentRegistryIframeDB.setClientCode(fixedValues.getClientCode());
        paymentRegistryIframeDB.setCommercialCode(fixedValues.getCommercialCode());
        paymentRegistryIframeDB.setCurrency(fixedValues.getCurrency());
        paymentRegistryIframeDB.setIdDocument(PaymentManagementUtils.mapDocument(paymentIframe.getPayer()));
        paymentRegistryIframeDB.setTypeDocument(GenerationPaymentLinkMapper.mapTypeDocument(paymentIframe.getPayer()));
        paymentRegistryIframeDB.setPhonenumber(
                PaymentManagementUtils.searchValueCharacteristic(paymentIframe.getCharacteristic(), Constants.PHONENUMBER));
        paymentRegistryIframeDB.setType(paymentIframe.getPayer().getReferredType());
        if (paymentIframe.getPaymentItem() != null) {
            paymentRegistryIframeDB.setVapId(paymentIframe.getPaymentItem().get(0).getItem().getId());
        }
        paymentRegistryIframeDB.setLanguage(fixedValues.getLanguage());

        paymentRegistryIframeDB.setOriginOpnumber(iframe.getNumOpOrigen());
        paymentRegistryIframeDB.setPaymentAttempts(fixedValues.getPaymentRetries());
        paymentRegistryIframeDB.setStatus(Constants.PREAUTH_PENDING);
        paymentRegistryIframeDB.setStatusDescription(Constants.PENDIENTE_PREAUTH);
        paymentRegistryIframeDB.setTransactiontype(transaction);
        paymentRegistryIframeDB.setTerminalCode(fixedValues.getTerminalCode());
        paymentRegistryIframeDB.setUserId(zlogin);
        paymentRegistryIframeDB.setProcessflowId(processFlowId);
        paymentRegistryIframeDB.setHash(iframe.getHash());
        paymentRegistryIframeDB.setCustCode(iframe.getCustCode());
        paymentRegistryIframeDB.setUrlKo(iframe.getUrlKo());
        paymentRegistryIframeDB.setUrlOk(iframe.getUrlOk());
        paymentRegistryIframeDB.setUrlIframe(iframe.getIframe());
        paymentRegistryIframeDB.setPaymentUpdate(formatDateIframe(iframe.getDate()));
        paymentRegistryIframeDB.setPaymentFlow(Constants.PAYMENT_FLOW_IFRAME);
        

        log.info("Se ha creado el objeto para guardar en bbdd");

        return paymentRegistryIframeDB;
    }

    public static String formatDateIframe(String dateIframe) {
        SimpleDateFormat format0 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        Date date = null;
        try {
            date = format0.parse(dateIframe);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }
        log.info("La fechaupdete de entrada al metod para formatear es : {}", date);
        SimpleDateFormat format1 = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        format1.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String response = format1.format(date);
        return response;
    }

    public static String mapBscs(List<PaymentItem> listPaymentItem) {
        String codebscsPL = null;

        for (PaymentItem paymentItem : listPaymentItem) {
            if (Constants.VAP.equalsIgnoreCase(paymentItem.getItem().getRole())) {
                codebscsPL = PaymentManagementUtils.searchValueCharacteristic(paymentItem.getItem().getCharacteristic(),
                        Constants.BSCSCODE);
            }
        }

        return codebscsPL;
    }

}