package com.orange.api.paymentmanagement.service.impl;

import java.util.List;
import java.util.concurrent.TimeoutException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.ObjectUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.mappers.AnnulationAndReturnedPaymentMapper;
import com.orange.api.paymentmanagement.service.PaymentLinkAnnulationService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.RequestAnnulationAndReturned;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseAnnulationAndReturned;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentLinkAnnulationServiceImpl implements PaymentLinkAnnulationService {

    private IntegrationServiceWSPspClient integrationServiceWSPspClient;

    private FixedValuesRepository fixedValuesRepository;

    private PaymentRegistryRepository paymentRegistryRepository;

    @Autowired
    public PaymentLinkAnnulationServiceImpl(IntegrationServiceWSPspClient integrationServiceWSPspClient,
                                            FixedValuesRepository fixedValuesRepository, PaymentRegistryRepository paymentmanagementRepository) {
        this.integrationServiceWSPspClient = integrationServiceWSPspClient;
        this.fixedValuesRepository = fixedValuesRepository;
        this.paymentRegistryRepository = paymentmanagementRepository;
    }

    @Override
    public Payment paymentLinkAnnulation(Payment payment, String numOrigin) {
        RequestAnnulationAndReturned requestWS = new RequestAnnulationAndReturned();

        PaymentRegistryDB paymentRegistryDB = this.paymentRegistryRepository.findByOriginOpnumber(numOrigin);
        if (ObjectUtils.isEmpty(paymentRegistryDB)) {
            log.error("No se ha encontrado ningun registro en BBDD");
            throw new OpenApiNotFoundException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
        }

        String transactiontype = paymentRegistryDB.getTransactiontype();
        String app = paymentRegistryDB.getChannel();

        FixedValuesDB fixedValues = null;
        List<FixedValuesDB> listFixedValues = this.fixedValuesRepository.findByTransactiontypeAndApp(transactiontype,
                app);
        if (!ObjectUtils.isEmpty(listFixedValues)) {
            fixedValues = listFixedValues.get(0);
        } else {
            log.error("La transacción o zapp no coincide con lo esperado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
        }

        AnnulationAndReturnedPaymentMapper.mapPaymentToRequestAnnulationAndReturned(payment, requestWS, paymentRegistryDB, fixedValues);

        ResponseAnnulationAndReturned responseAnnulationAndReturned = new ResponseAnnulationAndReturned();
        try {
            log.info("Se va a llamar al servicio de Anulacion del Paymentlink al WS de PSP con la peticion: {}"
                    + requestWS.toString());
            responseAnnulationAndReturned = this.integrationServiceWSPspClient.paymentLinkAnnulation(requestWS);
            log.info("Respuesta del servicio de Anulacion del Paymentlink al WS de PSP: {}"
                    + responseAnnulationAndReturned.toString());

            AnnulationAndReturnedPaymentMapper.mapPaymentRegistry(paymentRegistryDB, responseAnnulationAndReturned, requestWS,
                    Constants.CANCELLED, Constants.CANCELLED_DESC);

            log.info("La llamada para anular con numero operacion origen: " + requestWS.getNumOpOrigen()
                    + "ha ido correctamente");
        } catch (Exception e) {

            if (e instanceof TimeoutException) {

                AnnulationAndReturnedPaymentMapper.mapPaymentRegistryError(paymentRegistryDB, requestWS,
                        Constants.CANCELLATION_ERROR, Constants.CANCELLATION_TIMEOUT_DESC);

                log.info("La llamada para anular con numero operacion origen: " + requestWS.getNumOpOrigen()
                        + "ha fallado por Timeout");

            } else {

                AnnulationAndReturnedPaymentMapper.mapPaymentRegistryError(paymentRegistryDB, requestWS,
                        Constants.CANCELLATION_ERROR, Constants.CANCELLATION_ERROR_DESC);

                log.info("La llamada para anular con numero operacion origen: " + requestWS.getNumOpOrigen()
                        + "ha fallado");
            }
        }

        this.paymentRegistryRepository.save(paymentRegistryDB);

        return payment;
    }
}