package com.orange.api.paymentmanagement.web.model.integrationservicewspsp;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DatosTarjetaRespuesta {

    @JsonProperty("bin")
    private String bin;
    
    @JsonProperty("mascara")
    private String mascara;
    
    @JsonProperty("numeroCifrado")
    private String numeroCifrado;
}
