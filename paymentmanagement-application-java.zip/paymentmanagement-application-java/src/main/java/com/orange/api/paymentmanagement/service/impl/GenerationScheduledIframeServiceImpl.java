package com.orange.api.paymentmanagement.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.mappers.GenerationScheduledIframeMapper;
import com.orange.api.paymentmanagement.service.GenerationScheduledIframeService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Iframe;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GenerationScheduledIframeServiceImpl implements GenerationScheduledIframeService {

    @Value("${urlIframeScheduled}")
    private String urlIframeScheduled;
    
	private FixedValuesRepository fixedValuesRepository;

	private PaymentRegistryRepository paymentRegistryRepository;

	@Autowired
	public GenerationScheduledIframeServiceImpl(FixedValuesRepository fixedValuesRepository,
			PaymentRegistryRepository paymentmanagementRepository) {
		this.fixedValuesRepository = fixedValuesRepository;
		this.paymentRegistryRepository = paymentmanagementRepository;
	}

	@Override
	public Payment generationScheduledIframe(Payment payment, String app, String zlogin, String zCallerIp) {
		
		String transactiontype = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
				Constants.TRANSACTION);
		
		FixedValuesDB fixedValues = getFixedValues(app, transactiontype);
		Iframe iframe = null;
		try {
			iframe = GenerationScheduledIframeMapper.mapScheduledPaymentToIframe(fixedValues, payment, zlogin,transactiontype, urlIframeScheduled, zCallerIp);
		} catch (UnsupportedEncodingException e) {
			log.error("Ha fallado el encode de uno de los valores del iframe de recarga programada");
		}
		
		GenerationScheduledIframeMapper.mapIframeToScheduledPayment(iframe, payment);
		
		registerIframe(payment, app, fixedValues, transactiontype, iframe, zlogin);

		log.info("Se ha generado iframe de recarga programada con Numero Operacion Origen: "+iframe.getNumOpOrigen());

		return payment;
	}


	private void registerIframe(Payment payment, String app, FixedValuesDB fixedValues, String transactiontype,
			Iframe iframe, String zlogin) {

		String processFlowId = null;
			processFlowId = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(),
					Constants.PROCESSFLOW_ID);
	
		this.paymentRegistryRepository.save(GenerationScheduledIframeMapper.mapScheduledPaymentManagementDB(payment, app,
				fixedValues, transactiontype, iframe, zlogin, processFlowId));
		log.info("Se ha registrado el iframe de recarga programada en BBDD");

	}
	
	private FixedValuesDB getFixedValues(String app, String transactiontype) {
		
		List<FixedValuesDB> listFixedValues = this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(transactiontype,
				app,Constants.IFRAME);
		
		if (!ObjectUtils.isEmpty(listFixedValues)) {
			return listFixedValues.get(0);
		} else {
			log.error("La transacción o zapp no coincide con lo esperado");
			throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
		}		
	}
	

}