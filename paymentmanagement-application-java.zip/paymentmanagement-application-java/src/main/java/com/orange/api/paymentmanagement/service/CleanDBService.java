package com.orange.api.paymentmanagement.service;

/**
 * CleanDB service interface.
 */

public interface CleanDBService {

	/**
	 * This service performs a clean operation in the service DB in order to delete
	 * outdated DB registries in all tablespaces.
	 */
	void cleanDb();

}
