package com.orange.api.paymentmanagement.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.orange.api.paymentmanagement.web.model.processflowmanagement.TaskFlowObj;

@FeignClient(name = "bpmrecoverymanagement", url = "${spring.cloud.openfeign.client.config.bpmrecoverymanagement.url}")
public interface BpmRecoveryManagementClient {

	@PatchMapping(path = "/processFlow/recoveryManagement/{processFlowId}/taskFlow/updateIframe")
	ResponseEntity<String> updateStatusIframe(@PathVariable("processFlowId") String processFlowId,
			@RequestBody TaskFlowObj inputJson);

	@PatchMapping(path = "/processFlow/recoveryManagement/{processFlowId}/taskFlow/update")
	ResponseEntity<String> updateStatus(@PathVariable("processFlowId") String processFlowId,
			@RequestBody TaskFlowObj inputJson);

}