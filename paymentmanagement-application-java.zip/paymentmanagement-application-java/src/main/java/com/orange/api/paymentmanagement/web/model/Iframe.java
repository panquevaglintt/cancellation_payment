package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Iframe implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("numOpOrigen")
	private String numOpOrigen;

	@JsonProperty("iframe")
	private String iframe;

	@JsonProperty("date")
	private String date;
	
	@JsonProperty("urlOk")
	private String urlOk;
	
	@JsonProperty("urlKo")
	private String urlKo;
	
	@JsonProperty("hash")
	private String hash;
	
	@JsonProperty("custCode")
	private String custCode;

}