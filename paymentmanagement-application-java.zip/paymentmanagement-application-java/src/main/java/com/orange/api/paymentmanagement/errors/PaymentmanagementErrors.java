package com.orange.api.paymentmanagement.errors;

public enum PaymentmanagementErrors {
    INVALID_BODY,
    INVALID_APP,
    ERROR_REGISTER_NOTFOUND,
    FIELD_NULL,
    TOTAL_AMOUNT,
    PHONE_NUMBER,
    TRANSACTION_TYPE,
    PROCESS_FROLW_ID,
    INVALID_DATE_FORMAT

}