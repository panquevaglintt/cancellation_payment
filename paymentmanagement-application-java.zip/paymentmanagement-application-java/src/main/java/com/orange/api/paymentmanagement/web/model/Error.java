package com.orange.api.paymentmanagement.web.model;

import java.io.Serializable;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Error implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("code")
	private Integer code;

	@JsonProperty("message")
	private String message;

	@JsonProperty("description")
	private String description;

	@JsonProperty("infoURL")
	private String infoURL;

	@JsonProperty("details")
	@Valid
	private List<ErrorDetail> details;
}