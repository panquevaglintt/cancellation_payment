package com.orange.api.paymentmanagement.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.OrganizationIdentification;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosLink;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PaymentManagementUtils {
    
    public static Timestamp getDateTimestamp(OffsetDateTime date) {

        Timestamp timestamp1 = Timestamp.valueOf(date.toLocalDateTime());

        return timestamp1;

    }

    public static String getStatus(DatosLink datosLink) {
        String operacion = null;
        String status = null;
        if (datosLink != null) {
            if (datosLink.getNumIntentos() == 0) {
                operacion = Constants.CERO;
            } else {
                operacion = datosLink.getEstado();
            }

            switch (operacion) {
            case Constants.ACE:
                status = Constants.PAID;
                break;
            case Constants.DEN:
                status = Constants.PAYMENTERROR;
                break;
            case Constants.PRO:
                status = statusCorrect(datosLink);
                break;
            case Constants.CERO:
                status = Constants.PAYMENTERROR;
                break;
            default:
                break;
            }
        }

        return status;
    }
    
    public static String getStatusPreauth(DatosLink datosLink) {
        String operacion = null;
        String status = null;
        if (datosLink != null) {
            if (datosLink.getNumIntentos() == 0) {
                operacion = Constants.CERO;
            } else {
                operacion = datosLink.getEstado();
            }

            switch (operacion) {
            case Constants.ACE:
                status = Constants.PREAUTH_REALIZED;
                break;
            case Constants.DEN:
                status = Constants.PREAUTH_PAYMENT_ERROR;
                break;
            case Constants.PRO:
                status = statusCorrectPreauth(datosLink);
                break;
            case Constants.CERO:
                status = Constants.PREAUTH_PAYMENT_ERROR;
                break;
            default:
                break;
            }
        }

        return status;
    }

    private static String statusCorrect(DatosLink datosLink) {
        if (datosLink.getFxFinValidez() != null) {
            Calendar gc = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
            SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSSXXX);
            String date = sdfMadrid.format(gc.getTime());
            try {
                Date dateNow = sdfMadrid.parse(date);
                Date dateExpiration = sdfMadrid.parse(datosLink.getFxFinValidez());
                if (dateNow.after(dateExpiration)) {
                    return Constants.EXPIRED;
                }
            } catch (ParseException e) {
                log.error("La fecha no tiene el formato esperado");
            }
        }
        return Constants.PENDING;
    }
    
    private static String statusCorrectPreauth(DatosLink datosLink) {
        if (datosLink.getFxFinValidez() != null) {
            Calendar gc = Calendar.getInstance(TimeZone.getTimeZone(Constants.TIMEZONE_UTC));
            SimpleDateFormat sdfUTC = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSSXXX);
            String date = sdfUTC.format(gc.getTime());
            try {
                Date dateNow = sdfUTC.parse(date);
                Date dateExpiration = sdfUTC.parse(datosLink.getFxFinValidez());
                if (dateNow.after(dateExpiration)) {
                    return Constants.PREAUTH_EXPIRED;
                }
            } catch (ParseException e) {
                log.error("La fecha no tiene el formato esperado");
            }
        }
        return Constants.PREAUTH_PENDING;
    }

    public static String searchValueCharacteristic(List<Characteristic> characteristics, String name) {
        String value = null;
        searchCharacteristic: for (Characteristic characteristic : characteristics) {
            if (name.equalsIgnoreCase(characteristic.getName())) {
                value = characteristic.getValue();
                break searchCharacteristic;
            }
        }
        return value;
    }

    public static String getNumOrigen() {
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdfMadrid = new SimpleDateFormat(Constants.C_YYYYMMDDHHMMSS);
        sdfMadrid.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));
        String date = sdfMadrid.format(calendar.getTime());

        int numero = (int) (Math.random() * 99999);
        String formatted = String.format("%0" + 5 + "d", Integer.valueOf(numero));

        return "A" + date + formatted;
    }

    public static OffsetDateTime getDateOrigin() {

        GregorianCalendar gc = new GregorianCalendar();
        OffsetDateTime od = gc.toZonedDateTime().toOffsetDateTime();

        return od;

    }

    public static OffsetDateTime extractDate(String fxAltaLink, String timeZone, String dateFormat) {
        SimpleDateFormat format = new SimpleDateFormat(dateFormat);
        Date date = null;
        try {
            date = format.parse(fxAltaLink);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }

        format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        format.setTimeZone(TimeZone.getTimeZone(timeZone));
        OffsetDateTime offsetDateTime = OffsetDateTime.parse(format.format(date));
        return offsetDateTime;
    }

    public static String extractDateStatus(String fxFinValidez, String timeZone) {
        SimpleDateFormat format = new SimpleDateFormat(Constants.C_YYYY_MM_DD_T_HH_MM_SSXXX);
        Date date = null;
        try {
            date = format.parse(fxFinValidez);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }

        format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        format.setTimeZone(TimeZone.getTimeZone(timeZone));

        return format.format(date);
    }

    public static String dateFormat(Date date) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/ddTHH:mm:ssZ");

        return dateFormat.format(date);

    }

    public static String extractFechaOpOrigen(String fxFinValidez) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = null;
        try {
            date = format.parse(fxFinValidez);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }

        format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        format.setTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE_EUROPE_MADRID));

        return format.format(date);
    }

    public static OffsetDateTime extractDateOriginIframe(String fxAltaLink, String timeZone) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z");
        Date date = null;
        try {
            date = format.parse(fxAltaLink);
        } catch (ParseException e) {
            log.error("La fecha no tiene el formato esperado");
        }

        format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        format.setTimeZone(TimeZone.getTimeZone(timeZone));

        return OffsetDateTime.parse(format.format(date));
    }

    public static String mapDocument(RelatedParty payer) {

        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
            for (IndividualIdentification individual : payer.getIndividualIdentification()) {
                if (!Constants.CUSTOMER_CODE.equalsIgnoreCase(individual.getIdentificationType())) {
                    return individual.getIdentificationId();
                }
            }
        } else {
            for (OrganizationIdentification organization : payer.getOrganizationIdentification()) {
                if (!Constants.CUSTOMER_CODE.equalsIgnoreCase(organization.getIdentificationType())) {
                    return organization.getIdentificationId();
                }
            }
        }
        return null;
    }

    public static String mapCustomerCode(RelatedParty payer) {

        if (Constants.REFERRED_TYPE_INDIVIDUAL.equalsIgnoreCase(payer.getReferredType())) {
            for (IndividualIdentification individual : payer.getIndividualIdentification()) {
                if (Constants.CUSTOMER_CODE.equalsIgnoreCase(individual.getIdentificationType())) {
                    return individual.getIdentificationId();
                }
            }
        } else {
            for (OrganizationIdentification organization : payer.getOrganizationIdentification()) {
                if (Constants.CUSTOMER_CODE.equalsIgnoreCase(organization.getIdentificationType())) {
                    return organization.getIdentificationId();
                }
            }
        }
        return null;
    }

    public static boolean isAmortization(List<Characteristic> listCharacteristic) {

        for (Characteristic characteristic : listCharacteristic) {
            if (Constants.TRANSACTION.equalsIgnoreCase(characteristic.getName())
                    && Constants.AMORTIZATION.equalsIgnoreCase(characteristic.getValue())) {
                return true;
            }
        }
        return false;
    }

    public static boolean isFutureDate(String dateString) {
        boolean isFutureDate = false;
        try {
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

            Date date = format.parse(dateString);
            Date currentDate = new Date();

            if (date.after(currentDate)) {
                isFutureDate = true;
            } else {
                isFutureDate = false;
            }

        } catch (ParseException e) {
            log.warn("Error al formatear la fecha de validez");
        }
        return isFutureDate;
    }
  
}