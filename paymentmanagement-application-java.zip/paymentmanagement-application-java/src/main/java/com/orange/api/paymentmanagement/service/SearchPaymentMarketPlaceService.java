package com.orange.api.paymentmanagement.service;

import java.util.List;

import com.orange.api.paymentmanagement.web.model.Payment;

/**
 * Service Interface for Paymentmanagement service.
 */
public interface SearchPaymentMarketPlaceService {
	
	
	/**
	 * This service get status paymentLink
	 * @param id
	 * @return
	 */
	List<Payment> searchPaymentMarketPlace(String payerReferredType, String typeDocument, String idDocument, String phoneNumber);

}