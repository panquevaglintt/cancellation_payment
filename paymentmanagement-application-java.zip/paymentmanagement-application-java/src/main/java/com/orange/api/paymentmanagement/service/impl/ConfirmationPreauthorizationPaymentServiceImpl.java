package com.orange.api.paymentmanagement.service.impl;

import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.errors.PaymentmanagementErrors;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.mappers.ConfirmationPreauthorizationPaymentMapper;
import com.orange.api.paymentmanagement.service.ConfirmationPreauthorizationPaymentService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionConfirmacionRequest;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionConfirmacionResponse;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ConfirmationPreauthorizationPaymentServiceImpl implements ConfirmationPreauthorizationPaymentService {

    private IntegrationServiceWSPspClient integrationServiceWSPspClient;

    private FixedValuesRepository fixedValuesRepository;

    private PaymentRegistryRepository paymentRegistryRepository;

    @Autowired
    public ConfirmationPreauthorizationPaymentServiceImpl(IntegrationServiceWSPspClient integrationServiceWSPspClient,
            FixedValuesRepository fixedValuesRepository, PaymentRegistryRepository paymentmanagementRepository) {
        this.integrationServiceWSPspClient = integrationServiceWSPspClient;
        this.fixedValuesRepository = fixedValuesRepository;
        this.paymentRegistryRepository = paymentmanagementRepository;
    }

    @Override
    public Payment confirmationPreauthorizationPayment(Payment payment, String numOrigin) {
        PreautorizacionConfirmacionRequest requestWS = new PreautorizacionConfirmacionRequest();

        PaymentRegistryDB paymentRegistryDB = this.paymentRegistryRepository.findByOriginOpnumber(numOrigin);
        if (ObjectUtils.isEmpty(paymentRegistryDB)) {
            log.error("No se ha encontrado ningun registro en BBDD");
            throw new OpenApiNotFoundException(PaymentmanagementErrors.ERROR_REGISTER_NOTFOUND.toString());
        }

        String transactiontype = paymentRegistryDB.getTransactiontype();
        String app = paymentRegistryDB.getChannel();

        if (!CollectionUtils.isEmpty(payment.getCharacteristic()) && !StringUtils.isEmpty(
                PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.CHANNEL))) {
            app = PaymentManagementUtils.searchValueCharacteristic(payment.getCharacteristic(), Constants.CHANNEL);
        }
        FixedValuesDB fixedValues = null;
        List<FixedValuesDB> listFixedValues = this.fixedValuesRepository.findByTransactiontypeAndApp(transactiontype,
                app);
        if (!ObjectUtils.isEmpty(listFixedValues)) {
            fixedValues = listFixedValues.get(0);
        } else {
            log.error("La transacción o zapp no coincide con lo esperado");
            throw new OpenApiBadRequestException(PaymentmanagementErrors.INVALID_APP.toString());
        }

        ConfirmationPreauthorizationPaymentMapper.mapPaymentToPreautorizacionConfirmacionRequest(payment, requestWS, paymentRegistryDB, fixedValues);

        PreautorizacionConfirmacionResponse preautorizacionConfirmacionResponse = new PreautorizacionConfirmacionResponse();
        try {
            log.info("Se va a llamar al servicio de confirmación de la preautorización al WS de PSP con la peticion: {}"
                    + requestWS.toString());
            preautorizacionConfirmacionResponse = this.integrationServiceWSPspClient.confirmationPreauthorizationPayment(requestWS);
            log.info("Respuesta del servicio de confirmacion de preautorizacion al WS de PSP: {}"
                    + preautorizacionConfirmacionResponse.toString());

            ConfirmationPreauthorizationPaymentMapper.mapPaymentRegistry(paymentRegistryDB, preautorizacionConfirmacionResponse, requestWS,
                    Constants.PREAUTH_CONFIRMED, Constants.PREAUTH_CONFIRMED_DESC);

            log.info("La llamada para confirmar la preautorización  con numero operacion origen: " + requestWS.getNumOpOrigen()
                    + "ha ido correctamente");
        } catch (Exception e) {

            if (e instanceof TimeoutException) {

                ConfirmationPreauthorizationPaymentMapper.mapPaymentRegistryError(paymentRegistryDB, requestWS,
                        Constants.PREAUTH_CONFIRMED_ERROR, Constants.PREAUTH_CONFIRMED_TIMEOUT_DESC);

                log.info("La llamada para confirmar la preautorización con numero operacion origen: " + requestWS.getNumOpOrigen()
                        + "ha fallado por Timeout");

            } else {

                ConfirmationPreauthorizationPaymentMapper.mapPaymentRegistryError(paymentRegistryDB, requestWS,
                        Constants.PREAUTH_CONFIRMED_ERROR, Constants.PREAUTH_CONFIRMED_ERROR_DESC);

                log.info("La llamada para confirmar la preautorización con numero operacion origen: " + requestWS.getNumOpOrigen()
                        + "ha fallado");
            }
        }

        this.paymentRegistryRepository.save(paymentRegistryDB);

        ConfirmationPreauthorizationPaymentMapper.mapPreautorizacionConfirmacionResponseToPayment(payment,
                preautorizacionConfirmacionResponse, numOrigin);
        
        return payment;
    }

}