package com.orange.api.paymentmanagement.web.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.orange.api.paymentmanagement.service.PaymentManagementService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.utils.TestUtils;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.openapiosp.boot.errorhandler.autoconfigure.ErrorHandlerAutoconfiguration;
import com.orange.openapiosp.boot.errorhandler.autoconfigure.OrangeErrorMessageSourceConfig;
import com.orange.openapiosp.boot.security.jwt.service.OpenApiSecurityService;
import com.orange.openapiosp.boot.security.jwt.util.JwtClaim;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = PaymentManagementApiController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
@Import({ErrorHandlerAutoconfiguration.class, OrangeErrorMessageSourceConfig.class})
class PaymentManagementControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private OpenApiSecurityService securityService;
    @MockBean
    private PaymentManagementService paymentManagementService;

    @Test
    void GIVEN_ValidEPayment_WHEN_CreatePayment_THEN_Return200() throws Exception {

        Payment validEPayment = TestUtils.createValidEPayment();
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validEPayment);

        given(securityService.getByClaimsName(JwtClaim.Z_APP)).willReturn("zApp");
        given(securityService.getByClaimsName(JwtClaim.Z_LOGIN)).willReturn("zLogin");
        given(paymentManagementService.generationPaymentLink(any(), any(), any())).willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(post("/payment")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validEPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).generationPaymentLink(paymentArgumentCaptor.capture(), any(), any());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validEPayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validEPayment));
    }

    @Test
    void GIVEN_ValidMPPayment_WHEN_CreatePayment_THEN_Return200() throws Exception {

        Payment validMPPayment = TestUtils.createValidMPPayment();
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validMPPayment);

        given(securityService.getByClaimsName(JwtClaim.Z_APP)).willReturn("zApp");
        given(securityService.getByClaimsName(JwtClaim.Z_LOGIN)).willReturn("zLogin");
        given(paymentManagementService.generationPaymentMarketPlace(any(), any(), any()))
                .willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(post("/payment")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validMPPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).generationPaymentMarketPlace(paymentArgumentCaptor.capture(), any(), any());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validMPPayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validMPPayment));

    }

    @Test
    void GIVEN_ValidIframe_WHEN_CreatePayment_THEN_Return200() throws Exception {

        Payment validIframePayment = TestUtils.createValidIframePayment();
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validIframePayment);

        given(securityService.getByClaimsName(JwtClaim.Z_APP)).willReturn("zApp");
        given(securityService.getByClaimsName(JwtClaim.Z_LOGIN)).willReturn("zLogin");
        given(paymentManagementService.generationIframe(any(), any(), any()))
                .willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(post("/payment")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validIframePayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).generationIframe(paymentArgumentCaptor.capture(), any(), any());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validIframePayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validIframePayment));

    }

    @Test
    void GIVEN_TypeMPAndMSISDN_WHEN_FindPayment_THEN_Return200() throws Exception {
        mockMvc.perform(get("/payment")
                        .param("type", "MP-Payment")
                        .param("characteristic.name", "MSISDN"))
                .andExpect(status().isOk());
        verify(paymentManagementService, times(1)).searchPaymentMarketPlace(any(), any(), any(), any());
    }

    @Test
    void GIVEN_TypeMPAndIndividual_WHEN_FindPayment_THEN_Return200() throws Exception {
        mockMvc.perform(get("/payment")
                        .param("type", "MP-Payment")
                        .param("payer.referredType", "Individual")
                        .param("payer.individualIdentification.identificationType", "NIF")
                        .param("payer.individualIdentification.identificationId", "1111"))
                .andExpect(status().isOk());
        verify(paymentManagementService, times(1)).searchPaymentMarketPlace(any(), any(), any(), any());
    }

    @Test
    void GIVEN_PaymentId_WHEN_GetPayment_THEN_Return200() throws Exception {
        mockMvc.perform(get("/payment/{id}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void GIVEN_ValidPaymentStatusCancelled_WHEN_PatchPayment_THEN_Return200() throws Exception{
        Payment validMPPayment = TestUtils.createValidMPPayment();
        validMPPayment.setStatus("Cancelled");
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validMPPayment);
        given(paymentManagementService.paymentLinkAnnulation(any(), any())).willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(patch("/payment/{id}", 1)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validMPPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).paymentLinkAnnulation(paymentArgumentCaptor.capture(), any());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validMPPayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validMPPayment));
    }

    @Test
    void GIVEN_ValidPaymentStatusReturned_WHEN_PatchPayment_THEN_Return200() throws Exception{
        Payment validMPPayment = TestUtils.createValidMPPayment();
        validMPPayment.setStatus("Returned");
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validMPPayment);
        given(paymentManagementService.paymentReturnMarketPlace(any(), any())).willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(patch("/payment/{id}", 1)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validMPPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).paymentReturnMarketPlace(paymentArgumentCaptor.capture(), any());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validMPPayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validMPPayment));
    }

    @Test
    void GIVEN_ValidPaymentWithoutStatus_WHEN_PatchPayment_THEN_Return200() throws Exception{
        Payment validMPPayment = TestUtils.createValidMPPayment();
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validMPPayment);
        given(paymentManagementService.updateStatusPayment(any(), any())).willReturn(paymentResult);

        MvcResult mvcResult = mockMvc.perform(patch("/payment/{id}", 1)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validMPPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).updateStatusPayment(any(), paymentArgumentCaptor.capture());
        assertThat(paymentArgumentCaptor.getValue().getTotalAmount().getValue()).isEqualTo(validMPPayment.getTotalAmount().getValue());

        String actualResponseBody = mvcResult.getResponse().getContentAsString();
        assertThat(actualResponseBody).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(validMPPayment));
    }

    @Test
    void GIVEN_ValidPayment_WHEN_PatchPayment_Type_Cancellation_THEN_Return200() throws Exception {
        Payment validMPPayment = TestUtils.createValidMPPayment();
        validMPPayment.setType(Constants.PAYMENT_LINK_TYPE_CANCELLATION);
        ResponseEntity<Payment> paymentResult = ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(validMPPayment);
        given(paymentManagementService.paymentLinkCancellation(any(), any(),any())).willReturn(paymentResult);
        String id = "A20241204153033234954";
        MvcResult mvcResult = mockMvc.perform(patch("/payment/{id}", id)
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(validMPPayment)))
                .andExpect(status().isOk())
                .andReturn();

        ArgumentCaptor<Payment> paymentArgumentCaptor = ArgumentCaptor.forClass(Payment.class);
        verify(paymentManagementService, times(1)).paymentLinkCancellation(paymentArgumentCaptor.capture(), any(),any());
        assertThat(paymentArgumentCaptor.getValue().getId()).isEqualTo(id);
    }
}