package com.orange.api.paymentmanagement.service.impl;

import static org.mockito.Mockito.doNothing;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.repository.PaymentHistoricalRegistryRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.service.CleanDBService;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class CleanDbTest {

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;
    @Mock
    private PaymentHistoricalRegistryRepository paymentHistoricalRegistryRepository;

    @InjectMocks()
    private CleanDBService service = new CleanDBServiceImpl(paymentRegistryRepository,
            paymentHistoricalRegistryRepository);

    /**
     * This test checks the cleanDb service.
     */
    @Test
    public void cleanDb_OK() {

        doNothing().when(paymentRegistryRepository).paymentRegistryPurge();
        doNothing().when(paymentHistoricalRegistryRepository).paymentHistoricalRegistryPurge();
        service.cleanDb();
    }

}