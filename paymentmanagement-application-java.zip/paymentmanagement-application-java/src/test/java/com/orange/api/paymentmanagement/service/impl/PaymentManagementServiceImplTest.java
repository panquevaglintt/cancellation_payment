package com.orange.api.paymentmanagement.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.service.GenerationIframeService;
import com.orange.api.paymentmanagement.service.GenerationPaymentLinkService;
import com.orange.api.paymentmanagement.service.GenerationPaymentMarketPlaceService;
import com.orange.api.paymentmanagement.service.GenerationScheduledIframeService;
import com.orange.api.paymentmanagement.service.GenerationTokenPaymentService;
import com.orange.api.paymentmanagement.service.PaymentLinkAnnulationService;
import com.orange.api.paymentmanagement.service.PaymentReportService;
import com.orange.api.paymentmanagement.service.PaymentReturnedMarketPlaceService;
import com.orange.api.paymentmanagement.service.SearchPaymentMarketPlaceService;
import com.orange.api.paymentmanagement.service.StatusPaymentLinkService;
import com.orange.api.paymentmanagement.service.TransferFileService;
import com.orange.api.paymentmanagement.service.UpdateStatusPaymentService;
import com.orange.api.paymentmanagement.web.model.Payment;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class PaymentManagementServiceImplTest {

    @Mock
    private PaymentLinkAnnulationService paymentLinkAnnulationService;
    @Mock
    private StatusPaymentLinkService statusPaymentManagementService;
    @Mock
    private GenerationPaymentLinkService generationPaymentManagementService;
    @Mock
    private UpdateStatusPaymentService updateStatusPaymentService;
    @Mock
    private GenerationIframeService generationIframeService;
    @Mock
    private GenerationPaymentMarketPlaceService generationPaymentManagementMarketPlaceService;
    @Mock
    private SearchPaymentMarketPlaceService searchPaymentManagementMarketPlaceService;
    @Mock
    private PaymentReturnedMarketPlaceService paymentReturnedMarketPlaceService;
    @Mock
    private PaymentReportService paymentReportService;
    @Mock
    private TransferFileService transferFileService;
    @Mock
    private GenerationScheduledIframeService generationScheduledIframeService;
    @Mock
    private GenerationTokenPaymentService generationTokenPaymentService;

    @InjectMocks
    private PaymentManagementServiceImpl paymentTestManagementService;

    @Test
    public void paymentLinkAnnulationTest_OK() {

        Mockito.when(paymentLinkAnnulationService.paymentLinkAnnulation(Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.paymentLinkAnnulation(new Payment(),
                "numOrigin");

        assertNotNull(response);
    }

    @Test
    public void generationPaymentLinkTest_OK() {

        Mockito.when(
                generationPaymentManagementService.generationPaymentLink(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.generationPaymentLink(new Payment(), "zApp",
                "zLogin");

        assertNotNull(response);
    }

    @Test
    public void statusPaymentLinkTest_OK() {

        Mockito.when(statusPaymentManagementService.statusPaymentLink(Mockito.any(),Mockito.any())).thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.statusPaymentLink("id","E-Payment");

        assertNotNull(response);
    }

    @Test
    public void updateStatusPaymentTest_OK() {

        Mockito.when(updateStatusPaymentService.updateStatusPayment(Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.updateStatusPayment("id", new Payment());

        assertNotNull(response);
    }

    @Test
    public void generationIframeTest_OK() {

        Mockito.when(generationIframeService.generationIframe(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.generationIframe(new Payment(), "zApp",
                "zLogin");

        assertNotNull(response);
    }
    
    @Test
    public void generationPaymentMarketPlaceTest_OK() {

        Mockito.when(
        		generationPaymentManagementMarketPlaceService.generationPaymentMarketPlace(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.generationPaymentMarketPlace(new Payment(), "zApp",
                "zLogin");

        assertNotNull(response);
    }
    
    @Test
    public void searchPaymentMarketPlaceTest_OK() {

        Mockito.when(
        		searchPaymentManagementMarketPlaceService.searchPaymentMarketPlace(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ArrayList<Payment>());
        ResponseEntity<List<Payment>> response = paymentTestManagementService.searchPaymentMarketPlace("payerReferredType", "typeDocument", "idDocument", "phoneNumber");

        assertNotNull(response);
    }
    
    @Test
    public void paymentReturnedMarketPlaceTest_OK() {

        Mockito.when(paymentReturnedMarketPlaceService.paymentReturnMarketPlace(Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.paymentReturnMarketPlace(new Payment(),
                "numOrigin");

        assertNotNull(response);
    }
    
    @Test
    public void generationScheduledIframeServiceTest_OK() {

        Mockito.when(generationScheduledIframeService.generationScheduledIframe(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any()))
                .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.generationScheduledIframe(new Payment(),
                "zApp", "zLogin", "zCallerIp");

        assertNotNull(response);
    }
    
    @Test
    public void transferFileServiceTest_OK() {

        Mockito.when(transferFileService.paymentProcessingFile(Mockito.any(),Mockito.any(),Mockito.any()))
                .thenReturn(new Payment());
        Mockito.when(transferFileService.paymentValidatingFile(Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(new Payment());
        
        ResponseEntity<Payment> response1 = paymentTestManagementService.generationProccesingFile(new Payment(),
                "zApp", "Bearer 124143");
        ResponseEntity<Payment> response2 = paymentTestManagementService.generationValidatingFile(new Payment(),
                "zApp", "Bearer 124143");

        assertNotNull(response1);
        assertNotNull(response2);
    }
    
	@Test
	public void paymentRequesCsvGenerateTest() throws Exception {

		byte[] csvFile = new byte[1];

		Mockito.when(paymentReportService.paymentReportCsvGenerate(Mockito.any(), Mockito.any())).thenReturn(csvFile);

		ResponseEntity<byte[]> request = paymentTestManagementService.paymentReportCsvGenerate("654321987", "1231");

		assertEquals(HttpStatus.OK, request.getStatusCode());

	}
	
    @Test
    public void generationTokenPayment_OK() {
        
        Mockito.when(generationTokenPaymentService.generationTokenPayment(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(new Payment());
        ResponseEntity<Payment> response = paymentTestManagementService.generationTokenPayment(new Payment(), "zApp",
                "zLogin", "zCallerIp");
        
        assertNotNull(response);
    }

}