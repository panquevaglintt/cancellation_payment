package com.orange.api.paymentmanagement.service.impl;

import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;

@SpringBootTest
@RunWith(SpringRunner.class)
@EnableFeignClients
public class PaymentReportServiceImplTest {

    @Mock
    PaymentRegistryRepository paymentRegistryRepository;

    @InjectMocks
    private PaymentReportServiceImpl paymentReportService = new PaymentReportServiceImpl(paymentRegistryRepository);

    @Test()
    public void fraudRequesCsvGenerateEmptyTestOK() throws Exception {

        List<PaymentRegistryDB> db = new ArrayList();

        Mockito.when(paymentRegistryRepository.findByCreationDate(Mockito.any(), Mockito.any())).thenReturn(db);

        byte[] request = paymentReportService.paymentReportCsvGenerate("654321987", "1231");

        assertTrue(request.length > 0);
    }

    @Test()
    public void fraudRequesCsvGenerateTestOK() throws Exception {

        byte[] csvFile = new byte[1];
        Timestamp date = new Timestamp(10);
        PaymentRegistryDB db = new PaymentRegistryDB();
        Timestamp time = new Timestamp(0);
        time.getDate();

        db.setOriginOpnumber("12");
        db.setAnnulationDate(time);
        db.setCommercialCode("12");
        db.setAmount("12");
        db.setStatus("12");
        db.setTransactiontype("12");
        db.setToken("12");
        db.setLinkExpiration(time);
        db.setPhonenumber("12");
        db.setIdDocument("12");
        db.setAnnulationOpnumber("12");
        db.setAnnulationDate(time);
        db.setAnnulationResult("12");
        db.setVapId("12");

        List<PaymentRegistryDB> listdb = new ArrayList();
        listdb.add(db);

        Mockito.when(paymentRegistryRepository.findByCreationDate(Mockito.any(), Mockito.any())).thenReturn(listdb);

        byte[] request = paymentReportService.paymentReportCsvGenerate("654321987", "1231");

    }
}