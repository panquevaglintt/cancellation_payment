package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.service.GenerationTokenPaymentService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentMethodRefOrValue;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosTarjetaRespuesta;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseTokenPayment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.ExternalIdentifier;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.RelatedParty;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class GenerationTokenPaymentServiceImplTest {
    
    @Mock
    private FixedValuesRepository fixedValuesRepository;
    
    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;
    
    @Mock
    private PaymentMethodManagementClient paymentmethodmanagement;
    
    @Mock
    private IntegrationServiceWSPspClient integrationServiceWSPspClient;
    
    @InjectMocks()
    private GenerationTokenPaymentService service = new GenerationTokenPaymentServiceImpl(fixedValuesRepository, paymentRegistryRepository, 
            paymentmethodmanagement, integrationServiceWSPspClient);
    
    @Test
    public void generationTokenPayment_IndividualIdentification_TestOK() {
        
        PaymentMethod responseGet = new PaymentMethod();
        responseGet.setExpirationDate("2412");
        List<ExternalIdentifier> externalIdentifierList = new ArrayList<>();
        ExternalIdentifier externalIdentifier = new ExternalIdentifier();
        externalIdentifier.setType(Constants.ID_COF);
        externalIdentifierList.add(externalIdentifier);
        responseGet.setExternalIdentifier(externalIdentifierList);
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.RelatedParty relatedParty = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.RelatedParty();
        relatedParty.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification individualIdentification = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.IndividualIdentification();
        individualIdentification.setIdentificationType("DNI");
        individualIdentification.setIdentificationId("IdentificationId");
        List<IndividualIdentification> individualIdentificationList= new ArrayList();
        individualIdentificationList.add(individualIdentification);
        relatedParty.setIndividualIdentification(individualIdentificationList);
        responseGet.setRelatedParty(relatedParty);
        Mockito.when(this.paymentmethodmanagement.getPaymentMethod(Mockito.any(),Mockito.any())).thenReturn(responseGet);

        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
        paymentRegistryDB.setToken("123456789");
        paymentRegistryDB.setProcessflowId("ProcessFlowId");
        paymentRegistryDB.setCustCode("CustCode");
        Mockito.when(this.paymentRegistryRepository.findByPaymentMethodId(Mockito.any())).thenReturn(paymentRegistryDB);
        
        List<FixedValuesDB> listFixedValues = new ArrayList<>();
        FixedValuesDB fixedValues = new FixedValuesDB();
        fixedValues.setCurrency("Currency");
        listFixedValues.add(fixedValues);
        Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(listFixedValues);
        
        ResponseTokenPayment responseReturned = new ResponseTokenPayment();
        responseReturned.setNumOpOrigen("NumOpOrigen");
        ResultadoOperacion resultadoOperacion = new ResultadoOperacion();
        resultadoOperacion.setCodigo("OK");
        responseReturned.setResultadoOperacion(resultadoOperacion);
        responseReturned.setFechaOpOrigen("2023-10-05T14:30:00Z");
        DatosTarjetaRespuesta datosTarjeta = new DatosTarjetaRespuesta();
        datosTarjeta.setMascara("1234********45613");
        responseReturned.setDatosTarjeta(null);
        Mockito.when(this.integrationServiceWSPspClient.tokenPayment(Mockito.any())).thenReturn(responseReturned);
        
        Payment payment = new Payment();
        payment.setType(Constants.TOKEN_PAYMENT);
        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
        paymentMethod.setId("12345");
        payment.setPaymentMethod(paymentMethod);
        Money totalAmount = new Money();
        totalAmount.setUnit("EUR");
        totalAmount.setValue((float) 50);
        payment.setTotalAmount(totalAmount);
        List<Characteristic> characteristicList = new ArrayList<>();
        
        Characteristic characteristic = null;
        characteristic = new Characteristic();
        characteristic.setName(Constants.PHONENUMBER);
        characteristic.setValue("123456");
        characteristicList.add(characteristic);
        
        characteristic = new Characteristic();
        characteristic.setName(Constants.TRANSACTION);
        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
        characteristicList.add(characteristic);
        
        characteristic = new Characteristic();
        characteristic.setName(Constants.PROCESSFLOW_ID);
        characteristic.setValue("Prueba");
        characteristicList.add(characteristic);
        
        payment.setCharacteristic(characteristicList);
        
        payment = service.generationTokenPayment(payment, "zApp", "zLogin", "zCallerIp");
        
    }
    
    @Test
    public void generationTokenPayment_OrganizationIdentification_TestOK() {
        
        PaymentMethod responseGet = new PaymentMethod();
        responseGet.setExpirationDate("2412");
        List<ExternalIdentifier> externalIdentifierList = new ArrayList<>();
        ExternalIdentifier externalIdentifier = new ExternalIdentifier();
        externalIdentifier.setType(Constants.ID_COF);
        externalIdentifierList.add(externalIdentifier);
        responseGet.setExternalIdentifier(externalIdentifierList);
        RelatedParty relatedParty = new RelatedParty();
        relatedParty.setReferredType(Constants.REFERRED_TYPE_ORGANIZATION);
        com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification organizationIdentification = new com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification();
        organizationIdentification.setIdentificationType("DNI");
        organizationIdentification.setIdentificationId("IdentificationId");
        List<com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.OrganizationIdentification> organizationIdentificationList = new ArrayList();
        organizationIdentificationList.add(organizationIdentification);
        relatedParty.setOrganizationIdentification(organizationIdentificationList);
        responseGet.setRelatedParty(relatedParty);
        Mockito.when(this.paymentmethodmanagement.getPaymentMethod(Mockito.any(),Mockito.any())).thenReturn(responseGet);
        
        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
        paymentRegistryDB.setToken("123456789");
        paymentRegistryDB.setProcessflowId("ProcessFlowId");
        paymentRegistryDB.setCustCode("CustCode");
        Mockito.when(this.paymentRegistryRepository.findByPaymentMethodId(Mockito.any())).thenReturn(paymentRegistryDB);
        
        List<FixedValuesDB> listFixedValues = new ArrayList<>();
        FixedValuesDB fixedValues = new FixedValuesDB();
        fixedValues.setCurrency("Currency");
        listFixedValues.add(fixedValues);
        Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(listFixedValues);
        
        ResponseTokenPayment responseReturned = new ResponseTokenPayment();
        responseReturned.setNumOpOrigen("NumOpOrigen");
        ResultadoOperacion resultadoOperacion = new ResultadoOperacion();
        resultadoOperacion.setCodigo("OK");
        responseReturned.setResultadoOperacion(resultadoOperacion);
        responseReturned.setFechaOpOrigen("2023-10-05T14:30:00Z");
        DatosTarjetaRespuesta datosTarjeta = new DatosTarjetaRespuesta();
        datosTarjeta.setMascara("1234********45613");
        responseReturned.setDatosTarjeta(null);
        Mockito.when(this.integrationServiceWSPspClient.tokenPayment(Mockito.any())).thenReturn(responseReturned);
        
        Payment payment = new Payment();
        payment.setType(Constants.TOKEN_PAYMENT);
        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
        paymentMethod.setId("12345");
        payment.setPaymentMethod(paymentMethod);
        Money totalAmount = new Money();
        totalAmount.setUnit("EUR");
        totalAmount.setValue((float) 50);
        payment.setTotalAmount(totalAmount);
        List<Characteristic> characteristicList = new ArrayList<>();
        
        Characteristic characteristic = null;
        characteristic = new Characteristic();
        characteristic.setName(Constants.PHONENUMBER);
        characteristic.setValue("123456");
        characteristicList.add(characteristic);
        
        characteristic = new Characteristic();
        characteristic.setName(Constants.TRANSACTION);
        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
        characteristicList.add(characteristic);
        
        characteristic = new Characteristic();
        characteristic.setName(Constants.PROCESSFLOW_ID);
        characteristic.setValue("Prueba");
        characteristicList.add(characteristic);
        
        payment.setCharacteristic(characteristicList);
        
        payment = service.generationTokenPayment(payment, "zApp", "zLogin", "zCallerIp");
        
    }
    
}
