package com.orange.api.paymentmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.service.CancellationPreauthorizationPaymentService;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionCancelacionResponse;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext
public class CancellationPreauthorizationPaymentServiceImplTest {

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;

    @Mock
    private FixedValuesRepository fixedValuesRepository;

    @Mock
    private IntegrationServiceWSPspClient integrationServiceWSPspClient;
    
    ObjectMapper objectMapper;
    
    @InjectMocks()
    private CancellationPreauthorizationPaymentService cancellationPreauthorizationPaymentService = new CancellationPreauthorizationPaymentServiceImpl(integrationServiceWSPspClient,fixedValuesRepository,paymentRegistryRepository);


    @Test
    public void testCancellationPreauthorizationPayment_success() throws StreamReadException, DatabindException, IOException {
        // Arrange
        PaymentRegistryDB paymentRegistry = createPaymentRegistry();

        List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
        FixedValuesDB fixedValuesCancellation = createFixedValues();
        listFixedValues.add(fixedValuesCancellation);
        
        PreautorizacionCancelacionResponse response = createPreautorizacionCancellationResponse();
        
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.registerModule(new JavaTimeModule());

        File file = new File("mocks/examples/CancellationPLRequest.json");
        Payment payment = objectMapper.readValue(file, Payment.class);

        Mockito.when(paymentRegistryRepository.findByOriginOpnumber(Mockito.any()))
                .thenReturn(paymentRegistry);
        Mockito.when(fixedValuesRepository.findByTransactiontypeAndApp(Mockito.any(),Mockito.any()))
                .thenReturn(listFixedValues);
        Mockito.when(integrationServiceWSPspClient.cancelationPreauthorizationPayment(Mockito.any()))
                .thenReturn(response);

        // Act
        Payment result = cancellationPreauthorizationPaymentService.cancellationPreauthorizationPayment(payment, paymentRegistry.getOriginOpnumber());

        // Assert
        Assert.assertNotNull(result);
        Assert.assertEquals(paymentRegistry.getOriginOpnumber(), result.getId());
        Mockito.verify(paymentRegistryRepository).save(Mockito.any(PaymentRegistryDB.class));
        Mockito.verify(integrationServiceWSPspClient).cancelationPreauthorizationPayment(Mockito.any());
    }

    @Test
    public void testCancellationPreauthorizationPayment_notFound() {
        // Arrange
        String numOrigin = "12345";
        Payment payment = new Payment();

        Mockito.when(paymentRegistryRepository.findByOriginOpnumber(numOrigin))
                .thenReturn(null);

        // Act & Assert
        OpenApiNotFoundException exception = assertThrows(OpenApiNotFoundException.class, () -> 
        cancellationPreauthorizationPaymentService.cancellationPreauthorizationPayment(payment, numOrigin));
        assertEquals("Register not found.", exception.getDescription());
    }

    @Test
    public void testCancellationPreauthorizationPayment_invalidApp() {
        // Arrange
        String numOrigin = "12345";
        Payment payment = new Payment();

        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
        paymentRegistryDB.setTransactiontype("PREAUTH");
        paymentRegistryDB.setChannel("INVALID_APP");

        Mockito.when(paymentRegistryRepository.findByOriginOpnumber(Mockito.any()))
                .thenReturn(paymentRegistryDB);
        Mockito.when(fixedValuesRepository.findByTransactiontypeAndApp(Mockito.any(), Mockito.any()))
                .thenReturn(Collections.emptyList());

        // Act & Assert
        OpenApiBadRequestException exception = assertThrows(OpenApiBadRequestException.class, () -> 
        cancellationPreauthorizationPaymentService.cancellationPreauthorizationPayment(payment, numOrigin));
        assertEquals("The app param is not valid.", exception.getDescription());
    }
    
    private PreautorizacionCancelacionResponse createPreautorizacionCancellationResponse() {
        PreautorizacionCancelacionResponse pcResponse = new PreautorizacionCancelacionResponse();

        // Fill the fields with sample values
        pcResponse.setDatosTarjeta(new Object()); // Replace with actual card
                                                  // data object if available
        pcResponse.setImporte(1500L); // Example amount
        pcResponse.setMoneda("USD"); // Currency
        pcResponse.setDatosResolutor(new Object()); // Replace with actual
                                                    // resolver data object if
                                                    // available
        pcResponse.setNumAutorizacion("AUTH123456"); // Authorization number
        pcResponse.setNumOperacionNNP(987654321); // Example operation number

        // Example for ParametrosAdicionales object
        ParametrosAdicionales parametrosAdicionales = new ParametrosAdicionales();
        pcResponse.setParametrosAdicionales(parametrosAdicionales);

        // Example for ResultadoOperacion object
        ResultadoOperacion resultadoOperacion = new ResultadoOperacion();
        resultadoOperacion.setCodigo("00"); // Success code
        resultadoOperacion.setMensaje("Operation completed successfully.");
        pcResponse.setResultadoOperacion(resultadoOperacion);

        // Example for DatosCliente object
        DatosCliente datosCliente = new DatosCliente();
        datosCliente.setCoCliente("AAAAA"); // Replace with actual fields
        datosCliente.setCoComercio("00000");
        datosCliente.setCoTerminal("111111");
        datosCliente.setPalabraClave("keyword");
        pcResponse.setDatosCliente(datosCliente);

        pcResponse.setFechaOpOrigen("2024-11-26T12:34:56Z"); // ISO 8601 format
        pcResponse.setIdioma("EN"); // Language
        pcResponse.setNumOpOrigen("1234567890"); // Example origin operation
                                                 // number
        pcResponse.setUsuario("user123"); // Example username

        return pcResponse;
    }

    private FixedValuesDB createFixedValues() {
        FixedValuesDB fixedValuesCancellation = new FixedValuesDB();

        // Populating fields
        fixedValuesCancellation.setId(1L);
        fixedValuesCancellation.setCreationDate(new Timestamp(System.currentTimeMillis()));
        fixedValuesCancellation.setUpdateDate(new Timestamp(System.currentTimeMillis()));
        fixedValuesCancellation.setClientCode("CLIENT123");
        fixedValuesCancellation.setTransactiontype("TRANSACTION_TYPE");
        fixedValuesCancellation.setApp("APP_NAME");
        fixedValuesCancellation.setCommercialCode("COMMERCIAL123");
        fixedValuesCancellation.setTerminalCode("TERMINAL123");
        fixedValuesCancellation.setKeyword("KEYWORD");
        fixedValuesCancellation.setLanguage("en");
        fixedValuesCancellation.setCoTipoOpLink("OPLINK_TYPE");
        fixedValuesCancellation.setUrlLogo("https://example.com/logo.png");
        fixedValuesCancellation.setColor("#FFFFFF");
        fixedValuesCancellation.setText("Some Text");
        fixedValuesCancellation.setTextcvv("CVV Text");
        fixedValuesCancellation.setTextButton("Pay Now");
        fixedValuesCancellation.setTextFxExpiration("MM/YY");
        fixedValuesCancellation.setTextCard("Card Number");
        fixedValuesCancellation.setTextTitle("Payment Title");
        fixedValuesCancellation.setTextMask("**** **** **** ****");
        fixedValuesCancellation.setCardType("VISA");
        fixedValuesCancellation.setCurrency("USD");
        fixedValuesCancellation.setSeed("SEED123");
        fixedValuesCancellation.setFormButton("Submit");
        fixedValuesCancellation.setTemplate("DEFAULT_TEMPLATE");
        fixedValuesCancellation.setPaymentRetries("3");
        fixedValuesCancellation.setValidityTime("60");
        fixedValuesCancellation.setTarget("_blank");
        fixedValuesCancellation.setUrlCss("https://example.com/styles.css");
        fixedValuesCancellation.setTypelink("LINK_TYPE");
        fixedValuesCancellation.setPaymentMethod("CREDIT_CARD");
        return fixedValuesCancellation;
    }
    
    private PaymentRegistryDB createPaymentRegistry() {
        PaymentRegistryDB paymentRegistryConfirmationDB = new PaymentRegistryDB();

     // Timestamps
     paymentRegistryConfirmationDB.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setUpdateDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setAnnulationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setConfirmationOriginOpdate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setLinkExpiration(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setLinkRegistration(Timestamp.valueOf(LocalDateTime.now()));

     // Basic details
     paymentRegistryConfirmationDB.setClientCode("12345");
     paymentRegistryConfirmationDB.setCommercialCode("COMM123");
     paymentRegistryConfirmationDB.setTerminalCode("TERM001");
     paymentRegistryConfirmationDB.setLanguage("EN");
     paymentRegistryConfirmationDB.setAmount("100.00");
     paymentRegistryConfirmationDB.setCurrency("USD");
     paymentRegistryConfirmationDB.setStatus("Scheduled");
     paymentRegistryConfirmationDB.setStatusDescription("Payment scheduled successfully");

     // Identifiers
     paymentRegistryConfirmationDB.setOriginOpnumber("OP123456");
     paymentRegistryConfirmationDB.setPhonenumber("1234567890");
     paymentRegistryConfirmationDB.setIdDocument("ID987654");
     paymentRegistryConfirmationDB.setTypeDocument("Passport");
     paymentRegistryConfirmationDB.setType("Individual");
     paymentRegistryConfirmationDB.setTransactiontype("scheduled_top_up");
     paymentRegistryConfirmationDB.setBscsIdentifier("BSCS12345");
     paymentRegistryConfirmationDB.setVapId("VAP56789");
     paymentRegistryConfirmationDB.setProcessflowId("PF123456");
     paymentRegistryConfirmationDB.setUserId("User001");
     paymentRegistryConfirmationDB.setLinkCode("LINK123");
     paymentRegistryConfirmationDB.setLinkId("LINKID56789");
     paymentRegistryConfirmationDB.setSessionId("SESSION12345");
     paymentRegistryConfirmationDB.setPaymentId("PAYID987654");
     paymentRegistryConfirmationDB.setMarketplaceOrderId("MARKET123");

     // Links and URL details
     paymentRegistryConfirmationDB.setLink("http://example.com/payment-link");
     paymentRegistryConfirmationDB.setPaymentLink("http://example.com/payment-details");
     paymentRegistryConfirmationDB.setUrlOk("http://example.com/success");
     paymentRegistryConfirmationDB.setUrlKo("http://example.com/failure");
     paymentRegistryConfirmationDB.setUrlIframe("http://example.com/iframe");
     paymentRegistryConfirmationDB.setHash("HASHVALUE12345");

     // Payment details
     paymentRegistryConfirmationDB.setPaymentFlow("IFRAME");
     paymentRegistryConfirmationDB.setPaymentAttempts("3");
     paymentRegistryConfirmationDB.setPaymentResult("Success");
     paymentRegistryConfirmationDB.setResultDescription("Payment processed successfully");
     paymentRegistryConfirmationDB.setPaymentUpdate("2023-01-01 12:00:00");
     paymentRegistryConfirmationDB.setPaymentMethod("Credit Card");
     paymentRegistryConfirmationDB.setPaymentMethodId("METHOD001");

     // Card and banking details
     paymentRegistryConfirmationDB.setBankNumber("BANK12345");
     paymentRegistryConfirmationDB.setCardNumber("4111111111111111");
     paymentRegistryConfirmationDB.setToken("TOKEN123456");

     // Annulation details
     paymentRegistryConfirmationDB.setAnnulationOpnumber("ANN123456");
     paymentRegistryConfirmationDB.setAnnulationId("ANNID123");
     paymentRegistryConfirmationDB.setAnnulationResult("Success");
     paymentRegistryConfirmationDB.setAnnulationDescription("Annulation processed successfully");

     // Session details
     paymentRegistryConfirmationDB.setSessionDate("2023-01-01 12:00:00");

     // Miscellaneous
     paymentRegistryConfirmationDB.setAuthorizationNumber("AUTH12345");
     paymentRegistryConfirmationDB.setChannel("WEB");
     paymentRegistryConfirmationDB.setCustCode("CUST001");
     paymentRegistryConfirmationDB.setOperationType("Online");
     paymentRegistryConfirmationDB.setConfirmationOriginOpnumber("CONFOP12345");

     return paymentRegistryConfirmationDB;
    }
}

