package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.service.GenerationPreauthorizationPaymentLinkService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.EntityRef;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseGeneration;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class GenerationPreauthorizationPaymentLinkServiceImplTest {

	@Mock
	private IntegrationServiceWSPspClient integrationServiceWSPspClient;

	@Mock
	private FixedValuesRepository fixedValuesRepository;
    
	@Mock
	private PaymentRegistryRepository paymentRegistryRepository;
	
	@InjectMocks()
	private GenerationPreauthorizationPaymentLinkService service = new GenerationPreauthorizationPaymentLinkServiceImpl(integrationServiceWSPspClient,fixedValuesRepository,paymentRegistryRepository);

	@Test(expected = OpenApiBadRequestException.class)
	public void GenerationPaymentLink_TestKO_fixedValues() {
		Payment payment = createPayment();		
		service.generationPreauthorizationPaymentLink(payment, "fichadecliente", "zlogin", "aaa");
	}
	
	@Test
	public void GenerationPaymentLink_TestOK() {
		Payment payment = createPayment();
		List<FixedValuesDB> listFixedValues = createFixedValues();
		Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(Mockito.anyString(),
				Mockito.anyString(),Mockito.anyString())).thenReturn(listFixedValues);
		
		ResponseGeneration responseGeneration = createResponseGeneration();
		Mockito.when(this.integrationServiceWSPspClient.paymentLinkGeneration(Mockito.any())).thenReturn(responseGeneration);

		service.generationPreauthorizationPaymentLink(payment, "fichadecliente", "zlogin", "aaa");
	}
	
	private ResponseGeneration createResponseGeneration() {
		ResponseGeneration responseGeneration = new ResponseGeneration();
		responseGeneration.setFxAltaLink("2022-12-05T13:18:30.572+02:00");
		return responseGeneration;
	}

	private List<FixedValuesDB> createFixedValues() {
		List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
		FixedValuesDB fixedValues = new FixedValuesDB();
		fixedValues.setUrlCss("##CSS##");
		fixedValues.setPaymentRetries("3");
		fixedValues.setValidityTime("6");
		listFixedValues.add(fixedValues);
		return listFixedValues;
	}

	private Payment createPayment() {
		Payment payment = new Payment();
		
		payment.setTotalAmount(createTotalAmount());
		payment.setPaymentItem(createPaymentItem());
		payment.setCharacteristic(createCharacteristic());
		payment.setPayer(createPayer());
		payment.setAccount(createAccount());
		
		return payment;
	}

	private AccountRef createAccount() {
		AccountRef account = new AccountRef();
		
		account.setId("idAccount");
		
		return account;
	}

	private RelatedParty createPayer() {
		RelatedParty payer = new RelatedParty();
		payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
		payer.setRole(Constants.CLIENT);
		payer.setIndividualIdentification(createIndividual());
		return payer;
	}

	private List<IndividualIdentification> createIndividual() {
		List<IndividualIdentification> listIndividual = new ArrayList<IndividualIdentification>();
		
		IndividualIdentification individual = new IndividualIdentification();
		individual.setIdentificationId("id");
		individual.setIdentificationType("NIF");
		listIndividual.add(individual);
		
		individual = new IndividualIdentification();
		individual.setIdentificationId("customerCode");
		individual.setIdentificationType(Constants.CUSTOMER_CODE);
		listIndividual.add(individual);
		
		return listIndividual;
	}

	private List<Characteristic> createCharacteristic() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("recovery");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_OK);
		characteristic.setValue("redirectionOK");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_KO);
		characteristic.setValue("redirectionKO");
		listCharacteristic.add(characteristic);
		
		
		
		return listCharacteristic;
	}

	private List<PaymentItem> createPaymentItem() {
		List<PaymentItem> listPaymentItem = new ArrayList<PaymentItem>();
		PaymentItem paymentItem = new PaymentItem();
		EntityRef item = new EntityRef();
		item.setId("id_del_vap");
		item.setRole(Constants.VAP);
		item.setCharacteristic(createCharacteristicEntityRef());
		paymentItem.setItem(item);
		listPaymentItem.add(paymentItem);
		return listPaymentItem;
	}

	private List<Characteristic> createCharacteristicEntityRef() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.BSCSCODE);
		characteristic.setValue("codigo_bscs");
		listCharacteristic.add(characteristic);
		return listCharacteristic;
	}

	private Money createTotalAmount() {
		Money money = new Money();
		money.setUnit(Constants.EUR);
		money.setValue(10f);
		return money;
	}
}