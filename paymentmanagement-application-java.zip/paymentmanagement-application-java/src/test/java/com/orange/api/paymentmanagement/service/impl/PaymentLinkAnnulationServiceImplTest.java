package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.service.PaymentLinkAnnulationService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.EntityRef;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseAnnulationAndReturned;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class PaymentLinkAnnulationServiceImplTest {

    @Mock
    private IntegrationServiceWSPspClient integrationServiceWSPspClient;

    @Mock
    private FixedValuesRepository fixedValuesRepository;

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;

    @InjectMocks()
    private PaymentLinkAnnulationService service = new PaymentLinkAnnulationServiceImpl(
            integrationServiceWSPspClient, fixedValuesRepository, paymentRegistryRepository);

    @Test(expected = OpenApiBadRequestException.class)
    public void PaymentLinkAnnulation_TestKO_fixedValues() {
        Payment payment = createPayment();
        PaymentRegistryDB paymentRegistry = createPaymentRegistry();
        Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString()))
                .thenReturn(paymentRegistry);

        service.paymentLinkAnnulation(payment, "numOrigen");
    }

    @Test
    public void PaymentLinkAnnulation_TestOK() {
        Payment payment = createPayment();
        List<FixedValuesDB> listFixedValues = createFixedValues();
        Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndApp(Mockito.any(), Mockito.any()))
                .thenReturn(listFixedValues);

        PaymentRegistryDB paymentRegistry = createPaymentRegistry();
        Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString()))
                .thenReturn(paymentRegistry);

        ResponseAnnulationAndReturned responseAnnulationAndReturned = createResponseAnnulation();
        Mockito.when(this.integrationServiceWSPspClient.paymentLinkAnnulation(Mockito.any()))
                .thenReturn(responseAnnulationAndReturned);

        service.paymentLinkAnnulation(payment, "numOrigen");
    }

    @Test(expected = Exception.class)
    public void PaymentLinkAnnulation_TestKO() throws Exception {
        Payment payment = createPayment();
        List<FixedValuesDB> listFixedValues = createFixedValues();
        Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndApp(Mockito.any(), Mockito.any()))
                .thenReturn(listFixedValues);

        PaymentRegistryDB paymentRegistry = createPaymentRegistry();
        Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString()))
                .thenReturn(paymentRegistry);

        Mockito.when(integrationServiceWSPspClient.paymentLinkAnnulation(Mockito.any())).thenThrow(new Exception());

        service.paymentLinkAnnulation(payment, "numOrigen");
    }

    private PaymentRegistryDB createPaymentRegistry() {
        PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();

        return paymentRegistry;
    }

    private ResponseAnnulationAndReturned createResponseAnnulation() {
        ResponseAnnulationAndReturned responseAnnulationAndReturned = new ResponseAnnulationAndReturned();
        responseAnnulationAndReturned.setResultadoOperacion(new ResultadoOperacion());
        return responseAnnulationAndReturned;
    }

    private List<FixedValuesDB> createFixedValues() {
        List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
        FixedValuesDB fixedValues = new FixedValuesDB();
        fixedValues.setUrlCss("##CSS##");
        fixedValues.setPaymentRetries("3");
        fixedValues.setValidityTime("3");
        listFixedValues.add(fixedValues);
        return listFixedValues;
    }

    private Payment createPayment() {
        Payment payment = new Payment();

        payment.setTotalAmount(createTotalAmount());
        payment.setPaymentItem(createPaymentItem());
        payment.setCharacteristic(createCharacteristic());
        payment.setPayer(createPayer());
        payment.setAccount(createAccount());

        return payment;
    }

    private AccountRef createAccount() {
        AccountRef account = new AccountRef();

        account.setId("idAccount");

        return account;
    }

    private RelatedParty createPayer() {
        RelatedParty payer = new RelatedParty();
        payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
        payer.setRole(Constants.CLIENT);
        payer.setIndividualIdentification(createIndividual());
        return payer;
    }

    private List<IndividualIdentification> createIndividual() {
        List<IndividualIdentification> listIndividual = new ArrayList<IndividualIdentification>();

        IndividualIdentification individual = new IndividualIdentification();
        individual.setIdentificationId("id");
        individual.setIdentificationType("NIF");
        listIndividual.add(individual);

        return listIndividual;
    }

    private List<Characteristic> createCharacteristic() {
        List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

        Characteristic characteristic = new Characteristic();
        characteristic.setName(Constants.PHONENUMBER);
        characteristic.setValue("telefono");
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.VALIDITYTIME);
        characteristic.setValue("8");
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.PAYMENTRETRIES);
        characteristic.setValue("3");
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.TRANSACTION);
        characteristic.setValue("recovery");
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.REDIRECTION_OK);
        characteristic.setValue("redirectionOK");
        listCharacteristic.add(characteristic);

        characteristic = new Characteristic();
        characteristic.setName(Constants.REDIRECTION_KO);
        characteristic.setValue("redirectionKO");
        listCharacteristic.add(characteristic);

        return listCharacteristic;
    }

    private List<PaymentItem> createPaymentItem() {
        List<PaymentItem> listPaymentItem = new ArrayList<PaymentItem>();
        PaymentItem paymentItem = new PaymentItem();
        EntityRef item = new EntityRef();
        item.setId("id_del_vap");
        item.setRole(Constants.VAP);
        item.setCharacteristic(createCharacteristicEntityRef());
        paymentItem.setItem(item);
        listPaymentItem.add(paymentItem);
        return listPaymentItem;
    }

    private List<Characteristic> createCharacteristicEntityRef() {
        List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
        Characteristic characteristic = new Characteristic();
        characteristic.setName(Constants.BSCSCODE);
        characteristic.setValue("codigo_bscs");
        listCharacteristic.add(characteristic);
        return listCharacteristic;
    }

    private Money createTotalAmount() {
        Money money = new Money();
        money.setUnit(Constants.EUR);
        money.setValue(10f);
        return money;
    }
}