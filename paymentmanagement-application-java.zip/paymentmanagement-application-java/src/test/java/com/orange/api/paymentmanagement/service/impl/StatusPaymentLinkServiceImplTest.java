package com.orange.api.paymentmanagement.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.service.StatusPaymentLinkService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosLink;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosOperacion;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosResolutor;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosTarjeta;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseStatus;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class StatusPaymentLinkServiceImplTest {

	@Mock
	private IntegrationServiceWSPspClient integrationServiceWSPspClient;
    
	@Mock
	private PaymentRegistryRepository paymentRegistryRepository;
	
	@InjectMocks()
	private StatusPaymentLinkService service = new StatusPaymentLinkServiceImpl(integrationServiceWSPspClient,paymentRegistryRepository);

	@Test(expected = Exception.class)
	public void StatusPaymentLink_TestKO_paymentRegistry() {

		service.statusPaymentLink("id","E-Payment");
	}

	@Test
	public void StatusPaymentLink_TestOK() {
		
		PaymentRegistryDB paymentRegistry = createPaymentRegistry();
		Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString())).thenReturn(paymentRegistry);

		
		ResponseStatus responseStatus = createResponseStatus();
		Mockito.when(this.integrationServiceWSPspClient.paymentLinkStatus(Mockito.any())).thenReturn(responseStatus);

		service.statusPaymentLink("id","E-Payment");
	}
	
	private PaymentRegistryDB createPaymentRegistry() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setLinkRegistration(new Timestamp(0));
		
		return paymentRegistry;
	}
	
	private ResponseStatus createResponseStatus() {
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setResultadoOperacion(createResultadoOperacion());
		responseStatus.setDatosLink(createDatosLink());
		responseStatus.setOperaciones(createOperaciones());
		return responseStatus;
	}

	private List<DatosOperacion> createOperaciones() {
		List<DatosOperacion> listDatosOperacion = new ArrayList<DatosOperacion>();
		DatosOperacion datosOperacion = new DatosOperacion();
		datosOperacion.setNumOperacionNNP("numOperacionNNP");
		datosOperacion.setDatosTarjeta(createDatosTarjeta());
		datosOperacion.setDatosResolutor(createDatosResolutor());
		listDatosOperacion.add(datosOperacion);
		return listDatosOperacion;
	}

	private DatosResolutor createDatosResolutor() {
		DatosResolutor datosResolutor = new DatosResolutor();
		datosResolutor.setIdResolutor("idResolutor");
		datosResolutor.setIdSesion(1);
		return datosResolutor;
	}

	private DatosTarjeta createDatosTarjeta() {
		DatosTarjeta datosTarjeta = new DatosTarjeta();
		datosTarjeta.setBin("bin");
		return datosTarjeta;
	}

	private ResultadoOperacion createResultadoOperacion() {
		ResultadoOperacion resultadoOperacion = new ResultadoOperacion();
				
	    resultadoOperacion.setCodigo(Constants.OK);
		
		return resultadoOperacion;
	}

	private DatosLink createDatosLink() {
		DatosLink datosLink = new DatosLink();
		
		datosLink.setEstado(Constants.PRO);
		datosLink.setFxAltaLink("2022-12-01T18:17:41+01:00");
		datosLink.setFxFinValidez("2023-03-14T11:17:41+01:00");
		datosLink.setNumIntentos(2);
		
		return datosLink;
	}

}