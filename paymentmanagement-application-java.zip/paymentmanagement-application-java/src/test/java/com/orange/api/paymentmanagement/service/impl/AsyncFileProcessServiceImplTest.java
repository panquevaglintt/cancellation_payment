package com.orange.api.paymentmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.util.Date;
import java.util.concurrent.CompletableFuture;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.s3.AmazonS3;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.BpmPrepaidTopUpManagementClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.service.AsyncFileProcessService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext
public class AsyncFileProcessServiceImplTest {

    @Mock
    private PaymentMethodManagementClient paymentMethodManagementClient;

    @Mock
    private FixedValuesRepository fixedValuesRepository;

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;

    @Mock
    private BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement;

    @InjectMocks
    private AsyncFileProcessService asyncFileProcessService = new AsyncFileProcessServiceImpl(paymentMethodManagementClient, fixedValuesRepository, paymentRegistryRepository, bpmPrepaidTopUpManagement);

    private AmazonS3 mockS3Client;
    private File inputFile;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockS3Client = mock(AmazonS3.class);
    }

    @Test(expected = RuntimeException.class)
    public void testProccesOutputFileProcessing() throws Exception {

        inputFile = new File("mocks/examples/Recargas_ProgFecha_20241205");
        // Setup mocks
        when(paymentMethodManagementClient.getPaymentMethodAsync(anyString(), eq(Constants.TOKENIZED_CARD), anyString()))
                .thenReturn(new PaymentMethod());

        when(fixedValuesRepository.findByTransactiontypeAndApp(eq(Constants.SCHEDULED_TOP_UP), anyString()))
                .thenReturn(java.util.Collections.singletonList(new FixedValuesDB()));

        when(paymentRegistryRepository.findByPaymentMethodId(anyString())).thenReturn(new PaymentRegistryDB());

        // Call the method
        CompletableFuture<String> result = asyncFileProcessService.proccesOutputFileProcessing(mockS3Client, "testFile",
                "processFlowId", new Date(), inputFile, "zApp", "Bearer 124143");

        // Verify behavior
        assertNotNull(result);
        assertEquals("Finalizado el procesamiento del fichero de TAO exitosamente", result.get());
        verify(paymentMethodManagementClient, atLeastOnce()).getPaymentMethodAsync(anyString(), anyString(), anyString());
        verify(fixedValuesRepository, atLeastOnce()).findByTransactiontypeAndApp(anyString(), anyString());
        verify(paymentRegistryRepository, atLeastOnce()).findByPaymentMethodId(anyString());
        
        // Validate result
        assert result.get().contains("Finalizado el procesamiento del fichero de TAO exitosamente");
    }

    @Test(expected = RuntimeException.class)
    public void testProccesOutputFileValidating() throws Exception {
        inputFile = new File("mocks/examples/Recargas_ProgFecha_20241205_Enriquecido.csv.sal");

        // Mock repository and client behavior
        when(paymentRegistryRepository.findByOriginOpnumber(anyString())).thenReturn(new PaymentRegistryDB());
        when(paymentMethodManagementClient.getPaymentMethodAsync(anyString(), anyString(),anyString())).thenReturn(new PaymentMethod());
        when(paymentMethodManagementClient.updatePaymentMethodAsync(anyString(), Mockito.any(),anyString())).thenReturn(new PaymentMethod());
        when(bpmPrepaidTopUpManagement.updateFile(anyString(), Mockito.any())).thenReturn(null);

        // Execute the method
        CompletableFuture<String> result = asyncFileProcessService.proccesOutputFileValidating(mockS3Client, "testFile",
                "processFlowId", new Date(), inputFile, "zApp", "Bearer 124143");

        // Verify behavior
        verify(mockS3Client, atLeastOnce()).generatePresignedUrl(anyString(), anyString(), Mockito.any(), Mockito.any());
        verify(paymentRegistryRepository, atLeastOnce()).findByOriginOpnumber(anyString());
        verify(paymentMethodManagementClient, atLeastOnce()).getPaymentMethodAsync(anyString(), anyString(), anyString());
        verify(bpmPrepaidTopUpManagement, atLeastOnce()).updateFile(anyString(), Mockito.any());

        // Validate result
        assert result.get().contains("Finalizado el procesamiento del fichero Final exitosamente");
    }

}
