package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.service.SearchPaymentMarketPlaceService;
import com.orange.api.paymentmanagement.utils.Constants;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class searchPaymentMarketPlaceServiceImplTest {

    
	@Mock
	private PaymentRegistryRepository paymentRegistryRepository;
	
	@InjectMocks()
	private SearchPaymentMarketPlaceService service = new SearchPaymentMarketPlaceServiceImpl(paymentRegistryRepository);
		

	
	@Test
	public void searchPaymentMarketPlaceByPhoneNumber_TestOK() {

		List<PaymentRegistryDB> paymentRegistryDBList = new ArrayList<>();
		PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
		paymentRegistryDB.setOriginOpnumber("1234567");
		paymentRegistryDBList.add(paymentRegistryDB);
		Mockito.when(this.paymentRegistryRepository.findByPhonenumber(Mockito.anyString())).thenReturn(paymentRegistryDBList);
		
		service.searchPaymentMarketPlace(null, null, null, "654678678");
	}
	
	@Test
	public void searchPaymentMarketPlaceByDocumentNumberIndividual_TestOK() {

		List<PaymentRegistryDB> paymentRegistryDBList = new ArrayList<>();
		PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
		paymentRegistryDB.setOriginOpnumber("1234567");
		paymentRegistryDBList.add(paymentRegistryDB);
		Mockito.when(this.paymentRegistryRepository.findByIdDocument(Mockito.anyString())).thenReturn(paymentRegistryDBList);
		
		service.searchPaymentMarketPlace(Constants.REFERRED_TYPE_INDIVIDUAL, "NIF", "45657865X", null);
	}
	
	@Test
	public void searchPaymentMarketPlaceByDocumentNumberOrganization_TestOK() {

		List<PaymentRegistryDB> paymentRegistryDBList = new ArrayList<>();
		PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();
		paymentRegistryDB.setOriginOpnumber("1234567");
		paymentRegistryDBList.add(paymentRegistryDB);
		Mockito.when(this.paymentRegistryRepository.findByIdDocument(Mockito.anyString())).thenReturn(paymentRegistryDBList);
		
		service.searchPaymentMarketPlace(Constants.REFERRED_TYPE_ORGANIZATION, "NIF", "45657865X", null);
	}
	
	

	
}