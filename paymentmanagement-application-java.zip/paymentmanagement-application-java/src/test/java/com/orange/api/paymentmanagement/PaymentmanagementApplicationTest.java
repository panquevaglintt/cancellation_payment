/*package com.orange.api.paymentmanagement;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Base test class.
 
@RunWith(SpringRunner.class)
@SpringBootTest
public class PaymentmanagementApplicationTest {

	@Test
	public void contextLoads() {
	}

	@Test
	public void main() {
		PaymentmanagementApplication.main(new String[] {});
	}
}
*/