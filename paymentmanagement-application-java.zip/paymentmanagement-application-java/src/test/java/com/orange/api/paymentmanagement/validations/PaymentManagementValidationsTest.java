package com.orange.api.paymentmanagement.validations;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.EntityRef;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.PaymentMethodRefOrValue;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.openapiosp.boot.errorhandler.autoconfigure.OrangeErrorMessageSourceConfig;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

@ContextConfiguration(classes = { OrangeErrorMessageSourceConfig.class })
@RunWith(SpringRunner.class)
public class PaymentManagementValidationsTest {

	@Test
	public void validations_validateIdPaymentLink_OK() {
		PaymentManagementValidations.validateIdPaymentLink("id");
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validateIdPaymentLink_null_KO() {
		PaymentManagementValidations.validateIdPaymentLink(null);
	}

	@Test
	public void validations_validatePostPayment_OK() {
		Payment payment = createPayment();
        OffsetDateTime statusDate = OffsetDateTime.parse("2024-02-01T10:11:18+01:00");
        payment.setStatusDate(statusDate);
		PaymentManagementValidations.validatePostPayment(payment);
	}
	
	@Test
	public void validations_validatePostPaymentIframe_OK() {
		Payment payment = createPaymentIframe();
		PaymentManagementValidations.validatePostIframe(payment);
	}
	
    @Test
    public void validations_validatePostScheduledIframe_OK() {
        Payment payment = createPaymentIframe();
        PaymentManagementValidations.validatePostScheduledIframe(payment);
    }

    @Test
    public void validations_validateTransferFile_OK() {
        Payment payment = new Payment();
        List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
        Characteristic characteristic = new Characteristic();
        characteristic.setName("FileName");
        characteristic.setValue("aaaaa");
        listCharacteristic.add(characteristic);
        characteristic = new Characteristic();
        characteristic.setName("ProcessFlowId");
        characteristic.setValue("bbbbb");
        listCharacteristic.add(characteristic);
        payment.setCharacteristic(listCharacteristic);
        
        PaymentManagementValidations.validateTransferFile(payment);
    }

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_totalAmount1_KO() {
		Payment payment = createPayment();
		payment.setTotalAmount(null);
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_totalAmount2_KO() {
		Payment payment = createPayment();
		payment.getTotalAmount().setValue(null);
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_paymentItem1_KO() {
		Payment payment = createPayment();
		payment.setPaymentItem(null);
        OffsetDateTime statusDate = OffsetDateTime.parse("2024-01-01T10:12:21+02:00");
        payment.setStatusDate(statusDate);
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_paymentItem2_KO() {
		Payment payment = createPayment();
		payment.getPaymentItem().get(0).getItem().setCharacteristic(createBadCharacteristicPaymentItem());
        OffsetDateTime statusDate = OffsetDateTime.parse("2024-05-01T10:11:19+02:00");
        payment.setStatusDate(statusDate);
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_characteristic1_KO() {
		Payment payment = createPayment();
		payment.setCharacteristic(null);
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_characteristic2_KO() {
		Payment payment = createPayment();
		payment.setCharacteristic(createCharacteristicBadPhoneNumber());
		PaymentManagementValidations.validatePostPayment(payment);
	}

	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_characteristic5_KO() {
		Payment payment = createPayment();
		payment.setCharacteristic(createCharacteristicBadTransaction());
		PaymentManagementValidations.validatePostPayment(payment);
	}
	
	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_payer1_KO() {
		Payment payment = createPayment();
		payment.setPayer(null);
        OffsetDateTime statusDate = OffsetDateTime.parse("2024-06-01T10:09:21+02:00");
        payment.setStatusDate(statusDate);
		PaymentManagementValidations.validatePostPayment(payment);
	}	
	
	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPayment_payer2_KO() {
		Payment payment = createPayment();
		payment.getPayer().getIndividualIdentification().get(0).setIdentificationId(null);
        OffsetDateTime statusDate = OffsetDateTime.parse("2024-04-01T10:11:21+01:00");
        payment.setStatusDate(statusDate);
		PaymentManagementValidations.validatePostPayment(payment);
	}	
	
	@Test
	public void validations_validatePostPaymentAnnulation_OK() {
		Payment payment = createPayment();
		payment.setStatus(Constants.CANCELLED);
		PaymentManagementValidations.validatePostPaymentAnulationAndReturned(payment);
	}
	
	@Test(expected = OpenApiBadRequestException.class)
	public void validations_validatePostPaymentFind_status_KO() {
		Payment payment = createPayment();
		PaymentManagementValidations.validatePaymentFind(null, null, null, null, null, null, null, null, null);
	}	
	
	private List<Characteristic> createCharacteristicBadTransaction() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);

		
		return listCharacteristic;
	}
	
	   @Test(expected = OpenApiBadRequestException.class)
	    public void validations_proccesFlowId_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_TransactionType_value_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue("patata");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_TransactionType_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_phoneNumber_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_paymentMethod_id_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_paymentMethod_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_totalAmount_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        payment.setTotalAmount(null);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);

	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_totalAmount_unit_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setValue((float) 50);
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);
	        
	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }
	    
	    @Test(expected = OpenApiBadRequestException.class)
	    public void validations_totalAmount_value_status_KO() {
	        
	        Payment payment = createPayment();
	        payment.setType(Constants.TOKEN_PAYMENT);
	        PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
	        paymentMethod.setId("12345");
	        payment.setPaymentMethod(paymentMethod);
	        Money totalAmount = new Money();
	        totalAmount.setUnit("EUR");
	        payment.setTotalAmount(totalAmount);
	        List<Characteristic> characteristicList = new ArrayList<>();
	        
	        Characteristic characteristic = null;
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PHONENUMBER);
	        characteristic.setValue("123456");
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.TRANSACTION);
	        characteristic.setValue(Constants.SCHEDULED_TOP_UP);
	        characteristicList.add(characteristic);
	        
	        characteristic = new Characteristic();
	        characteristic.setName(Constants.PROCESSFLOW_ID);
	        characteristic.setValue("Prueba");
	        characteristicList.add(characteristic);
	        
	        payment.setCharacteristic(characteristicList);
	        
	        PaymentManagementValidations.validatePostTokenPayment(payment);
	    }

	private List<Characteristic> createCharacteristicBadPaymentRetries() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("amortization");
		listCharacteristic.add(characteristic);
		
		
		
		return listCharacteristic;
	}

	private List<Characteristic> createCharacteristicBadValidity() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("amortization");
		listCharacteristic.add(characteristic);
		
		
		
		return listCharacteristic;
	}

	private List<Characteristic> createCharacteristicBadPhoneNumber() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("amortization");
		listCharacteristic.add(characteristic);

		return listCharacteristic;
	}

	private List<Characteristic> createBadCharacteristicPaymentItem() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName("mal");
		characteristic.setValue("codigo_bscs");
		listCharacteristic.add(characteristic);
		return listCharacteristic;
	}

	private Payment createPayment() {
		Payment payment = new Payment();

		payment.setTotalAmount(createTotalAmount());
		payment.setPaymentItem(createPaymentItem());
		payment.setCharacteristic(createCharacteristic());
		payment.setPayer(createPayer());

		return payment;
	}
	
	private Payment createPaymentIframe() {
		Payment payment = new Payment();

		payment.setTotalAmount(createTotalAmount());
		payment.setPaymentItem(createPaymentItem());
		payment.setCharacteristic(createCharacteristicIframe());
		payment.setPayer(createPayer());
		payment.setAccount(createAccount());

		return payment;
	}
	
	private AccountRef createAccount() {
		AccountRef account = new AccountRef();
		
		account.setId("idAccount");
		account.setReferredType(Constants.BILLINGACCOUNT);
		
		return account;
	}


	private RelatedParty createPayer() {
		RelatedParty payer = new RelatedParty();
		payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
		payer.setRole(Constants.CLIENT);
		payer.setIndividualIdentification(createIndividual());
		return payer;
	}

	private List<IndividualIdentification> createIndividual() {
		List<IndividualIdentification> listIndividual = new ArrayList<IndividualIdentification>();

		IndividualIdentification individual = new IndividualIdentification();
		individual.setIdentificationId("id");
		individual.setIdentificationType("NIF");
		listIndividual.add(individual);

		return listIndividual;
	}

	private List<Characteristic> createCharacteristic() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("amortization");
		listCharacteristic.add(characteristic);

		return listCharacteristic;
	}
	
	private List<Characteristic> createCharacteristicIframe() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();

		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);

		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("amortization");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_OK);
		characteristic.setValue("redirectionOK");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_KO);
		characteristic.setValue("redirectionKO");
		listCharacteristic.add(characteristic);

		return listCharacteristic;
	}

	private List<PaymentItem> createPaymentItem() {
		List<PaymentItem> listPaymentItem = new ArrayList<PaymentItem>();
		PaymentItem paymentItem = new PaymentItem();
		EntityRef item = new EntityRef();
		item.setId("id_del_vap");
		item.setRole(Constants.VAP);
		item.setCharacteristic(createCharacteristicEntityRef());
		paymentItem.setItem(item);
		listPaymentItem.add(paymentItem);
		return listPaymentItem;
	}

	private List<Characteristic> createCharacteristicEntityRef() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.BSCSCODE);
		characteristic.setValue("codigo_bscs");
		listCharacteristic.add(characteristic);
		return listCharacteristic;
	}

	private Money createTotalAmount() {
		Money money = new Money();
		money.setUnit(Constants.EUR);
		money.setValue(10f);
		return money;
	}

}