package com.orange.api.paymentmanagement.service.impl;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.mappers.GenerationScheduledIframeMapper;
import com.orange.api.paymentmanagement.utils.PaymentManagementUtils;
import com.orange.api.paymentmanagement.web.model.Payment;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext
public class GenerationScheduledIframeServiceImplTest {

    @Mock
    private FixedValuesRepository fixedValuesRepository;

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;

    @Mock
    private GenerationScheduledIframeMapper generationScheduledIframeMapper;

    @Mock
    private PaymentManagementUtils paymentManagementUtils;

    @InjectMocks
    private GenerationScheduledIframeServiceImpl generationScheduledIframeService;

    @Value("${urlIframeScheduled}")
    private String urlIframeScheduled;
    
    ObjectMapper objectMapper;

    @Test
    public void testGenerationScheduledIframe() throws UnsupportedEncodingException {
        // Arrange
        String zLogin = "testUser";
        String zCallerIp = "127.0.0.1";
        String app = "testApp";
        String transactionType = "testTransaction";        
       
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.registerModule(new JavaTimeModule());

        Payment payment = new Payment();
        try {
            File file = new File("mocks/examples/PaymentIframePreauthRequest.json");
            payment = objectMapper.readValue(file, Payment.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        FixedValuesDB fixedValues = new FixedValuesDB();

        // Populating fields
        fixedValues.setId(1L);
        fixedValues.setCreationDate(new Timestamp(System.currentTimeMillis()));
        fixedValues.setUpdateDate(new Timestamp(System.currentTimeMillis()));
        fixedValues.setClientCode("CLIENT123");
        fixedValues.setTransactiontype("TRANSACTION_TYPE");
        fixedValues.setApp("APP_NAME");
        fixedValues.setCommercialCode("COMMERCIAL123");
        fixedValues.setTerminalCode("TERMINAL123");
        fixedValues.setKeyword("KEYWORD");
        fixedValues.setLanguage("en");
        fixedValues.setCoTipoOpLink("OPLINK_TYPE");
        fixedValues.setUrlLogo("https://example.com/logo.png");
        fixedValues.setColor("#FFFFFF");
        fixedValues.setText("Some Text");
        fixedValues.setTextcvv("CVV Text");
        fixedValues.setTextButton("Pay Now");
        fixedValues.setTextFxExpiration("MM/YY");
        fixedValues.setTextCard("Card Number");
        fixedValues.setTextTitle("Payment Title");
        fixedValues.setTextMask("**** **** **** ****");
        fixedValues.setCardType("VISA");
        fixedValues.setCurrency("USD");
        fixedValues.setSeed("SEED123");
        fixedValues.setFormButton("Submit");
        fixedValues.setTemplate("DEFAULT_TEMPLATE");
        fixedValues.setPaymentRetries("3");
        fixedValues.setValidityTime("60");
        fixedValues.setTarget("_blank");
        fixedValues.setUrlCss("https://example.com/styles.css");
        fixedValues.setTypelink("LINK_TYPE");
        fixedValues.setPaymentMethod("CREDIT_CARD");
        
        List<FixedValuesDB> fixedValuesList = new ArrayList<FixedValuesDB>();
        fixedValuesList.add(fixedValues);
        
        when(fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(Mockito.any(),Mockito.any(),Mockito.any()))
                .thenReturn(fixedValuesList);

        // Act
        Payment result = generationScheduledIframeService.generationScheduledIframe(payment, app, zLogin, zCallerIp);

        assertNotNull(result);
        assertEquals(result, payment);  // Assuming the service modifies and returns the same payment object
    }
}
