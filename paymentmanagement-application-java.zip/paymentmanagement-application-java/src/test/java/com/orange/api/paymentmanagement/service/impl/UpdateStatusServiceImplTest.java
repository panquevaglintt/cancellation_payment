package com.orange.api.paymentmanagement.service.impl;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.BpmAmortizationManagementClient;
import com.orange.api.paymentmanagement.feign.client.BpmPfSalesClient;
import com.orange.api.paymentmanagement.feign.client.BpmPrepaidTopUpManagementClient;
import com.orange.api.paymentmanagement.feign.client.BpmRecoveryManagementClient;
import com.orange.api.paymentmanagement.feign.client.PaymentMethodManagementClient;
import com.orange.api.paymentmanagement.service.UpdateStatusPaymentService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.EntityRef;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.PaymentMethodRefOrValue;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.api.paymentmanagement.web.model.StatusChange;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResponseAnnulationAndReturned;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;
import com.orange.api.paymentmanagement.web.model.paymentmethodmanagement.PaymentMethod;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class UpdateStatusServiceImplTest {
    
	@Mock
	private PaymentRegistryRepository paymentRegistryRepository;
	
	@Mock
	private BpmAmortizationManagementClient bpmAmortizationManagement;
	
	@Mock
	private BpmRecoveryManagementClient bpmRecoveryManagement;
	
	@Mock
	private BpmPrepaidTopUpManagementClient bpmPrepaidTopUpManagement;
	
	@Mock
	private BpmPfSalesClient bpmPfSalesClient;
	
	@Mock
	private PaymentMethodManagementClient paymentMethodManagementClient;
	
	ObjectMapper objectMapper;
	
	@InjectMocks()
	private UpdateStatusPaymentService service = new UpdateStatusPaymentServiceImpl(paymentRegistryRepository,bpmAmortizationManagement,bpmRecoveryManagement, bpmPrepaidTopUpManagement, bpmPfSalesClient, paymentMethodManagementClient);

	@Test(expected = Exception.class)
	public void UpdateStatus_TestKO_paymentRegistry() {

		Payment payment = createPayment();

		service.updateStatusPayment("id",payment);
	}

	@Test
	public void UpdateStatusAmortization_TestOK() {
		Payment payment = createPayment();
		PaymentRegistryDB paymentRegistry = createPaymentRegistryAmortization();
		Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString())).thenReturn(paymentRegistry);
		Mockito.when(this.bpmAmortizationManagement.getProccessFlow(Mockito.any())).thenReturn(null);
		Mockito.when(this.bpmAmortizationManagement.updateStatus(Mockito.any(), Mockito.any())).thenReturn(null);
		Mockito.when(this.paymentMethodManagementClient.createPaymentMethod(Mockito.any())).thenReturn(null);
		service.updateStatusPayment("id",payment);
	}
	
	
	@Test
	public void UpdateStatusRecoveryIframe_TestOK() {
		Payment payment = createPayment();
		PaymentRegistryDB paymentRegistry = createPaymentRegistryRecoveryIframe();
		Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString())).thenReturn(paymentRegistry);
		Mockito.when(this.bpmRecoveryManagement.updateStatusIframe(Mockito.any(), Mockito.any())).thenReturn(null);
		service.updateStatusPayment("id",payment);
	}
	
	@Test
	public void UpdateStatusRecoveryPaymentLink_TestOK() {
		Payment payment = createPayment();
		PaymentRegistryDB paymentRegistry = createPaymentRegistryRecovery();
		Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString())).thenReturn(paymentRegistry);
		Mockito.when(this.bpmRecoveryManagement.updateStatus(Mockito.any(), Mockito.any())).thenReturn(null);
		service.updateStatusPayment("id",payment);
	}
	
	@Test
	public void UpdateStatusPrepaidTopUp_TestOK() {
		Payment payment = createPayment();
		PaymentRegistryDB paymentRegistry = createPaymentRegistryPrepaidTopUp();
		Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString())).thenReturn(paymentRegistry);
		Mockito.when(this.bpmPrepaidTopUpManagement.updateStatusIframe(Mockito.any(), Mockito.any())).thenReturn(null);
		service.updateStatusPayment("id",payment);
	}
	
    @Test
    public void UpdateStatusPurchase_TestOK() {
        Payment payment = createPayment();
        PaymentRegistryDB paymentRegistry = createPaymentRegistryPurchase();
        Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString()))
                .thenReturn(paymentRegistry);
        Mockito.when(this.bpmPfSalesClient.updateStatusPurchase(Mockito.any(), Mockito.any())).thenReturn(null);
        service.updateStatusPayment("id", payment);
    }
    
    @Test
    public void UpdateStatusScheduled_TestOK() throws StreamReadException, DatabindException, IOException {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.registerModule(new JavaTimeModule());

        File file = new File("mocks/examples/PaymentMethodResponse.json");
        PaymentMethod paymentMethod = objectMapper.readValue(file, PaymentMethod.class);

        Payment payment = createPayment();
        PaymentRegistryDB paymentRegistry = createPaymentRegistryScheduled();
        Mockito.when(this.paymentRegistryRepository.findByOriginOpnumber(Mockito.anyString()))
                .thenReturn(paymentRegistry);
        Mockito.when(this.paymentMethodManagementClient.createPaymentMethod(Mockito.any())).thenReturn(paymentMethod);
        Mockito.when(this.bpmPrepaidTopUpManagement.updateScheduled(Mockito.any(), Mockito.any())).thenReturn(null);

        service.updateStatusPayment("id", payment);
    }
	
	private PaymentRegistryDB createPaymentRegistryAmortization() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setTransactiontype("amortization");
		return paymentRegistry;
	}
	
	private PaymentRegistryDB createPaymentRegistryRecovery() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setTransactiontype("recovery");
		return paymentRegistry;
	}
	
	private PaymentRegistryDB createPaymentRegistryRecoveryIframe() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setTransactiontype("recovery");
		paymentRegistry.setHash("hash");
		return paymentRegistry;
	}
	
	private PaymentRegistryDB createPaymentRegistryPrepaidTopUp() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setTransactiontype("top_up");
		return paymentRegistry;
	}
	
    private PaymentRegistryDB createPaymentRegistryPurchase() {
        PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
        paymentRegistry.setTransactiontype("purchase");
        return paymentRegistry;
    }
	
    private PaymentRegistryDB createPaymentRegistryScheduled() {
        PaymentRegistryDB paymentRegistryDB = new PaymentRegistryDB();

     // Timestamps
     paymentRegistryDB.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryDB.setUpdateDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryDB.setAnnulationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryDB.setConfirmationOriginOpdate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryDB.setLinkExpiration(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryDB.setLinkRegistration(Timestamp.valueOf(LocalDateTime.now()));

     // Basic details
     paymentRegistryDB.setClientCode("12345");
     paymentRegistryDB.setCommercialCode("COMM123");
     paymentRegistryDB.setTerminalCode("TERM001");
     paymentRegistryDB.setLanguage("EN");
     paymentRegistryDB.setAmount("100.00");
     paymentRegistryDB.setCurrency("USD");
     paymentRegistryDB.setStatus("Scheduled");
     paymentRegistryDB.setStatusDescription("Payment scheduled successfully");

     // Identifiers
     paymentRegistryDB.setOriginOpnumber("OP123456");
     paymentRegistryDB.setPhonenumber("1234567890");
     paymentRegistryDB.setIdDocument("ID987654");
     paymentRegistryDB.setTypeDocument("Passport");
     paymentRegistryDB.setType("Individual");
     paymentRegistryDB.setTransactiontype("scheduled_top_up");
     paymentRegistryDB.setBscsIdentifier("BSCS12345");
     paymentRegistryDB.setVapId("VAP56789");
     paymentRegistryDB.setProcessflowId("PF123456");
     paymentRegistryDB.setUserId("User001");
     paymentRegistryDB.setLinkCode("LINK123");
     paymentRegistryDB.setLinkId("LINKID56789");
     paymentRegistryDB.setSessionId("SESSION12345");
     paymentRegistryDB.setPaymentId("PAYID987654");
     paymentRegistryDB.setMarketplaceOrderId("MARKET123");

     // Links and URL details
     paymentRegistryDB.setLink("http://example.com/payment-link");
     paymentRegistryDB.setPaymentLink("http://example.com/payment-details");
     paymentRegistryDB.setUrlOk("http://example.com/success");
     paymentRegistryDB.setUrlKo("http://example.com/failure");
     paymentRegistryDB.setUrlIframe("http://example.com/iframe");
     paymentRegistryDB.setHash("HASHVALUE12345");

     // Payment details
     paymentRegistryDB.setPaymentFlow("IFRAME");
     paymentRegistryDB.setPaymentAttempts("3");
     paymentRegistryDB.setPaymentResult("Success");
     paymentRegistryDB.setResultDescription("Payment processed successfully");
     paymentRegistryDB.setPaymentUpdate("2023-01-01 12:00:00");
     paymentRegistryDB.setPaymentMethod("Credit Card");
     paymentRegistryDB.setPaymentMethodId("METHOD001");

     // Card and banking details
     paymentRegistryDB.setBankNumber("BANK12345");
     paymentRegistryDB.setCardNumber("4111111111111111");
     paymentRegistryDB.setToken("TOKEN123456");

     // Annulation details
     paymentRegistryDB.setAnnulationOpnumber("ANN123456");
     paymentRegistryDB.setAnnulationId("ANNID123");
     paymentRegistryDB.setAnnulationResult("Success");
     paymentRegistryDB.setAnnulationDescription("Annulation processed successfully");

     // Session details
     paymentRegistryDB.setSessionDate("2023-01-01 12:00:00");

     // Miscellaneous
     paymentRegistryDB.setAuthorizationNumber("AUTH12345");
     paymentRegistryDB.setChannel("WEB");
     paymentRegistryDB.setCustCode("CUST001");
     paymentRegistryDB.setOperationType("Online");
     paymentRegistryDB.setConfirmationOriginOpnumber("CONFOP12345");

     return paymentRegistryDB;
    }
	
	private PaymentRegistryDB createPaymentRegistryIndividual() {
		PaymentRegistryDB paymentRegistry = new PaymentRegistryDB();
		paymentRegistry.setType(Constants.REFERRED_TYPE_INDIVIDUAL);
		return paymentRegistry;
	}
	
	private ResponseAnnulationAndReturned createResponseAnnulation() {
		ResponseAnnulationAndReturned responseAnnulationAndReturned = new ResponseAnnulationAndReturned();
		responseAnnulationAndReturned.setResultadoOperacion(new ResultadoOperacion());
		return responseAnnulationAndReturned;
	}

	private List<FixedValuesDB> createFixedValues() {
		List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
		FixedValuesDB fixedValues = new FixedValuesDB();
		fixedValues.setUrlCss("##CSS##");
		fixedValues.setPaymentRetries("3");
		fixedValues.setValidityTime("3");
		listFixedValues.add(fixedValues);
		return listFixedValues;
	}

	private Payment createPayment() {
		Payment payment = new Payment();
		
		payment.setTotalAmount(createTotalAmount());
		payment.setPaymentItem(createPaymentItem());
		payment.setCharacteristic(createCharacteristic());
		payment.setPayer(createPayer());
		payment.setAccount(createAccount());
		payment.setStatusChange(createStatusChange());
		payment.setPaymentMethod(createPaymentMethod());
		
		return payment;
	}

	private PaymentMethodRefOrValue createPaymentMethod() {
		PaymentMethodRefOrValue paymentMethod = new PaymentMethodRefOrValue();
		paymentMethod.setToken("token");
		paymentMethod.setCharacteristic(createCharacteristicPaymentMethod());
		
		return paymentMethod;
	}

	private List<Characteristic> createCharacteristicPaymentMethod() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName("Bin");
		characteristic.setValue("bin");
		listCharacteristic.add(characteristic);
		
		return listCharacteristic;
	}

	private List<StatusChange> createStatusChange() {
		List<StatusChange> listStatusChange = new ArrayList<StatusChange>();
		
		StatusChange statusChange = new StatusChange();
		listStatusChange.add(statusChange);
		
		return listStatusChange;
	}

	private AccountRef createAccount() {
		AccountRef account = new AccountRef();
		
		account.setId("idAccount");
		
		return account;
	}

	private RelatedParty createPayer() {
		RelatedParty payer = new RelatedParty();
		payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
		payer.setRole(Constants.CLIENT);
		payer.setIndividualIdentification(createIndividual());
		return payer;
	}

	private List<IndividualIdentification> createIndividual() {
		List<IndividualIdentification> listIndividual = new ArrayList<IndividualIdentification>();
		
		IndividualIdentification individual = new IndividualIdentification();
		individual.setIdentificationId("id");
		individual.setIdentificationType("NIF");
		listIndividual.add(individual);
		
		return listIndividual;
	}

	private List<Characteristic> createCharacteristic() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("recovery");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_OK);
		characteristic.setValue("redirectionOK");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_KO);
		characteristic.setValue("redirectionKO");
		listCharacteristic.add(characteristic);
		
		
		
		return listCharacteristic;
	}

	private List<PaymentItem> createPaymentItem() {
		List<PaymentItem> listPaymentItem = new ArrayList<PaymentItem>();
		PaymentItem paymentItem = new PaymentItem();
		EntityRef item = new EntityRef();
		item.setId("id_del_vap");
		item.setRole(Constants.VAP);
		item.setCharacteristic(createCharacteristicEntityRef());
		paymentItem.setItem(item);
		listPaymentItem.add(paymentItem);
		return listPaymentItem;
	}

	private List<Characteristic> createCharacteristicEntityRef() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.BSCSCODE);
		characteristic.setValue("codigo_bscs");
		listCharacteristic.add(characteristic);
		return listCharacteristic;
	}

	private Money createTotalAmount() {
		Money money = new Money();
		money.setUnit(Constants.EUR);
		money.setValue(10f);
		return money;
	}
}