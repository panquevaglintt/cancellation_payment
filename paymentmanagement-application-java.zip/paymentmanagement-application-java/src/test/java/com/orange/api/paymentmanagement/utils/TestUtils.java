package com.orange.api.paymentmanagement.utils;

import java.util.ArrayList;
import java.util.List;

import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.RelatedParty;

public final class TestUtils {

    private TestUtils() {
    }

    public static Payment createValidEPayment() {
        return Payment.builder()
                .type(Constants.E_PAYMENT)
                .totalAmount(createValidAmount())
                .characteristic(createCharacteristics())
                .payer(createIndividualPayer())
                .build();
    }

    public static Payment createValidMPPayment() {
        return Payment.builder()
                .type(Constants.MP_PAYMENT)
                .totalAmount(createValidAmount())
                .characteristic(createCharacteristics())
                .payer(createIndividualPayer())
                .build();
    }

    public static Payment createValidIframePayment() {
        return Payment.builder()
                .type("Iframe-Payment")
                .totalAmount(createValidAmount())
                .characteristic(createCharacteristics())
                .payer(createIndividualPayer())
                .build();
    }

    public static Payment createValidCancellationPaymentLink() {
        return Payment.builder()
                .type(Constants.PAYMENT_LINK_TYPE_CANCELLATION)
                .totalAmount(createValidAmount())
                .characteristic(createCharacteristics())
                .payer(createIndividualPayer())
                .build();
    }

    private static Money createValidAmount() {
        return Money.builder().value(10f).build();
    }

    private static List<Characteristic> createCharacteristics() {
        List<Characteristic> characteristics = new ArrayList<>();
        characteristics.add(Characteristic.builder().name(Constants.PHONENUMBER).build());
        characteristics.add(Characteristic.builder().name(Constants.REDIRECTION_OK).build());
        characteristics.add(Characteristic.builder().name(Constants.REDIRECTION_KO).build());
        characteristics.add(Characteristic.builder().name(Constants.TRANSACTION).build());
        return characteristics;
    }

    private static RelatedParty createIndividualPayer() {
        List<IndividualIdentification> individualIdentifications = new ArrayList<>();
        individualIdentifications.add(IndividualIdentification.builder().identificationId("id").identificationType("NIF").build());
        return RelatedParty.builder()
                .role(Constants.CLIENT)
                .referredType(Constants.REFERRED_TYPE_INDIVIDUAL)
                .individualIdentification(individualIdentifications)
                .build();
    }
}
