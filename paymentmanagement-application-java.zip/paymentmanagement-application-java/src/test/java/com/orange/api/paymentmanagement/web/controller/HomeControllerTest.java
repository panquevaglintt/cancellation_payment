/*package com.orange.api.paymentmanagement.web.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

@RunWith(BlockJUnit4ClassRunner.class)
public class HomeControllerTest {

	@Test
	public void testIndex() {

		HomeController myUnit = new HomeController();
		String result = myUnit.index();
		Assert.assertEquals("redirect:swagger-ui.html", result);
	}
}*/