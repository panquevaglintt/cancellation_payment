package com.orange.api.paymentmanagement.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.service.GenerationPreauthorizationIframeService;
import com.orange.api.paymentmanagement.utils.Constants;
import com.orange.api.paymentmanagement.web.model.AccountRef;
import com.orange.api.paymentmanagement.web.model.Characteristic;
import com.orange.api.paymentmanagement.web.model.EntityRef;
import com.orange.api.paymentmanagement.web.model.IndividualIdentification;
import com.orange.api.paymentmanagement.web.model.Money;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.PaymentItem;
import com.orange.api.paymentmanagement.web.model.RelatedParty;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class GenerationPreauthorizationIframeServiceImplTest {

	@Mock
	private FixedValuesRepository fixedValuesRepository;
    
	@Mock
	private PaymentRegistryRepository paymentRegistryRepository;
	
	@InjectMocks()
	private GenerationPreauthorizationIframeService service = new GenerationPreauthorizationIframeServiceImpl(fixedValuesRepository,paymentRegistryRepository);

	@Test(expected = OpenApiBadRequestException.class)
	public void GenerationIframe_TestKO_fixedValues() {
	    ReflectionTestUtils.setField(service, "urlIframePreauth", "test");

		Payment payment = createPayment();		
		service.generationPreauthorizationIframe(payment, "fichadecliente", "zlogin", "aaa");
	}
	
	@Test
	public void GenerationIframe_TestOK() {
	    ReflectionTestUtils.setField(service, "urlIframePreauth", "test");

		Payment payment = createPayment();
		List<FixedValuesDB> listFixedValues = createFixedValues();
		Mockito.when(this.fixedValuesRepository.findByTransactiontypeAndAppAndTypelink(Mockito.anyString(),
				Mockito.anyString(),Mockito.anyString())).thenReturn(listFixedValues);

		payment = service.generationPreauthorizationIframe(payment, "fichadecliente", "zlogin", "aaa");
		System.out.println("");
	}
	
	private List<FixedValuesDB> createFixedValues() {
		List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
		FixedValuesDB fixedValues = new FixedValuesDB();
		fixedValues.setApp("acmeweb");
		fixedValues.setCardType("6");
		fixedValues.setClientCode("ORANGE");
		fixedValues.setColor("#FF7900");
		fixedValues.setCommercialCode("40005");
		fixedValues.setCoTipoOpLink("0013");
		fixedValues.setCurrency("978");
		fixedValues.setFormButton("Realizar%20Pago");
		fixedValues.setKeyword("KGeeR7Ot1vo2");
		fixedValues.setLanguage("es");
		fixedValues.setPaymentRetries("1");
		fixedValues.setSeed("ZNFyvyiJExVSu66HeY3n");
		fixedValues.setTarget("_top");
		fixedValues.setTemplate("template3");
		fixedValues.setTerminalCode("00000000");
		fixedValues.setText("text");
		fixedValues.setTextButton("PAGAR");
		fixedValues.setTextCard("NUMERO DE TARJETA");
		fixedValues.setTextcvv("DIGITOS DE SEGURIDAD - CVV");
		fixedValues.setTextFxExpiration("FECHA CADUCIDAD");
		fixedValues.setTextMask("text");
		fixedValues.setTextTitle("Usted va a realizar un pago a traves de una pagina segura con los datos que a continuacion se detallan. Por favor, introduzca sus datos de pago en el formulario.");
		fixedValues.setTransactiontype("prepaidtopup");
		fixedValues.setTypelink("iframe");
		fixedValues.setUrlCss("##CSS##");
		fixedValues.setUrlLogo("https://www.orange.es/static/img/logos/LogoOrange.jpg");
		fixedValues.setValidityTime("8");
		listFixedValues.add(fixedValues);
		return listFixedValues;
	}

	private Payment createPayment() {
		Payment payment = new Payment();
		
		payment.setTotalAmount(createTotalAmount());
		payment.setPaymentItem(createPaymentItem());
		payment.setCharacteristic(createCharacteristic());
		payment.setPayer(createPayer());
		payment.setAccount(createAccount());
		
		return payment;
	}

	private AccountRef createAccount() {
		AccountRef account = new AccountRef();
		
		account.setId("idAccount");
		
		return account;
	}

	private RelatedParty createPayer() {
		RelatedParty payer = new RelatedParty();
		payer.setReferredType(Constants.REFERRED_TYPE_INDIVIDUAL);
		payer.setRole(Constants.CLIENT);
		payer.setIndividualIdentification(createIndividual());
		return payer;
	}

	private List<IndividualIdentification> createIndividual() {
		List<IndividualIdentification> listIndividual = new ArrayList<IndividualIdentification>();
		
		IndividualIdentification individual = new IndividualIdentification();
		individual.setIdentificationId("id");
		individual.setIdentificationType("NIF");
		listIndividual.add(individual);
		
		individual = new IndividualIdentification();
		individual.setIdentificationId("customerCode");
		individual.setIdentificationType(Constants.CUSTOMER_CODE);
		listIndividual.add(individual);
		
		return listIndividual;
	}

	private List<Characteristic> createCharacteristic() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.PHONENUMBER);
		characteristic.setValue("telefono");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.VALIDITYTIME);
		characteristic.setValue("8");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.PAYMENTRETRIES);
		characteristic.setValue("3");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.TRANSACTION);
		characteristic.setValue("recovery");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_OK);
		characteristic.setValue("redirectionOK");
		listCharacteristic.add(characteristic);
		
		characteristic = new Characteristic();
		characteristic.setName(Constants.REDIRECTION_KO);
		characteristic.setValue("redirectionKO");
		listCharacteristic.add(characteristic);
		
		
		
		return listCharacteristic;
	}

	private List<PaymentItem> createPaymentItem() {
		List<PaymentItem> listPaymentItem = new ArrayList<PaymentItem>();
		PaymentItem paymentItem = new PaymentItem();
		EntityRef item = new EntityRef();
		item.setId("id_del_vap");
		item.setRole(Constants.VAP);
		item.setCharacteristic(createCharacteristicEntityRef());
		paymentItem.setItem(item);
		listPaymentItem.add(paymentItem);
		return listPaymentItem;
	}

	private List<Characteristic> createCharacteristicEntityRef() {
		List<Characteristic> listCharacteristic = new ArrayList<Characteristic>();
		Characteristic characteristic = new Characteristic();
		characteristic.setName(Constants.BSCSCODE);
		characteristic.setValue("codigo_bscs");
		listCharacteristic.add(characteristic);
		return listCharacteristic;
	}

	private Money createTotalAmount() {
		Money money = new Money();
		money.setUnit(Constants.EUR);
		money.setValue(10f);
		return money;
	}
}