package com.orange.api.paymentmanagement.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.orange.api.paymentmanagement.db.entities.FixedValuesDB;
import com.orange.api.paymentmanagement.db.entities.PaymentRegistryDB;
import com.orange.api.paymentmanagement.db.repository.FixedValuesRepository;
import com.orange.api.paymentmanagement.db.repository.PaymentRegistryRepository;
import com.orange.api.paymentmanagement.feign.client.IntegrationServiceWSPspClient;
import com.orange.api.paymentmanagement.service.ConfirmationPreauthorizationPaymentService;
import com.orange.api.paymentmanagement.web.model.Payment;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.DatosCliente;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ParametrosAdicionales;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.PreautorizacionConfirmacionResponse;
import com.orange.api.paymentmanagement.web.model.integrationservicewspsp.ResultadoOperacion;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiBadRequestException;
import com.orange.openapiosp.boot.errorhandler.exception.OpenApiNotFoundException;

@SpringBootTest
@DirtiesContext
@RunWith(SpringRunner.class)
public class ConfirmationPreauthorizationPaymentServiceImplTest {

    @Mock
    private PaymentRegistryRepository paymentRegistryRepository;

    @Mock
    private FixedValuesRepository fixedValuesRepository;

    @Mock
    private IntegrationServiceWSPspClient integrationServiceWSPspClient;
    
    ObjectMapper objectMapper;
    
    @InjectMocks()
    private ConfirmationPreauthorizationPaymentService confirmationPreauthorizationPaymentService = new ConfirmationPreauthorizationPaymentServiceImpl(integrationServiceWSPspClient,fixedValuesRepository,paymentRegistryRepository);
    
    @Test
    public void testConfirmationPreauthorizationPayment_Success() throws StreamReadException, DatabindException, IOException {
        // Arrange
        PaymentRegistryDB paymentRegistry = createPaymentRegistry();

        List<FixedValuesDB> listFixedValues = new ArrayList<FixedValuesDB>();
        FixedValuesDB fixedValuesConfirmation = createFixedValues();
        listFixedValues.add(fixedValuesConfirmation);
        
        PreautorizacionConfirmacionResponse response = createPreautorizacionConfirmacionResponse();
        
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.registerModule(new JavaTimeModule());

        File file = new File("mocks/examples/ConfirmationPLRequest.json");
        Payment payment = objectMapper.readValue(file, Payment.class);

        when(paymentRegistryRepository.findByOriginOpnumber(Mockito.any())).thenReturn(paymentRegistry);
        when(fixedValuesRepository.findByTransactiontypeAndApp(Mockito.any(), Mockito.any()))
            .thenReturn(Collections.singletonList(fixedValuesConfirmation));
        when(integrationServiceWSPspClient.confirmationPreauthorizationPayment(Mockito.any()))
            .thenReturn(response);

        // Act
        Payment result = confirmationPreauthorizationPaymentService.confirmationPreauthorizationPayment(payment, paymentRegistry.getOriginOpnumber());

        // Assert
        assertNotNull(result);
        verify(paymentRegistryRepository).findByOriginOpnumber(paymentRegistry.getOriginOpnumber());
        verify(integrationServiceWSPspClient).confirmationPreauthorizationPayment(any());
        verify(paymentRegistryRepository).save(paymentRegistry);
    }



    @Test
    public void testConfirmationPreauthorizationPayment_PaymentRegistryNotFound() {
        // Arrange
        String numOrigin = "12345";
        Payment payment = new Payment();

        when(paymentRegistryRepository.findByOriginOpnumber(numOrigin)).thenReturn(null);

        // Act & Assert
        OpenApiNotFoundException exception = assertThrows(OpenApiNotFoundException.class, () -> 
            confirmationPreauthorizationPaymentService.confirmationPreauthorizationPayment(payment, numOrigin));
        assertEquals("Register not found.", exception.getDescription());
    }

    @Test
    public void testConfirmationPreauthorizationPayment_InvalidTransactionOrApp() {
        // Arrange
        String numOrigin = "12345";
        PaymentRegistryDB paymentRegistryConfirmationDB = new PaymentRegistryDB();
        paymentRegistryConfirmationDB.setTransactiontype("InvalidTransaction");
        paymentRegistryConfirmationDB.setChannel("InvalidApp");

        Payment payment = new Payment();

        when(paymentRegistryRepository.findByOriginOpnumber(numOrigin)).thenReturn(paymentRegistryConfirmationDB);
        when(fixedValuesRepository.findByTransactiontypeAndApp("InvalidTransaction", "InvalidApp"))
            .thenReturn(Collections.emptyList());

        // Act & Assert
        OpenApiBadRequestException exception = assertThrows(OpenApiBadRequestException.class, () -> 
            confirmationPreauthorizationPaymentService.confirmationPreauthorizationPayment(payment, numOrigin));
        assertEquals("The app param is not valid.", exception.getDescription());
    }
    
    private PreautorizacionConfirmacionResponse createPreautorizacionConfirmacionResponse() {
        PreautorizacionConfirmacionResponse response = new PreautorizacionConfirmacionResponse();

     // Fill the fields with sample values
     response.setDatosTarjeta(new Object()); // Replace with actual card data object if available
     response.setImporte(1500L); // Example amount
     response.setMoneda("USD"); // Currency
     response.setDatosResolutor(new Object()); // Replace with actual resolver data object if available
     response.setNumAutorizacion("AUTH123456"); // Authorization number
     response.setNumOperacionNNP(987654321); // Example operation number

     // Example for ParametrosAdicionales object
     ParametrosAdicionales parametrosAdicionales = new ParametrosAdicionales();
     response.setParametrosAdicionales(parametrosAdicionales);

     // Example for ResultadoOperacion object
     ResultadoOperacion resultadoOperacion = new ResultadoOperacion();
     resultadoOperacion.setCodigo("00"); // Success code
     resultadoOperacion.setMensaje("Operation completed successfully.");
     response.setResultadoOperacion(resultadoOperacion);

     // Example for DatosCliente object
     DatosCliente datosCliente = new DatosCliente();
     datosCliente.setCoCliente("AAAAA"); // Replace with actual fields
     datosCliente.setCoComercio("00000");
     datosCliente.setCoTerminal("111111");
     datosCliente.setPalabraClave("keyword");
     response.setDatosCliente(datosCliente);

     response.setFechaOpOrigen("2024-11-26T12:34:56Z"); // ISO 8601 format
     response.setIdioma("EN"); // Language
     response.setNumOpOrigen("1234567890"); // Example origin operation number
     response.setUsuario("user123"); // Example username
     
     return response;
    }

    private FixedValuesDB createFixedValues() {
        FixedValuesDB fixedValuesConfirmation = new FixedValuesDB();

        // Populating fields
        fixedValuesConfirmation.setId(1L);
        fixedValuesConfirmation.setCreationDate(new Timestamp(System.currentTimeMillis()));
        fixedValuesConfirmation.setUpdateDate(new Timestamp(System.currentTimeMillis()));
        fixedValuesConfirmation.setClientCode("CLIENT123");
        fixedValuesConfirmation.setTransactiontype("TRANSACTION_TYPE");
        fixedValuesConfirmation.setApp("APP_NAME");
        fixedValuesConfirmation.setCommercialCode("COMMERCIAL123");
        fixedValuesConfirmation.setTerminalCode("TERMINAL123");
        fixedValuesConfirmation.setKeyword("KEYWORD");
        fixedValuesConfirmation.setLanguage("en");
        fixedValuesConfirmation.setCoTipoOpLink("OPLINK_TYPE");
        fixedValuesConfirmation.setUrlLogo("https://example.com/logo.png");
        fixedValuesConfirmation.setColor("#FFFFFF");
        fixedValuesConfirmation.setText("Some Text");
        fixedValuesConfirmation.setTextcvv("CVV Text");
        fixedValuesConfirmation.setTextButton("Pay Now");
        fixedValuesConfirmation.setTextFxExpiration("MM/YY");
        fixedValuesConfirmation.setTextCard("Card Number");
        fixedValuesConfirmation.setTextTitle("Payment Title");
        fixedValuesConfirmation.setTextMask("**** **** **** ****");
        fixedValuesConfirmation.setCardType("VISA");
        fixedValuesConfirmation.setCurrency("USD");
        fixedValuesConfirmation.setSeed("SEED123");
        fixedValuesConfirmation.setFormButton("Submit");
        fixedValuesConfirmation.setTemplate("DEFAULT_TEMPLATE");
        fixedValuesConfirmation.setPaymentRetries("3");
        fixedValuesConfirmation.setValidityTime("60");
        fixedValuesConfirmation.setTarget("_blank");
        fixedValuesConfirmation.setUrlCss("https://example.com/styles.css");
        fixedValuesConfirmation.setTypelink("LINK_TYPE");
        fixedValuesConfirmation.setPaymentMethod("CREDIT_CARD");
        return fixedValuesConfirmation;
    }
    
    private PaymentRegistryDB createPaymentRegistry() {
        PaymentRegistryDB paymentRegistryConfirmationDB = new PaymentRegistryDB();

     // Timestamps
     paymentRegistryConfirmationDB.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setUpdateDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setAnnulationDate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setConfirmationOriginOpdate(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setLinkExpiration(Timestamp.valueOf(LocalDateTime.now()));
     paymentRegistryConfirmationDB.setLinkRegistration(Timestamp.valueOf(LocalDateTime.now()));

     // Basic details
     paymentRegistryConfirmationDB.setClientCode("12345");
     paymentRegistryConfirmationDB.setCommercialCode("COMM123");
     paymentRegistryConfirmationDB.setTerminalCode("TERM001");
     paymentRegistryConfirmationDB.setLanguage("EN");
     paymentRegistryConfirmationDB.setAmount("100.00");
     paymentRegistryConfirmationDB.setCurrency("USD");
     paymentRegistryConfirmationDB.setStatus("Scheduled");
     paymentRegistryConfirmationDB.setStatusDescription("Payment scheduled successfully");

     // Identifiers
     paymentRegistryConfirmationDB.setOriginOpnumber("OP123456");
     paymentRegistryConfirmationDB.setPhonenumber("1234567890");
     paymentRegistryConfirmationDB.setIdDocument("ID987654");
     paymentRegistryConfirmationDB.setTypeDocument("Passport");
     paymentRegistryConfirmationDB.setType("Individual");
     paymentRegistryConfirmationDB.setTransactiontype("scheduled_top_up");
     paymentRegistryConfirmationDB.setBscsIdentifier("BSCS12345");
     paymentRegistryConfirmationDB.setVapId("VAP56789");
     paymentRegistryConfirmationDB.setProcessflowId("PF123456");
     paymentRegistryConfirmationDB.setUserId("User001");
     paymentRegistryConfirmationDB.setLinkCode("LINK123");
     paymentRegistryConfirmationDB.setLinkId("LINKID56789");
     paymentRegistryConfirmationDB.setSessionId("SESSION12345");
     paymentRegistryConfirmationDB.setPaymentId("PAYID987654");
     paymentRegistryConfirmationDB.setMarketplaceOrderId("MARKET123");

     // Links and URL details
     paymentRegistryConfirmationDB.setLink("http://example.com/payment-link");
     paymentRegistryConfirmationDB.setPaymentLink("http://example.com/payment-details");
     paymentRegistryConfirmationDB.setUrlOk("http://example.com/success");
     paymentRegistryConfirmationDB.setUrlKo("http://example.com/failure");
     paymentRegistryConfirmationDB.setUrlIframe("http://example.com/iframe");
     paymentRegistryConfirmationDB.setHash("HASHVALUE12345");

     // Payment details
     paymentRegistryConfirmationDB.setPaymentFlow("IFRAME");
     paymentRegistryConfirmationDB.setPaymentAttempts("3");
     paymentRegistryConfirmationDB.setPaymentResult("Success");
     paymentRegistryConfirmationDB.setResultDescription("Payment processed successfully");
     paymentRegistryConfirmationDB.setPaymentUpdate("2023-01-01 12:00:00");
     paymentRegistryConfirmationDB.setPaymentMethod("Credit Card");
     paymentRegistryConfirmationDB.setPaymentMethodId("METHOD001");

     // Card and banking details
     paymentRegistryConfirmationDB.setBankNumber("BANK12345");
     paymentRegistryConfirmationDB.setCardNumber("4111111111111111");
     paymentRegistryConfirmationDB.setToken("TOKEN123456");

     // Annulation details
     paymentRegistryConfirmationDB.setAnnulationOpnumber("ANN123456");
     paymentRegistryConfirmationDB.setAnnulationId("ANNID123");
     paymentRegistryConfirmationDB.setAnnulationResult("Success");
     paymentRegistryConfirmationDB.setAnnulationDescription("Annulation processed successfully");

     // Session details
     paymentRegistryConfirmationDB.setSessionDate("2023-01-01 12:00:00");

     // Miscellaneous
     paymentRegistryConfirmationDB.setAuthorizationNumber("AUTH12345");
     paymentRegistryConfirmationDB.setChannel("WEB");
     paymentRegistryConfirmationDB.setCustCode("CUST001");
     paymentRegistryConfirmationDB.setOperationType("Online");
     paymentRegistryConfirmationDB.setConfirmationOriginOpnumber("CONFOP12345");

     return paymentRegistryConfirmationDB;
    }
}
